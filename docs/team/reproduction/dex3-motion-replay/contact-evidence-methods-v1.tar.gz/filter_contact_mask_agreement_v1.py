"""Conservatively filter existing evidence with both source hand-mask estimates.

This only removes parent candidates. Mask agreement is not semantic ground truth,
and neither contact acceptance nor original observation flags are changed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
from PIL import Image
from scipy.ndimage import binary_erosion

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'bundle', 'parent', 'path-map', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    a = parser.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    sys.path.insert(0, str(a.source / 'scripts/retarget'))
    from track3_review_source import resolve_source, mask_source_hash
    parent = json.loads((a.parent / 'report.json').read_text())
    assert parent['regions_payload_sha256'] == sha(a.parent / 'regions.npz')
    assert parent['bundle_manifest_sha256'] == sha(a.bundle / 'manifest.json')
    assert parent['contact_known'] is False and parent['physical_task_accepted'] is False
    paths = json.loads(a.path_map.read_text())
    locked = json.loads((a.bundle / 'source/provenance/inputs-lock.json').read_text())['source_files']
    hashes = {v['path']: v['sha256'] for v in locked}
    with np.load(a.parent / 'regions.npz', allow_pickle=False) as z:
        arrays = {k: z[k].copy() for k in z.files}
    rows = arrays['candidate_rows_hand_object']
    pixels = arrays['candidate_source_pixels']
    frames = arrays['frame_indices']
    keep = np.zeros(len(rows), dtype=bool)
    source_locks = {}
    for row in np.unique(rows[:, 0]):
        frame = int(frames[row])
        masks = []
        for side in ('left', 'right'):
            suffix = f'/masks/{side}/{frame:06d}.png'
            matches = [path for path in hashes if path.endswith(suffix)]
            assert len(matches) == 1
            raw = matches[0]
            path = resolve_source(raw, paths)
            assert sha(path) == hashes[raw] == mask_source_hash(hashes, frame, side, True)
            mask = np.asarray(Image.open(path)) > 0
            if mask.ndim == 3:
                mask = mask[:, :, 0]
            masks.append(mask)
            source_locks[raw] = {'local': str(path), 'sha256': hashes[raw]}
        for si in (0, 1):
            own = binary_erosion(masks[si] & ~masks[1-si], structure=np.ones((3,3), dtype=bool), border_value=0)
            selected = np.flatnonzero((rows[:,0] == row) & (rows[:,1] == si))
            xy = pixels[selected]
            keep[selected] = own[xy[:,1], xy[:,0]]
    parent_count = arrays['inferred_quality_stereo_contact_candidate_count'].copy()
    count = np.zeros_like(parent_count)
    selected_rows = rows[keep]
    np.add.at(count, tuple(selected_rows.T), 1)
    assert (count <= parent_count).all()
    arrays['inferred_quality_stereo_contact_candidate_count'] = count
    arrays['parent_candidate_count_before_mask_agreement'] = parent_count
    arrays['parent_candidate_indices_retained'] = np.flatnonzero(keep)
    for key in ('candidate_rows_hand_object', 'candidate_surface_points_object_local_m',
                'candidate_stereo_points_object_local_m', 'candidate_source_pixels'):
        arrays[key] = arrays[key][keep]
    centers = np.full_like(arrays['candidate_region_center_object_local_m'], np.nan)
    radius = np.full_like(arrays['candidate_region_radius_p90_local_m'], np.nan)
    for row, si, oi in np.argwhere(count > 0):
        selected = (selected_rows == [row,si,oi]).all(axis=1)
        points = arrays['candidate_surface_points_object_local_m'][selected]
        center = np.median(points, axis=0)
        centers[row,si,oi] = center
        radius[row,si,oi] = np.percentile(np.linalg.norm(points-center,axis=1),90)
    arrays['candidate_region_center_object_local_m'] = centers
    arrays['candidate_region_radius_p90_local_m'] = radius
    assert not arrays['original_observations_promoted'].any()
    for info in source_locks.values():
        assert sha(Path(info['local'])) == info['sha256']
    a.out.mkdir()
    np.savez_compressed(a.out / 'regions.npz', **arrays)
    report = {'source_sha256': sha(Path(__file__)), 'parent_report_sha256': sha(a.parent / 'report.json'),
              'parent_payload_sha256': sha(a.parent / 'regions.npz'), 'regions_payload_sha256': sha(a.out / 'regions.npz'),
              'bundle_manifest_sha256': sha(a.bundle / 'manifest.json'), 'source_mask_locks': source_locks,
              'filter': 'All nine original own-hand, non-other-hand mask pixels also required for each retained parent candidate',
              'estimated_mask_agreement_is_ground_truth': False, 'only_parent_candidates_removed': True,
              'candidate_points_before_by_hand': parent_count.sum(axis=(0,2)).tolist(),
              'candidate_points_after_by_hand': count.sum(axis=(0,2)).tolist(),
              'candidate_points_removed': int((~keep).sum()),
              'source_observations_promoted': False, 'hand_accuracy_accepted': False,
              'contact_known': False, 'physical_task_accepted': False, 'elapsed_seconds': time.monotonic()-started}
    (a.out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'source_mask_locks'}, indent=2))

if __name__ == '__main__':
    main()
