"""Source-backed potential contact regions, never observed contact labels.

Actual confidence-filtered stereo pixels anchor regions; hidden mesh vertices
receive no depth targets. All frames/hands/objects run with a predeclared method.
Human poses, object poses, camera, scales and observation support are untouched.
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import binary_erosion, maximum_filter, minimum_filter
from scipy.spatial import cKDTree

ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parents[1]

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()

def confidence(depth,valid,own):
    finite=np.isfinite(depth)&(depth>.01)&(depth<3)
    safe=np.where(finite,depth,0.)
    spread=maximum_filter(safe,size=3)-minimum_filter(safe,size=3)
    return binary_erosion(own&valid&finite,structure=np.ones((3,3),dtype=bool),border_value=0)&(spread<=.01)

def unambiguous_proximity(distances,index):
    own=distances[index]
    competitors=[d for i,d in enumerate(distances) if i!=index]
    other=np.min(np.stack(competitors),axis=0) if competitors else np.full_like(own,np.inf)
    return (own<=.005)&((other>.005)|(other-own>.002))

def controls():
    depth=np.full((5,5),.4)
    valid=np.ones((5,5),dtype=bool)
    mask=np.ones((5,5),dtype=bool)
    assert confidence(depth,valid,mask)[2,2]
    valid[1,1]=False
    assert binary_erosion(valid)[2,2]  # prior cross-shaped filter misses this corner
    assert not confidence(depth,valid,mask)[2,2]
    valid[:]=True;mask[1,1]=False
    assert not confidence(depth,valid,mask)[2,2]
    mask[:]=True;depth[1,1]=.43
    assert not confidence(depth,valid,mask)[2,2]
    depth[1,1]=np.nan
    assert not confidence(depth,valid,mask)[2,2]
    np.testing.assert_array_equal(unambiguous_proximity([np.array([.004,.006])],0),[True,False])
    np.testing.assert_array_equal(unambiguous_proximity([np.array([.001,.004]),np.array([.010,.010]),np.array([.002,.008])],0),[False,True])
    return {'all_nine_pixels_required':True,'invalid_corner_refused':True,
            'other_semantic_corner_refused':True,'discontinuity_or_nan_corner_refused':True,
            'single_object_proximity_checked':True,'third_object_ambiguity_refused':True}

def source_file(hashes,frame,marker):
    suffix=f'{int(frame):06d}.npy' if marker=='/depth/' else f'{int(frame):06d}.png'
    matches=[path for path in hashes if marker in path and path.endswith(suffix)]
    if len(matches)!=1:
        raise ValueError((frame,marker,len(matches)))
    return matches[0]

def temporal_intervals(frames,eligible):
    intervals=[]
    start=None
    for index,value in enumerate(np.r_[eligible,False]):
        if value and start is None:
            start=index
        elif not value and start is not None:
            if index-start>=3:
                intervals.append([int(frames[start]),int(frames[index-1])])
            start=None
    return intervals

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--quality',type=Path,required=True)
    p.add_argument('--pixel-stride',type=int,default=2,choices=(1,2,4))
    p.add_argument('--bundle',type=Path,required=True)
    p.add_argument('--material',type=Path,required=True)
    p.add_argument('--path-map',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    stride=a.pixel_stride
    sys.path.insert(0,str(a.source/'source/robotic_grounding'))
    sys.path.insert(0,str(a.source/'scripts/retarget'))
    from track3_review_source import mask_source_hash,raster,resolve_source
    from robotic_grounding.retarget.track3_bundle import validate_bundle
    from robotic_grounding.retarget.track3_collision_voxels import solid_depth_bounds
    started=time.monotonic()
    validation=validate_bundle(a.bundle)
    assert not a.out.exists()
    a.out.mkdir(parents=True)
    bm=json.loads((a.bundle/'manifest.json').read_text(encoding='utf-8'))
    mm=json.loads((a.material/'manifest.json').read_text(encoding='utf-8'))
    assert mm['source_bundle_payload_sha256']==validation['payload_sha256']
    paths=json.loads(a.path_map.read_text(encoding='utf-8'))
    assert all(set(item)=={'source_prefix','local_prefix'} for item in paths)
    lock=a.bundle/'source/provenance/inputs-lock.json'
    hashes={row['path']:row['sha256'] for row in json.loads(lock.read_text(encoding='utf-8'))['source_files']}
    with np.load(a.bundle/'episode.npz',allow_pickle=False) as archive:
        d={key:archive[key] for key in archive.files}
    protocol={'source_sha256':sha(Path(__file__)),'bundle_manifest_sha256':validation['manifest_sha256'],
              'material_manifest_sha256':sha(a.material/'manifest.json'),'input_lock_sha256':sha(lock),
              'raster_source_sha256':sha(a.source/'scripts/retarget/track3_review_source.py'),
              'source_pixels':'actual stereo depth at original own-hand mask pixels; no hidden-vertex targets',
              'surface_samples_per_object':1000000,'surface_sample_seed':4814,
              'source_pixel_stride':stride,'actual_original_pixels_only_no_depth_upsampling':True,'adjacent_depth_pixels_are_not_independent_measurements':True,'stereo_confidence_neighborhood':'all9 pixels,3x3square',
              'stereo_neighborhood_spread_max_m':.01,'mesh_source_front_depth_max_error_m':.01,
              'source_surface_point_max_distance_m':.005,'ambiguous_object_gap_difference_m':.002,
              'derived_material_depth_lower_max_m':.002,'minimum_points_per_frame':8,
              'minimum_contiguous_frames':3,'source_hand_direct_required':True,'source_object_observed_required':True,
              'grasp_annotations_used':False,'gt_used':False,'source_observations_modified':False,
              'display_holds_used':False,'contact_known':False,'physical_task_accepted':False,
              'controls':controls()}
    geometry=[]
    samples_hash=[]
    grids=[]
    for oi,obj in enumerate(bm['objects']):
        vertices=d[f'object_{oi}_vertices']
        tri=vertices[d[f'object_{oi}_faces']]
        area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=-1)/2
        assert area.sum()>0
        rng=np.random.default_rng(4814+oi)
        face=rng.choice(len(tri),1000000,p=area/area.sum())
        xy=rng.random((len(face),2));xy[xy.sum(axis=1)>1]=1-xy[xy.sum(axis=1)>1]
        selected=tri[face]
        samples=selected[:,0]+xy[:,0,None]*(selected[:,1]-selected[:,0])+xy[:,1,None]*(selected[:,2]-selected[:,0])
        geometry.append((samples,cKDTree(samples)))
        samples_hash.append(hashlib.sha256(samples.astype('<f8').tobytes()).hexdigest())
        path=a.material/f'object_{oi}.npz'
        expected=next(o['payload_sha256'] for o in mm['objects'] if o['object']==oi)
        assert sha(path)==expected
        with np.load(path,allow_pickle=False) as g:
            grids.append({key:g[key] for key in g.files})
    protocol['surface_samples_sha256']=samples_hash
    receipt=json.loads((a.quality/'run-receipt.json').read_text())
    assert receipt['status']=='completed_consistency_checks_proposals_unaccepted'
    assert receipt['quality_accepted'] is False and receipt['physical_task_accepted'] is False
    assert receipt['frame_evidence_sha256']==sha(a.quality/'frame-evidence.json')
    assert receipt['geometry_export_verification_sha256']==sha(a.quality/'geometry-export-verification.json')
    exports=json.loads((a.quality/'geometry-export-verification.json').read_text())['exports']
    verified={(v['side'],v['frame']):v for v in exports}
    record_paths={}
    for path in (a.quality/'accepted/records').glob('*/*.json'):
        record=json.loads(path.read_text())
        key=('right' if record['is_right'] else 'left',int(record['frame_idx']))
        assert key not in record_paths
        assert record['directly_observed'] is True and record['geometry_export_verified'] is True
        assert record['quality_accepted'] is False and record['physical_task_accepted'] is False
        assert sha(path)==verified[key]['record_sha256']
        record_paths[key]=path
    quality_locks={}
    proposal_support=np.zeros_like(d['hand_valid'])
    protocol.update(hand_quality_receipt_sha256=sha(a.quality/'run-receipt.json'),
        original_source_observation_flags_preserved=True,quality_or_contact_acceptance_promoted=False,
        source_pixels='actual locked stereo pixels inside the current-image proposal mask and projected verified geometry; inferred contact evidence only',
        source_hand_direct_required=False,consistency_passing_verified_geometry_required=True)
    (a.out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n',encoding='utf-8')
    frames=d['frame_indices'];n=len(frames)
    objects=len(bm['objects'])
    counts=np.zeros((n,2,objects),dtype=np.int64)
    centers=np.full((n,2,objects,3),np.nan)
    radius=np.full((n,2,objects),np.nan)
    hand_pixels=np.zeros((n,2),dtype=np.int64)
    cross_only=np.zeros((n,2),dtype=np.int64)
    records={}
    point_rows=[]
    point_local=[]
    point_stereo=[]
    source_pixel=[]
    best={}
    width,height=map(int,d['image_size'])
    K=d['intrinsics'].copy();K[:2]/=stride
    def load_path(raw):
        path=resolve_source(raw,paths)
        assert sha(path)==hashes[raw],(raw,path)
        records[raw]={'local':str(path),'sha256':hashes[raw]}
        return path
    for row,frame in enumerate(frames):
        observed=np.array([bm['object_observation_provenance'][obj['name']].get(str(int(frame)))=='observed' for obj in bm['objects']])
        if not any((side,int(frame)) in record_paths for side in ('left','right')) or not observed.any():
            continue
        depth=np.load(load_path(source_file(hashes,frame,'/depth/')),allow_pickle=False)
        valid=np.asarray(Image.open(load_path(source_file(hashes,frame,'/valid/'))))>0
        if valid.ndim==3:valid=valid[:,:,0]
        masks=[]
        for side in ('left','right'):
            key=(side,int(frame))
            mask=np.zeros((height,width),dtype=bool)
            if key in record_paths:
                path=a.quality/f'accepted/masks/{side}/{int(frame):06d}.png'
                mask=np.asarray(Image.open(path))>0
                if mask.ndim==3:mask=mask[:,:,0]
                assert mask.shape==(height,width)
                quality_locks[str(path)]=sha(path)
            masks.append(mask)
        camera=d['camera_c2w'][row]
        for si,side in enumerate(('left','right')):
            key=(side,int(frame))
            if key not in record_paths:continue
            geometry_path=a.quality/f'geometry/{side}/{int(frame):06d}.npz'
            assert sha(geometry_path)==verified[key]['geometry_sha256']
            with np.load(geometry_path,allow_pickle=False) as archive:
                assert bool(archive['accepted'])
                hand_proposal_camera=archive['vertices'].copy()
            assert hand_proposal_camera.shape==(778,3) and np.isfinite(hand_proposal_camera).all()
            proposal_support[row,si]=True
            quality_locks[str(geometry_path)]=sha(geometry_path)
            quality_locks[str(record_paths[key])]=sha(record_paths[key])
            own=masks[si]&~masks[1-si]
            confident=confidence(depth,valid,own)
            finite=np.isfinite(depth)&(depth>.01)&(depth<3)
            legacy=binary_erosion(own&valid&finite)&((maximum_filter(np.where(finite,depth,0.),size=3)-minimum_filter(np.where(finite,depth,0.),size=3))<=.01)
            cross_only[row,si]=int(np.sum((legacy&~confident)[::stride,::stride]))
            hand_camera=hand_proposal_camera
            zbuffer=np.full(((height+stride-1)//stride,(width+stride-1)//stride),np.inf)
            owner=np.full(zbuffer.shape,-1,dtype=np.int16)
            raster(hand_camera,d[f'hand_{side}_faces'],K,zbuffer,owner,si)
            conf=confident[::stride,::stride]&(owner==si)&(np.abs(zbuffer-depth[::stride,::stride])<=.01)
            y,x=np.nonzero(conf)
            hand_pixels[row,si]=len(x)
            if not len(x):continue
            z=depth[y*stride,x*stride]
            camera_points=np.column_stack(((x*stride-d['intrinsics'][0,2])/d['intrinsics'][0,0]*z,
                                          (y*stride-d['intrinsics'][1,2])/d['intrinsics'][1,1]*z,z))
            world=camera_points@camera[:3,:3].T+camera[:3,3]
            nearest=[];distances=[];locals_all=[]
            for oi,(samples,tree) in enumerate(geometry):
                pose=d[f'object_{oi}_world'][row]
                scale=float(d[f'object_{oi}_scale'][row])
                local=(world-pose[:3,3])@pose[:3,:3]/scale
                gap,index=tree.query(local,workers=1)
                nearest.append(samples[index]);distances.append(gap*scale);locals_all.append(local)
            for oi,(local,contact_points,gap) in enumerate(zip(locals_all,nearest,distances)):
                if not observed[oi]:continue
                eligible=unambiguous_proximity(distances,oi)
                grid=grids[oi]
                lo,hi,inside=solid_depth_bounds(local,grid['solid_cells'],grid['empty_center_distance_m'],grid['origin_m'],float(grid['pitch_m']))
                eligible &= lo*float(d[f'object_{oi}_scale'][row])<=.002
                selected=np.flatnonzero(eligible)
                counts[row,si,oi]=len(selected)
                if not len(selected):continue
                contacts=contact_points[selected]
                center=np.median(contacts,axis=0)
                centers[row,si,oi]=center
                radius[row,si,oi]=float(np.percentile(np.linalg.norm(contacts-center,axis=-1),90))
                # All eligible samples retained, no handpicked frame or region.
                point_rows.extend([[row,si,oi]]*len(selected))
                point_local.extend(contacts.tolist())
                point_stereo.extend(local[selected].tolist())
                source_pixel.extend(np.column_stack((x[selected]*stride,y[selected]*stride)).tolist())
                key=(si,oi)
                if key not in best or len(selected)>best[key]['count']:
                    best[key]={'row':row,'frame':int(frame),'count':len(selected),'pixels':np.column_stack((x[selected]*stride,y[selected]*stride)).tolist()}
        if row%25==0:
            print(json.dumps({'frame':int(frame),'source_contact_candidate_points':int(counts.sum()),'elapsed_s':time.monotonic()-started}),flush=True)
    for raw,record in records.items():assert sha(Path(record['local']))==record['sha256'],raw
    for path,expected in quality_locks.items():assert sha(Path(path))==expected,path
    assert validate_bundle(a.bundle)==validation
    assert sha(Path(__file__))==protocol['source_sha256']
    np.savez_compressed(a.out/'regions.npz',frame_indices=frames,source_hand_valid=d['hand_valid'],source_hand_directly_observed=d['hand_directly_observed'],
                        inferred_quality_stereo_contact_candidate_count=counts,candidate_region_center_object_local_m=centers,candidate_region_radius_p90_local_m=radius,
                        confident_projected_hand_pixels=hand_pixels,prior_cross_filter_only_pixels=cross_only,
                        consistency_checked_hand_proposal_support=proposal_support,original_observations_promoted=np.zeros_like(proposal_support),
                        candidate_rows_hand_object=np.asarray(point_rows,dtype=np.int64).reshape(-1,3),
                        candidate_surface_points_object_local_m=np.asarray(point_local,dtype=np.float64).reshape(-1,3),
                        candidate_stereo_points_object_local_m=np.asarray(point_stereo,dtype=np.float64).reshape(-1,3),
                        candidate_source_pixels=np.asarray(source_pixel,dtype=np.int64).reshape(-1,2))
    summaries={}
    for si,side in enumerate(('left','right')):
        summaries[side]={}
        for oi,obj in enumerate(bm['objects']):
            summaries[side][obj['name']]={'candidate_points':int(counts[:,si,oi].sum()),'frames_with_any_candidate':int(np.sum(counts[:,si,oi]>0)),
                                         'frames_with_at_least8_points':int(np.sum(counts[:,si,oi]>=8)),
                                         'automatic_potential_contact_intervals':temporal_intervals(frames,counts[:,si,oi]>=8)}
    report={**protocol,'regions_payload_sha256':sha(a.out/'regions.npz'),'protocol_sha256':sha(a.out/'protocol.json'),
            'per_hand_object':summaries,'prior_cross_filter_only_pixels':cross_only.sum(axis=0).tolist(),
            'source_files_verified':records,'best_support_frames':{f'{s}-{o}':{k:v for k,v in value.items() if k!='pixels'} for (s,o),value in best.items()},
            'quality_input_files_sha256':quality_locks,
            'elapsed_seconds':time.monotonic()-started,'status':'current-image quality/stereo contact evidence only; original source flags unchanged; no accepted contact or human pose'}
    images=a.out/'images';images.mkdir()
    for (si,oi),sample in best.items():
        raw=source_file(hashes,sample['frame'],'/color/')
        image=Image.open(load_path(raw)).convert('RGB')
        draw=ImageDraw.Draw(image)
        for x,y in sample['pixels']:
            draw.ellipse((x-1,y-1,x+1,y+1),fill=(250,70,30) if si==0 else (30,120,255))
        draw.rectangle((0,0,width,35),fill=(25,25,25))
        draw.text((12,10),f'UNACCEPTED potential contact pixels | frame{sample["frame"]} | {("left","right")[si]} {bm["objects"][oi]["name"]}',fill='white')
        image.save(images/f'{("left","right")[si]}-object{oi}-best-support.jpg',quality=95)
    report['source_files_verified']=records
    (a.out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['per_hand_object','prior_cross_filter_only_pixels','best_support_frames','elapsed_seconds','status']},indent=2),flush=True)

if __name__=='__main__':main()
