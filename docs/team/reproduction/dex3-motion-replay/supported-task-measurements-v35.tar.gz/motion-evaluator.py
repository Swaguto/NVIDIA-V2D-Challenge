"""Explicit inferred CAD-contact replay; source observations stay unchanged.

Free motion is linear XYZ/fingers and shortest quaternion interpolation between
stored knots. Closed intervals follow the original object and interpolated local
anchors. This evaluator does not assert source accuracy or a geometry proof.
"""

import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation, Slerp


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def blend(first, second, fraction):
    result = first * (1 - fraction) + second * fraction
    result[3:7] = Slerp([0.0, 1.0], Rotation.from_quat([first[3:7], second[3:7]]))(
        [fraction]
    )[0].as_quat()
    return result


class LockedReplayMotion:
    def __init__(
        self,
        bundle,
        baseline,
        parent_proposal,
        interval_inputs,
        atlas,
        proposal,
        *,
        source,
    ):
        saved = json.loads((proposal / "report.json").read_text())
        assert saved["motion_module_sha256"] == sha(Path(__file__))
        assert saved["payload_sha256"] == sha(proposal / "robot-motion-proposal.npz")
        assert saved["replay_knots_sha256"] == sha(proposal / "replay-knots.npz")
        assert saved["bundle_manifest_sha256"] == sha(bundle / "manifest.json")
        assert saved["physical_task_accepted"] is False
        self.source = load(bundle / "episode.npz")
        self.times = self.source["timestamps_s"]
        data = load(proposal / "robot-motion-proposal.npz")
        self.source_q = data["robot_qpos_inferred"]
        for target, origin in (
            ("source_hand_valid", "hand_valid"),
            ("source_hand_directly_observed", "hand_directly_observed"),
        ):
            np.testing.assert_array_equal(data[target], self.source[origin])
        assert (
            data["robot_pose_is_inferred"].all()
            and not data["robot_motion_target_validated"].any()
        )
        knots = load(proposal / "replay-knots.npz")
        self.breakpoints = knots["timestamps_s"]
        self.knot_q = knots["qpos_inferred"]
        self.knot_kinds = knots["inference_kind"]
        self.knot_details = knots["phase_details"]
        assert (
            np.all(np.diff(self.breakpoints) > 0)
            and np.isin(self.times, self.breakpoints).all()
        )
        np.testing.assert_array_equal(
            self.knot_q[np.searchsorted(self.breakpoints, self.times)], self.source_q
        )
        self.sides = saved["CAD_contact_replay_sides"]
        self.hold_local = {}
        for si, side in enumerate(self.sides):
            for phase in side["phases"]:
                rows = np.asarray(phase["source_rows"], dtype=np.int64)
                assert len(rows) >= 2 and np.all(np.diff(rows) == 1)
                assert np.all(
                    data["robot_contact_intent_inferred"][rows, si, phase["object"]]
                )
                poses = self.source[f"object_{phase['object']}_world"][rows]
                rotation = Rotation.from_matrix(poses[:, :3, :3])
                local = self.source_q[rows, si].copy()
                local[:, :3] = rotation.inv().apply(local[:, :3] - poses[:, :3, 3])
                local[:, 3:7] = (
                    rotation.inv() * Rotation.from_quat(local[:, 3:7])
                ).as_quat()
                self.hold_local[phase["prefix"]] = {"rows": rows, "qpos": local}
        self.repair_report = saved

    def bracket(self, timestamp):
        row = int(
            np.clip(
                np.searchsorted(self.times, timestamp, side="right") - 1,
                0,
                len(self.times) - 2,
            )
        )
        fraction = float(
            np.clip(
                (timestamp - self.times[row]) / (self.times[row + 1] - self.times[row]),
                0,
                1,
            )
        )
        return row, fraction

    def object_pose(self, oi, timestamp):
        row, fraction = self.bracket(timestamp)
        raw = self.source[f"object_{oi}_world"][row : row + 2]
        rotations = Rotation.from_matrix(raw[:, :3, :3])
        matrix = Slerp([0.0, 1.0], rotations)([fraction]).as_matrix()[0]
        residual = raw[:, :3, :3] - rotations.as_matrix()
        matrix += residual[0] * (1 - fraction) + residual[1] * fraction
        translation = raw[0, :3, 3] * (1 - fraction) + raw[1, :3, 3] * fraction
        scale = float(
            self.source[f"object_{oi}_scale"][row] * (1 - fraction)
            + self.source[f"object_{oi}_scale"][row + 1] * fraction
        )
        return matrix, translation, scale

    def evaluate(self, timestamp):
        row = int(
            np.clip(
                np.searchsorted(self.breakpoints, timestamp, side="right") - 1,
                0,
                len(self.breakpoints) - 2,
            )
        )
        fraction = float(
            np.clip(
                (timestamp - self.breakpoints[row])
                / (self.breakpoints[row + 1] - self.breakpoints[row]),
                0,
                1,
            )
        )
        q = np.asarray(
            [
                blend(self.knot_q[row, si], self.knot_q[row + 1, si], fraction)
                for si in (0, 1)
            ]
        )
        kinds, details = self.knot_kinds[row].copy(), self.knot_details[row].copy()
        if fraction == 0:
            q = self.knot_q[row].copy()
        elif fraction == 1:
            q = self.knot_q[row + 1].copy()
        source_row, f = self.bracket(timestamp)
        for si, side in enumerate(self.sides):
            for phase in side["phases"]:
                if not phase["interval"][0] <= timestamp <= phase["interval"][1]:
                    continue
                support = self.hold_local[phase["prefix"]]
                rows = support["rows"]
                if source_row >= rows[-1]:
                    local = support["qpos"][-1].copy()
                else:
                    i = int(source_row - rows[0])
                    assert 0 <= i < len(rows) - 1
                    local = blend(support["qpos"][i], support["qpos"][i + 1], f)
                raw = self.source[f"object_{phase['object']}_world"][
                    source_row : source_row + 2
                ]
                rotation = Slerp([0.0, 1.0], Rotation.from_matrix(raw[:, :3, :3]))([f])[
                    0
                ]
                q[si] = local
                q[si, :3] = (
                    rotation.apply(local[:3])
                    + raw[0, :3, 3] * (1 - f)
                    + raw[1, :3, 3] * f
                )
                q[si, 3:7] = (rotation * Rotation.from_quat(local[3:7])).as_quat()
                kinds[si] = 16
                break
        exact = np.flatnonzero(self.times == timestamp)
        if len(exact):
            q = self.source_q[int(exact[0])].copy()
        return q, kinds, details
