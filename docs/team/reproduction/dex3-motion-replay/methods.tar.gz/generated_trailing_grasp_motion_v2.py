"""Extend existing inferred grasp schedules using locked source-only continuity.

Reuse the fitted Dex3 anchors, opening corridors, object interpolation and free
priors. No human observation, source hold state or object pose is changed.
"""
import argparse
import json
from pathlib import Path

import numpy as np

from corrected_per_grasp_motion_v5 import CorrectedPerGraspMotion as BaseMotion
from corrected_per_grasp_motion_v1 import load, sha
from generated_per_grasp_motion_v4 import PerGraspMotion


class ContinuationMotion(BaseMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas,
                 proposal=None, *, base_repair=None, timing_inputs=None):
        self.timing_enabled = False
        saved = None
        if proposal is not None:
            saved = json.loads((proposal/'report.json').read_text())
            base_repair = base_repair or proposal.parent/saved['base_repair_proposal']
            timing_inputs = timing_inputs or proposal.parent/saved['timing_inputs']
            assert saved['base_repair_report_sha256'] == sha(base_repair/'report.json')
            assert saved['timing_report_sha256'] == sha(timing_inputs/'report.json')
            assert saved['motion_module_sha256'] == sha(Path(__file__))
            assert saved['payload_sha256'] == sha(proposal/'robot-motion-proposal.npz')
        assert base_repair is not None and timing_inputs is not None
        super().__init__(bundle,baseline,parent_proposal,interval_inputs,atlas,base_repair)
        self.base_repair, self.timing_inputs = base_repair,timing_inputs
        self.base_data = load(base_repair/'robot-motion-proposal.npz')
        self.timing_report = json.loads((timing_inputs/'report.json').read_text())
        tr = self.timing_report
        assert tr['parent_proposal_report_sha256'] == sha(base_repair/'report.json')
        assert tr['bundle_manifest_sha256'] == sha(bundle/'manifest.json')
        assert tr['payload_sha256'] == sha(timing_inputs/'intent-proposal.npz')
        assert not tr['source_annotations_or_GT_read'] and tr['all_targets_unvalidated']
        timing = load(timing_inputs/'intent-proposal.npz')
        for target,key in (('frame_indices','frame_indices'),('timestamps_s','timestamps_s'),
                           ('source_hand_valid','hand_valid'),('source_hand_directly_observed','hand_directly_observed')):
            np.testing.assert_array_equal(timing[target],self.source[key])
        np.testing.assert_array_equal(timing['source_object_observed'],self.base_data['source_object_observed'])
        np.testing.assert_array_equal(timing['original_robot_contact_intent_inferred'],self.base_data['robot_contact_intent_inferred'])
        self.new_intent = timing['robot_contact_intent_inferred']
        self.extension = timing['trailing_source_continuity_extension']
        assert self.new_intent.dtype == self.extension.dtype == bool
        np.testing.assert_array_equal(self.new_intent,self.base_data['robot_contact_intent_inferred']|self.extension)
        assert not (self.extension&self.base_data['robot_contact_intent_inferred']).any()
        assert not timing['all_robot_motion_target_validated'].any()
        reliable = self.source['hand_valid']&self.source['hand_directly_observed']
        assert not (self.extension.any(axis=2)&~reliable).any()
        assert np.all(self.new_intent.sum(axis=2)<=1)
        self.schedule_changes = []
        for si,side in enumerate(self.sides):
            covered = np.zeros_like(self.new_intent[:,si])
            for phase in side['phases']:
                original_rows = np.asarray(phase['source_rows'])
                oi = phase['object']
                end = int(original_rows[-1])
                while end+1<len(self.times) and self.new_intent[end+1,si,oi]:
                    assert self.source['frame_indices'][end+1] == self.source['frame_indices'][end]+1
                    assert self.extension[end+1,si,oi]
                    end += 1
                rows = np.arange(original_rows[0],end+1)
                assert self.new_intent[rows,si,oi].all()
                covered[rows,oi] = True
                old_interval = phase['interval']
                phase['parent_interval'] = old_interval
                phase['interval'] = (old_interval[0],float(self.times[end]))
                phase['source_rows'] = rows.tolist()
                self.schedule_changes.append({'prefix':phase['prefix'],'parent_interval_s':list(old_interval),
                                              'interval_s':list(phase['interval']),
                                              'added_source_frames':self.source['frame_indices'][rows[len(original_rows):]].tolist()})
            np.testing.assert_array_equal(covered,self.new_intent[:,si])
            for previous,current in zip(side['phases'][:-1],side['phases'][1:]):
                assert previous['interval'][1]+previous['duration_s']+self.free_blend <= current['interval'][0]-current['duration_s']-self.free_blend
            for phase in side['phases']:
                self.translation_delta[phase['source_rows'],si] = 0.
                for profile in self.profiles:
                    if profile['side']==side['side']:
                        assert profile['time_end_s']<=phase['interval'][0] or profile['time_start_s']>=phase['interval'][1]
                self.breakpoints = np.r_[self.breakpoints,phase['interval'][0]-phase['clock'],phase['interval'][1]+phase['clock'],
                                         phase['interval'][0]-phase['duration_s']-self.free_blend,
                                         phase['interval'][1]+phase['duration_s']+self.free_blend]
        self.breakpoints = np.unique(self.breakpoints)
        self.breakpoints = self.breakpoints[(self.breakpoints>=self.times[0])&(self.breakpoints<=self.times[-1])]
        self.timing_enabled = True
        q = np.array([self.evaluate(float(t))[0] for t in self.times])
        assert np.isfinite(q).all()
        original = self.base_data['robot_contact_intent_inferred'].any(axis=2)
        np.testing.assert_allclose(q[original],self.base_data['robot_qpos_inferred'][original],rtol=0,atol=1e-12)
        self.source_sample_maximum_error = 0.
        if saved is not None:
            stored = load(proposal/'robot-motion-proposal.npz')
            assert saved["physical_task_accepted"] is False
            for key in ("frame_indices","timestamps_s","source_hand_valid","source_hand_directly_observed","source_object_observed","source_inferred_hold_state","robot_contact_intent_bridge"):
                np.testing.assert_array_equal(stored[key],self.base_data[key])
            assert stored["robot_pose_is_inferred"].all()
            assert not stored["robot_motion_target_validated"].any()
            np.testing.assert_array_equal(stored['robot_contact_intent_inferred'],self.new_intent)
            np.testing.assert_array_equal(stored['robot_contact_intent_trailing_extension'],self.extension)
            np.testing.assert_allclose(q,stored['robot_qpos_inferred'],rtol=0,atol=1e-12)
            self.source_sample_maximum_error = float(abs(q-stored['robot_qpos_inferred']).max())
            self.repair_report = saved

    def evaluate(self,timestamp):
        q,kinds,details = super().evaluate(timestamp)
        if self.timing_enabled:
            for si,side in enumerate(self.sides):
                for phase in side['phases']:
                    if phase['parent_interval'][1]<timestamp<=phase['interval'][1]:
                        kinds[si] = 13
        return q,kinds,details


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('bundle','baseline','parent-proposal','interval-inputs','atlas','base-repair','timing-inputs','out'):
        parser.add_argument('--'+name,type=Path,required=True)
    a = parser.parse_args()
    assert not a.out.exists()
    assert a.base_repair.parent.resolve()==a.timing_inputs.parent.resolve()==a.out.parent.resolve(), 'Use sibling locked input directories for portable references'
    motion = ContinuationMotion(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,
                                base_repair=a.base_repair,timing_inputs=a.timing_inputs)
    data = {k:v.copy() for k,v in motion.base_data.items()}
    q,kinds,details = (np.asarray(v) for v in zip(*(motion.evaluate(float(t)) for t in motion.times)))
    parent_q = data['robot_qpos_inferred'].copy()
    data['robot_qpos_inferred'] = q
    data['robot_contact_intent_inferred'] = motion.new_intent
    data['robot_contact_intent_trailing_extension'] = motion.extension
    kinds[data['robot_contact_intent_bridge'].any(axis=2)] = 3
    data['robot_pose_inference_kind'] = kinds
    data['robot_grasp_phase_index_inferred'] = details[:,:,0].astype(np.int16)
    data['robot_blend_object'] = details[:,:,1].astype(np.int16)
    data['robot_corridor_opening_clock_s'] = details[:,:,2]
    data['robot_corridor_prior_blend_weight'] = details[:,:,3]
    uncorrected = np.array([PerGraspMotion.evaluate(motion,float(t))[0] for t in motion.times])
    data['robot_transition_translation_delta_m'] = q[:,:,:3]-uncorrected[:,:,:3]
    dense_times = np.unique(np.r_[motion.breakpoints,(motion.breakpoints[:-1]+motion.breakpoints[1:])/2])
    dense,dense_kind,dense_detail = (np.asarray(v) for v in zip(*(motion.evaluate(float(t)) for t in dense_times)))
    for si,side in enumerate(('left','right')):
        limits = np.asarray(motion.rm['joints'][side]['velocity_limits_rad_s'])
        assert np.all(abs(np.diff(dense[:,si,7:],axis=0))/np.diff(dense_times)[:,None]<=limits+1e-8)
    for key in ('source_hand_valid','source_hand_directly_observed','source_object_observed','source_inferred_hold_state','robot_contact_intent_bridge'):
        np.testing.assert_array_equal(data[key],motion.base_data[key])
    assert data['robot_pose_is_inferred'].all() and not data['robot_motion_target_validated'].any()
    a.out.mkdir(parents=True)
    payload = a.out/'robot-motion-proposal.npz'
    np.savez_compressed(payload,**data)
    dense_payload = a.out/'generated-corridor-waypoints.npz'
    np.savez_compressed(dense_payload,timestamps_s=dense_times,robot_qpos_inferred=dense,
                        robot_pose_inference_kind=dense_kind,robot_grasp_phase_details=dense_detail,
                        robot_pose_is_inferred=np.ones(dense.shape[:2],dtype=bool),
                        robot_motion_target_validated=np.zeros(dense.shape[:2],dtype=bool))
    report = {k:motion.repair_report[k] for k in ('bundle_manifest_sha256','baseline_manifest_sha256','interval_report_sha256','atlas_sha256','material_manifest_sha256','robot_assets')}
    changed = np.any(q!=parent_q,axis=2)
    report.update(source_sha256=sha(Path(__file__)),motion_module_sha256=sha(Path(__file__)),
                  parent_motion_module_sha256=sha(Path(__file__).with_name('corrected_per_grasp_motion_v5.py')),
                  base_repair_proposal=a.base_repair.name,base_repair_report_sha256=sha(a.base_repair/'report.json'),
                  timing_inputs=a.timing_inputs.name,timing_report_sha256=sha(a.timing_inputs/'report.json'),
                  parent_proposal_report_sha256=sha(a.parent_proposal/'report.json'),payload_sha256=sha(payload),
                  generated_waypoint_payload_sha256=sha(dense_payload),schedule_changes=motion.schedule_changes,
                  changed_inferred_source_states=int(changed.sum()),
                  changed_source_frames_by_side={s:motion.source['frame_indices'][changed[:,si]].tolist() for si,s in enumerate(('left','right'))},
                  inferred_continuation_states=int(motion.extension.sum()),original_grasp_anchors_retained=int(motion.base_data['robot_contact_intent_inferred'].sum()),
                  original_grasp_anchor_maximum_q_error=float(abs(q[motion.base_data['robot_contact_intent_inferred'].any(axis=2)]-parent_q[motion.base_data['robot_contact_intent_inferred'].any(axis=2)]).max()),
                  source_frames=len(q),dense_timeline_samples=len(dense_times),
                  controls={'source_arrays_unchanged':True,'original_anchors_unchanged':True,'no_missing_observations_extended':True,'finger_speed_limits_checked':True},
                  robot_inference_kinds={'13':'source-supported trailing continuation of an existing inferred robot grasp; human observations unchanged'},
                  source_annotations_or_GT_used=False,episode_specific_frames_or_crops=False,
                  complete_scene_clearance_certified=False,source_contact_timing_accepted=False,
                  contact_force_or_grasp_stability_measured=False,new_simulator_run=False,physical_task_accepted=False)
    (a.out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:report[k] for k in ('inferred_continuation_states','changed_inferred_source_states','schedule_changes','original_grasp_anchor_maximum_q_error','physical_task_accepted')}))


if __name__=='__main__':
    main()
