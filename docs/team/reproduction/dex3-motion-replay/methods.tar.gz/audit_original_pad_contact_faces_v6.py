"""Find original pad-face contact witnesses without a nearest-face normal tie.

Every original triangle whose exact target distance is within the fixed 2 mm
limit is considered. Report actual two-pad facing/opposition witnesses; this
development proxy does not measure force, source accuracy or grasp stability.
"""
import argparse
import importlib
import json
from pathlib import Path
import sys
import time
import xml.etree.ElementTree as ET

import numpy as np
import trimesh
from scipy.spatial.transform import Rotation

from corrected_per_grasp_motion_v1 import load,sha
from closest_mesh_surface_v2 import Surface,closest_triangle_points,analytic_controls
from exact_voxel_boundary_v1 import Boundary
from audit_per_grasp_contact_timing_v2 import affine_nearby_facets


def all_near_faces(surface,target,limit=.002):
    ids = []
    for group,tree,radius in surface.radius_groups:
        subset = tree.query_ball_point(target,limit+radius+1e-12,eps=0)
        if subset:
            ids.extend(group[np.asarray(subset,dtype=np.int64)].tolist())
    ids = np.asarray(sorted(ids),dtype=np.int64)
    if not len(ids):
        return ids,np.empty((0,3)),np.empty(0),0
    feet = closest_triangle_points(surface.triangles[ids],np.tile(target,(len(ids),1)))
    distance = np.linalg.norm(feet-target,axis=1)
    passing = distance<=limit+1e-12
    return ids[passing],feet[passing],distance[passing],len(ids)


def controls():
    vertices = np.array([[0.,0,0],[1.,0,0],[0,1.,0]])
    surface = Surface(vertices,np.array([[0,1,2],[0,2,1]]))
    target = np.array([.5,.5,0.])
    ids,feet,gap,_ = all_near_faces(surface,target)
    np.testing.assert_array_equal(ids,[0,1])
    np.testing.assert_array_equal(feet,np.tile(target,(2,1)))
    assert np.dot(surface.normals[0],surface.normals[1])==-1
    assert not len(all_near_faces(surface,target+[0,0,.01])[0])
    rotation = Rotation.from_rotvec([.4,-.3,.2]).as_matrix()
    transformed = Surface(vertices@rotation.T+[1,2,3],np.array([[0,1,2],[0,2,1]]))
    ids2,feet2,gap2,_ = all_near_faces(transformed,target@rotation.T+[1,2,3])
    np.testing.assert_array_equal(ids,ids2)
    np.testing.assert_allclose(feet2,feet@rotation.T+[1,2,3],atol=1e-12)
    np.testing.assert_allclose(gap,gap2,atol=1e-12)
    return {'opposite_normals_at_shared_edge_both_retained':True,'far_target_refused':True,
            'fixed_world_basis_invariant':True,**analytic_controls()}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','parent-proposal','interval-inputs','atlas','proposal','material','annotation','out'):
        p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--motion-kind',choices=('continuation','repaired','retained-release','bounded-release-v4','gated-edge'),required=True)
    a = p.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    tested = controls()
    module_name,class_name = {
        'continuation':('generated_trailing_grasp_motion_v2','ContinuationMotion'),
        'repaired':('repaired_trailing_grasp_motion_v1','RepairedContinuationMotion'),
        'retained-release':('retained_source_following_release_motion_v7','RetainedReleaseMotion'),
        'bounded-release-v4':('repaired_retained_release_motion_v4','RepairedReleaseMotion'),
        'gated-edge':('clearance_gated_edge_motion_v2','ClearanceGatedEdgeMotion'),
    }[a.motion_kind]
    module = importlib.import_module(module_name)
    cls = getattr(module,class_name)
    motion = cls(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,a.proposal, **({'source':a.source} if a.motion_kind=='gated-edge' else {}))
    source = motion.source
    data = load(a.proposal/'robot-motion-proposal.npz')
    mm = json.loads((a.material/'manifest.json').read_text())
    assert mm['source_bundle_payload_sha256']==sha(a.bundle/'episode.npz')
    assert motion.repair_report['material_manifest_sha256']==sha(a.material/'manifest.json')
    sys.path.insert(0,str(a.source/'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    assets = a.source/'source/robotic_grounding/robotic_grounding/assets'
    verify_robot_assets(motion.repair_report,assets)
    boundaries = {}
    for entry in mm['objects']:
        path = a.material/f"object_{entry['object']}.npz"
        assert sha(path)==entry['payload_sha256']
        z = load(path)
        boundaries[entry['object']] = Boundary(z['solid_cells'],z['origin_m'],float(z['pitch_m']))
    records = []
    for si,side in enumerate(('left','right')):
        kin = setup_dex3_kinematics(side=side,max_iter=1)
        xml = ET.parse(assets/f'urdfs/g1/dex3_{side}.urdf').getroot()
        surfaces = {}
        for finger,suffix in (('thumb','2'),('index','1')):
            name = f'{side}_hand_{finger}_{suffix}_link'
            collision = xml.find(f"link[@name='{name}']/collision")
            spec = collision.find('geometry/mesh')
            mesh = trimesh.load(assets/'meshes'/spec.attrib['filename'].removeprefix('package://'),force='mesh',process=False)
            vertices = np.asarray(mesh.vertices,dtype=float)*np.fromstring(spec.attrib.get('scale','1 1 1'),sep=' ')
            origin = collision.find('origin')
            if origin is not None:
                vertices = vertices@Rotation.from_euler('xyz',np.fromstring(origin.attrib.get('rpy','0 0 0'),sep=' ')).as_matrix().T+np.fromstring(origin.attrib.get('xyz','0 0 0'),sep=' ')
            surfaces[finger] = (name,Surface(vertices,mesh.faces))
        for phase in motion.sides[si]['phases']:
            spec = next(v for v in motion.atlas['grasps'] if v['prefix']==phase['prefix'])
            path = a.atlas.parent/spec['templates']/'report.json'
            assert sha(path)==spec['templates_report_sha256']
            template = json.loads(path.read_text())
            candidate = next(v for v in template['templates'] if v['side']==side and v['object']==phase['object'] and v.get('seed')==phase['seed'])
            rows = np.flatnonzero((motion.times>=phase['interval'][0]-phase['duration_s']-motion.free_blend-1e-10)&
                                  (motion.times<=phase['interval'][1]+phase['duration_s']+motion.free_blend+1e-10))
            oi = phase['object']
            for row in rows:
                kin.configuration.update(data['robot_qpos_inferred'][row,si])
                pose = source[f'object_{oi}_world'][row]
                matrix = pose[:3,:3]*source[f'object_{oi}_scale'][row]
                translation = pose[:3,3]
                inverse = np.linalg.inv(matrix)
                singular = np.linalg.svd(matrix,compute_uv=False)
                choices,pad_counts = {},{}
                for intended in candidate['pads']:
                    finger = intended['finger']
                    name,surface = surfaces[finger]
                    tf = kin.configuration.get_transform_frame_to_world(name)
                    target_world = matrix@(np.asarray(intended['target_object_scaled_m'])/candidate['template_reference_scale'])+translation
                    target_link = tf.rotation.T@(target_world-tf.translation)
                    ids,points,gaps,count = all_near_faces(surface,target_link)
                    options = []
                    if len(ids):
                        world = points@tf.rotation.T+tf.translation
                        canonical = (world-translation)@inverse.T
                        distance,_,_ = boundaries[oi].unsigned(canonical)
                        inside = boundaries[oi].inside(canonical)
                        lower = np.where(inside,-distance*singular.max(),distance*singular.min())
                        upper = np.where(inside,-distance*singular.min(),distance*singular.max())
                        for j in np.flatnonzero((lower>=-.0005-1e-12)&(upper<=.002+1e-12)):
                            facets = affine_nearby_facets(boundaries[oi],canonical[j],tf.rotation@surface.normals[ids[j]],matrix,translation)
                            for facet in facets:
                                options.append({'original_mesh_triangle_index':int(ids[j]),'robot_point_world_m':world[j].tolist(),
                                                'target_gap_m':float(gaps[j]),'signed_material_gap_lower_m':float(lower[j]),
                                                'signed_material_gap_upper_m':float(upper[j]),'material_facet':facet})
                    choices[finger] = options
                    pad_counts[finger] = {'complete_candidate_triangles':count,'within_target_limit_triangles':len(ids),'passing_facing_options':len(options)}
                witness = None
                for thumb in choices['thumb']:
                    for index in choices['index']:
                        dot = float(np.dot(thumb['material_facet']['world_outward_normal'],index['material_facet']['world_outward_normal']))
                        if dot<=-.5+1e-12:
                            witness = {'thumb':thumb,'index':index,'material_normal_dot':dot}
                            break
                    if witness is not None:
                        break
                records.append({'prefix':phase['prefix'],'source_frame':int(source['frame_indices'][row]),'side':side,'object':oi,
                                'source_hand_valid':bool(source['hand_valid'][row,si]),'source_hand_directly_observed':bool(source['hand_directly_observed'][row,si]),
                                'closed_intent':bool(data['robot_contact_intent_inferred'][row,si,oi]),
                                'pad_candidates':pad_counts,'two_pad_original_face_proxy':witness is not None,'witness':witness})
            print(json.dumps({'grasp':phase['prefix'],'source_samples':len(rows),'elapsed_seconds':time.monotonic()-started}),flush=True)
    labels = json.loads(a.annotation.read_text())
    validation = []
    for label in labels['visible_grasp_intervals']:
        oi = next(v['index'] for v in motion.bm['objects'] if v['name']==label['object_id'])
        frames = list(range(label['definite_core_start_frame'],label['definite_core_end_frame']+1))
        selected = [v for v in records if v['side']==label['hand'] and v['object']==oi and v['source_frame'] in frames]
        by_frame = {v['source_frame']:v for v in selected}
        assert len(by_frame)==len(selected)
        missing = [f for f in frames if f not in by_frame or not by_frame[f]['two_pad_original_face_proxy']]
        validation.append({'grasp_id':label['grasp_id'],'definite_core_frames':len(frames),'missing_contact_proxy_core_frames':missing,
                           'core_frames_not_sampled':[f for f in frames if f not in by_frame]})
    a.out.mkdir(parents=True)
    report = {'source_sha256':sha(Path(__file__)),'motion_module_sha256':sha(Path(module.__file__)),
              'proposal_report_sha256':sha(a.proposal/'report.json'),'bundle_manifest_sha256':sha(a.bundle/'manifest.json'),
              'material_manifest_sha256':sha(a.material/'manifest.json'),'atlas_sha256':sha(a.atlas),
              'facet_helper_sha256':sha(Path(__file__).with_name('audit_per_grasp_contact_timing_v2.py')),
              'surface_helper_sha256':sha(Path(__file__).with_name('closest_mesh_surface_v2.py')),
              'annotation_sha256':sha(a.annotation),'controls':tested,'measurements':records,'source_label_validation':validation,
              'labels_read_only_after_all_geometry':True,'nearest_face_normal_ties_not_discarded':True,
              'target_distance_limit_m':.002,'interior_tolerance_m':.0005,'opposition_dot_max':-.5,
              'source_observations_changed':False,'contact_force_or_grasp_stability_measured':False,
              'continuous_contact_certificate':False,'physical_task_accepted':False,'elapsed_seconds':time.monotonic()-started}
    (a.out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'source_label_validation':validation,'physical_task_accepted':False}))


if __name__=='__main__':
    main()
