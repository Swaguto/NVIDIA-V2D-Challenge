"""Reject complete recovered edge priors when the robot geometry screen fails.

Use the existing bounded, checked robot approach/exit for a rejected edge. Never
erase or promote source observations. The screen selects whole edge segments,
not episode-specific frames/crops. Full surface checks must follow this screen.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from corrected_per_grasp_motion_v1 import load, sha
from image_supported_edge_motion_v2 import ImageSupportedEdgeMotion
from repaired_retained_release_motion_v4 import RepairedReleaseMotion


class ClearanceGatedEdgeMotion:
    def __init__(self,bundle,baseline,parent_proposal,interval_inputs,atlas,proposal=None,*,source,base=None,probe=None):
        saved=None
        if proposal is not None:
            saved=json.loads((proposal/'report.json').read_text())
            assert saved['motion_module_sha256']==sha(Path(__file__))
            assert saved['payload_sha256']==sha(proposal/'robot-motion-proposal.npz')
            base=proposal.parent/saved['gated_edge_parent_proposal']
            probe=proposal.parent/saved['gated_edge_screen']
        assert base is not None and probe is not None
        self.parent=ImageSupportedEdgeMotion(bundle,baseline,parent_proposal,interval_inputs,atlas,base,source=source)
        safe=base.parent/self.parent.repair_report['base_repaired_proposal']
        fallback=RepairedReleaseMotion(bundle,baseline,parent_proposal,interval_inputs,atlas,safe)
        scan=json.loads((probe/'report.json').read_text())
        assert scan['proposal_report_sha256']==sha(base/'report.json')
        assert scan['corrected_motion_module_sha256']==sha(Path(__file__).with_name('image_supported_edge_motion_v2.py'))
        self.selections=[]
        failures=scan['explicit_material_failure_pairs']+scan['cross_hand_failure_pairs']
        for si,side in enumerate(self.parent.sides):
            rows=np.asarray(side['reliable_prior_rows'])
            for name,edge_row,mask in (
                ('entry',rows[0],np.arange(len(self.parent.times))<rows[0]),
                ('exit',rows[-1],np.arange(len(self.parent.times))>rows[-1])):
                edge_time=float(self.parent.times[edge_row])
                rejected=[v for v in failures if (v.get('side',side['side'])==side['side']) and
                    ((v['generated_timestamp_s']<edge_time) if name=='entry' else (v['generated_timestamp_s']>edge_time))]
                if rejected:self.parent.free_priors[si][mask]=fallback.free_priors[si][mask]
                self.selections.append({'side':side['side'],'edge':name,'edge_time_s':edge_time,
                    'recovered_robot_prior_selected':not bool(rejected),'failed_screen_pairs':len(rejected),
                    'fallback':'bounded retained-release robot prior' if rejected else None,
                    'source_observations_changed':False})
        self.parent_data=load(base/'robot-motion-proposal.npz')
        self.repair_report={**self.parent.repair_report,'gated_edge_parent_proposal':base.name,
            'gated_edge_parent_report_sha256':sha(base/'report.json'),'gated_edge_screen':probe.name,
            'gated_edge_screen_sha256':sha(probe/'report.json'),'edge_selections':self.selections,
            'fallback_proposal':safe.name,'fallback_report_sha256':sha(safe/'report.json')}
        q=np.array([self.evaluate(float(t))[0] for t in self.parent.times])
        anchors=self.parent_data['robot_contact_intent_inferred'].any(axis=2)
        np.testing.assert_array_equal(q[anchors],self.parent_data['robot_qpos_inferred'][anchors])
        np.testing.assert_array_equal(q[:,:,7:],self.parent_data['robot_qpos_inferred'][:,:,7:])
        if saved is not None:
            for key in ('gated_edge_parent_report_sha256','gated_edge_screen_sha256','edge_selections','fallback_report_sha256'):
                assert saved[key]==self.repair_report[key]
            data=load(proposal/'robot-motion-proposal.npz')
            for key in self.parent_data:
                if key.startswith('source_') or key in ('frame_indices','timestamps_s','robot_contact_intent_inferred','robot_contact_intent_bridge','robot_contact_intent_trailing_extension'):
                    np.testing.assert_array_equal(data[key],self.parent_data[key])
            np.testing.assert_array_equal(q,data['robot_qpos_inferred'])
            assert data['robot_pose_is_inferred'].all() and not data['robot_motion_target_validated'].any()
            self.repair_report=saved
        self.source_sample_maximum_error=0.

    def __getattr__(self,name):return getattr(self.parent,name)
    def evaluate(self,timestamp):return self.parent.evaluate(timestamp)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','parent-proposal','interval-inputs','atlas','base','probe','out'):
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args()
    assert not a.out.exists() and a.out.parent.resolve()==a.base.parent.resolve()==a.probe.parent.resolve()
    m=ClearanceGatedEdgeMotion(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,source=a.source,base=a.base,probe=a.probe)
    d={k:v.copy() for k,v in m.parent_data.items()}
    q,kinds,details=(np.asarray(v) for v in zip(*(m.evaluate(float(t)) for t in m.times)))
    d['robot_transition_translation_delta_m']+=q[:,:,:3]-d['robot_qpos_inferred'][:,:,:3]
    fallback_data=load(a.base.parent/m.repair_report['fallback_proposal']/'robot-motion-proposal.npz')
    changed=np.any(q!=fallback_data['robot_qpos_inferred'],axis=2)
    d['robot_edge_prior_changed']=changed
    d['robot_qpos_inferred']=q
    d['robot_pose_inference_kind']=kinds
    a.out.mkdir()
    payload=a.out/'robot-motion-proposal.npz'
    np.savez_compressed(payload,**d)
    report={**m.repair_report,'motion_module_sha256':sha(Path(__file__)), 'payload_sha256':sha(payload),
        'method':'whole_edge_robot_clearance_gate_over_bounded_retained_release',
        'all_grasp_anchors_and_finger_arrays_unchanged':True,'all_source_observation_arrays_unchanged':True,
        'annotations_or_GT_read':False,'physical_task_accepted':False,'new_simulator_run':False,
        'recovered_human_hands_promoted_to_robot_targets':False,'changed_hand_frame_count':int(changed.sum()),
        'edge_changed_flag_reference':'final state compared with bounded retained release'}
    (a.out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'edge_selections':m.selections,'physical_task_accepted':False}))


if __name__=='__main__':main()
