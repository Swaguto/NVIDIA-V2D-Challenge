"""Complete original robot triangle bounds on all inferred object-hold frames.

Canonical own-object geometry groups use a conservative metric bound covering
every source affine matrix in that group. Other-object scenes remain per-frame.
This remains a static object-attached hypothesis, not a full motion trajectory.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np

from exact_voxel_boundary_v1 import Boundary
from certify_uniform_metric_triangles_v1 import certify, controls as old_controls


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def material_box(boundary):
    occupied = np.argwhere(boundary.solid)
    return boundary.origin + (occupied.min(axis=0) - .5) * boundary.pitch, boundary.origin + (occupied.max(axis=0) + .5) * boundary.pitch


def mesh_certificate(boundary, box, triangles, matrix, metric_bounds=None,canonical_displacement_padding_m=0.,world_displacement_padding_m=0.):
    low, high = box
    assert 0<=canonical_displacement_padding_m and 0<=world_displacement_padding_m<.002
    low=low-canonical_displacement_padding_m;high=high+canonical_displacement_padding_m
    # A disjoint triangle AABB proves every original point is outside the
    # entire material-cell union. The small guard makes separation conservative.
    possible = (triangles.max(axis=1) >= low - 1e-10).all(axis=1) & (triangles.min(axis=1) <= high + 1e-10).all(axis=1)
    ids = np.flatnonzero(possible)
    if len(ids):
        result = certify(boundary, triangles[ids], matrix, limit=.002-world_displacement_padding_m,metric_singular_bounds=metric_bounds)
        if result['witness'] is not None:
            result['witness']['original_exported_robot_triangle_index'] = int(ids[result['witness']['original_triangle_index']])
        result['certificate_original_triangles'] = result['original_triangles']
    else:
        result = {'status': 'certified outside whole material AABB', 'triangle_material_limit_certified': True,
                  'maximum_signed_depth_witness_m': None, 'witness': None, 'remaining_subtriangles': 0,
                  'queries': 0, 'history': [], 'certificate_original_triangles': 0}
    result['original_exported_robot_triangles'] = len(triangles)
    result['canonical_displacement_padding_m']=canonical_displacement_padding_m
    result['world_displacement_padding_m']=world_displacement_padding_m
    result['reference_surface_limit_m']=.002-world_displacement_padding_m
    result['actual_family_surface_limit_m']=.002
    reference_witness=result['maximum_signed_depth_witness_m']
    result['maximum_reference_signed_depth_witness_m']=reference_witness
    result['minimum_corresponding_actual_family_depth_lower_m']=(None if reference_witness is None else reference_witness-world_displacement_padding_m)
    result['witness_coordinates_are_reference_canonical']=world_displacement_padding_m>0
    result['explicit_actual_family_intrusion_proven']=(reference_witness is not None and reference_witness-world_displacement_padding_m>.002)
    if not result['triangle_material_limit_certified'] and world_displacement_padding_m>0:
        result['status']=('failed: actual family depth lower bound exceeds limit' if result['explicit_actual_family_intrusion_proven'] else 'unresolved: tightened reference surface does not certify scaled family')
    result['aabb_separated_original_triangles'] = len(triangles) - len(ids)
    assert result['certificate_original_triangles'] + result['aabb_separated_original_triangles'] == len(triangles)
    return result


def controls():
    original = old_controls()
    box = Boundary(np.ones((1, 1, 1), dtype=bool), np.zeros(3), .02)
    bounds = material_box(box)
    crosses = np.array([[[-.025, -.025, 0.], [.025, -.025, 0.], [0., .05, 0.]]])
    failed = mesh_certificate(box, bounds, crosses, np.eye(3), (.8, 1.3))
    assert not failed['triangle_material_limit_certified']
    np.testing.assert_allclose(failed['maximum_signed_depth_witness_m'], .008, atol=1e-12)
    assert failed['aabb_separated_original_triangles'] == 0
    outside = np.array([[[1., 0, 0], [1.001, 0, 0], [1., .001, 0]]])
    separated = mesh_certificate(box, bounds, outside, np.eye(3), (.8, 1.3))
    assert separated['triangle_material_limit_certified'] and separated['aabb_separated_original_triangles'] == 1
    near = np.array([[[.0105, 0, 0], [.0105, .003, 0], [.0105, 0, .003]]])
    # Include the otherwise exterior near triangle in the conservative tested
    # box to exercise the metric-bound path, not only the AABB shortcut.
    expanded = (bounds[0] - .001, bounds[1] + .001)
    bounded = mesh_certificate(box, expanded, near, np.eye(3), (.8, 1.3))
    assert bounded['triangle_material_limit_certified'] and bounded['certificate_original_triangles'] == 1
    for angle in (.0, .43, -.77):
        rotation = np.array([[np.cos(angle), -np.sin(angle), 0], [np.sin(angle), np.cos(angle), 0], [0, 0, 1]])
        matrix = rotation @ np.diag([.8, .9, 1.3])
        actual = certify(box, near, matrix)
        assert actual['triangle_material_limit_certified']
        actual_failed = certify(box, crosses, matrix)
        assert not actual_failed['triangle_material_limit_certified']
    padding=float(np.linalg.norm(near.reshape(-1,3),axis=1).max())*.001
    family=mesh_certificate(box,expanded,near,np.eye(3),(.8,1.3),padding,1.3*padding)
    assert family['triangle_material_limit_certified']
    assert family['reference_surface_limit_m']<.002 and family['actual_family_surface_limit_m']==.002
    for ratio in (.999,1.,1.001):
        for angle in (0.,.43):
            rotation=np.array([[np.cos(angle),-np.sin(angle),0],[np.sin(angle),np.cos(angle),0],[0,0,1]])
            assert certify(box,near*ratio,rotation@np.diag([.8,.9,1.3]))['triangle_material_limit_certified']
    edge=np.array([[[.0101,0.,0.],[.0101,.001,0.],[.0101,0.,.001]]])
    edge_padding=float(np.linalg.norm(edge.reshape(-1,3),axis=1).max())*.03
    padded=mesh_certificate(box,bounds,edge,np.eye(3),(1.,1.),edge_padding,edge_padding)
    assert padded['aabb_separated_original_triangles']==0 and padded['certificate_original_triangles']==1
    assert padded['triangle_material_limit_certified']
    assert not mesh_certificate(box,bounds,crosses,np.eye(3),(.8,1.3),1e-7,1.3e-7)['triangle_material_limit_certified']
    almost=np.array([[[.00805,0.,0.],[.00805,1e-7,0.],[.00805,0.,1e-7]]])
    refused=mesh_certificate(box,bounds,almost,np.eye(3),(1.,1.),.0001,.0001)
    assert not refused['triangle_material_limit_certified']
    assert not refused['explicit_actual_family_intrusion_proven']
    assert refused['status'].startswith('unresolved:')
    assert refused['maximum_reference_signed_depth_witness_m']>.0019
    assert refused['minimum_corresponding_actual_family_depth_lower_m']<.002
    return {'reference_refusal_not_an_actual_family_intrusion_control':True,'scale_family_displacement_and_tightened_limit_controls':True,'aabb_expanded_for_possible_scale_displacement':True,
            'unsafe_triangle_family_refused':True,'original_controls': original, 'global_min_max_metric_bound_checks': True,
            'triangle_interior_crossing_not_hidden_by_aabb': True, 'complete_triangle_accounting': True,
            'rotated_affine_near_exterior_and_interior_controls': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('bundle', 'scenes', 'material', 'timing', 'vertex-audit', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    a = parser.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    tested = controls()
    bm = json.loads((a.bundle / 'manifest.json').read_text())
    scenes = json.loads((a.scenes / 'report.json').read_text())
    mm = json.loads((a.material / 'manifest.json').read_text())
    timing = json.loads((a.timing / 'report.json').read_text())
    vertices = json.loads((a.vertex_audit / 'report.json').read_text())
    bundle_hash = sha(a.bundle / 'manifest.json')
    assert scenes['bundle_manifest_sha256'] == timing['bundle_manifest_sha256'] == vertices['bundle_manifest_sha256'] == bundle_hash
    assert bm['payload']['sha256'] == mm['source_bundle_payload_sha256'] == sha(a.bundle / 'episode.npz')
    assert timing['payload_sha256'] == sha(a.timing / 'hold-hypotheses.npz')
    assert vertices['scene_report_sha256'] == sha(a.scenes / 'report.json')
    assert vertices['material_manifest_sha256'] == sha(a.material / 'manifest.json')
    assert vertices['timing_report_sha256'] == sha(a.timing / 'report.json')
    assert vertices['payload_sha256'] == sha(a.vertex_audit / 'hold-scene-vertex-bounds.npz')
    with np.load(a.bundle / 'episode.npz', allow_pickle=False) as archive:
        d = {k: archive[k] for k in archive.files}
    with np.load(a.timing / 'hold-hypotheses.npz', allow_pickle=False) as archive:
        h = {k: archive[k] for k in archive.files}
    for key, original in (('frame_indices', 'frame_indices'), ('source_hand_valid', 'hand_valid'), ('source_hand_directly_observed', 'hand_directly_observed')):
        np.testing.assert_array_equal(h[key], d[original])
    holds = h['inferred_hold_state'] > 0
    boundaries, boxes = {}, {}
    for entry in mm['objects']:
        path = a.material / f"object_{entry['object']}.npz"
        assert sha(path) == entry['payload_sha256']
        with np.load(path, allow_pickle=False) as archive:
            boundary = Boundary(archive['solid_cells'], archive['origin_m'], archive['pitch_m'])
        boundaries[entry['object']] = boundary
        boxes[entry['object']] = material_box(boundary)
    groups, records = [], []
    for scene in scenes['scenes']:
        si, oi = ('left', 'right').index(scene['side']), scene['object']
        payload = a.scenes / scene['payload_name']
        assert sha(payload) == scene['payload_sha256']
        with np.load(payload, allow_pickle=False) as archive:
            world_reference = archive['robot_vertices_world']
            faces = archive['robot_faces']
        reference = d[f'object_{oi}_world'][scene['source_row']]
        local_vertices = (world_reference - reference[:3, 3]) @ np.linalg.inv(reference[:3, :3]).T
        local_triangles = local_vertices[faces]
        rows = np.flatnonzero(holds[:, si, oi])
        scales = d[f'object_{oi}_scale'][rows]
        own_by_row = {}
        group_rows=rows
        scale=float(scales[0])
        matrices=d[f'object_{oi}_world'][group_rows,:3,:3]*scales[:,None,None]
        singular=np.linalg.svd(matrices,compute_uv=False)
        metric=(float(singular.min()),float(singular.max()))
        canonical=local_triangles/scale
        ratios=scale/scales
        maximum_ratio_difference=float(np.max(np.abs(ratios-1.)))
        maximum_reference_vertex_norm=float(np.linalg.norm(canonical.reshape(-1,3),axis=1).max())
        canonical_padding=maximum_reference_vertex_norm*maximum_ratio_difference
        world_padding=metric[1]*canonical_padding
        result=mesh_certificate(boundaries[oi],boxes[oi],canonical,np.eye(3),metric,canonical_padding,world_padding)
        group={'side':scene['side'],'object':oi,'seed':scene['seed'],'reference_source_scale':scale,
               'source_scale_min':float(scales.min()),'source_scale_max':float(scales.max()),
               'every_original_source_scale_retained':True,'source_frames':d['frame_indices'][group_rows].tolist(),
               'metric_singular_value_bounds_covering_every_group_frame':list(metric),
               'maximum_reference_canonical_vertex_norm_m':maximum_reference_vertex_norm,
               'maximum_canonical_scale_ratio_difference':maximum_ratio_difference,
               'canonical_triangles_same_by_object_attachment_definition':False,
               'actual_canonical_family':'reference canonical triangles multiplied by original reference_scale/frame_scale',
               'family_bound':'signed distance is1-Lipschitz; maximum point displacement bounded by maximum reference vertex norm times maximum scale-ratio difference, then maximum world singular value; reference certificate uses a tighter limit',
               'world_radius_bound_uses_maximum_singular_value':True,
               'group_source_frame_count':len(group_rows),**result,'physical_task_accepted':False}
        groups.append(group)
        for row in group_rows:own_by_row[int(row)]=len(groups)-1
        for row in rows:
            frame = int(d['frame_indices'][row])
            parent = d[f'object_{oi}_world'][row]
            world = local_triangles @ parent[:3, :3].T + parent[:3, 3]
            for other, boundary in boundaries.items():
                pose = d[f'object_{other}_world'][row]
                scale = float(d[f'object_{other}_scale'][row])
                matrix = pose[:3, :3] * scale
                provenance = bm['object_observation_provenance'][bm['objects'][other]['name']][str(frame)]
                if other == oi:
                    group = groups[own_by_row[int(row)]]
                    result = {k: v for k, v in group.items() if k not in ('source_frames', 'side', 'object', 'seed', 'source_scale', 'physical_task_accepted')}
                    result['own_object_group_index'] = own_by_row[int(row)]
                else:
                    canonical = np.einsum('ij,pkj->pki', np.linalg.inv(matrix), world - pose[:3, 3])
                    result = mesh_certificate(boundary, boxes[other], canonical, matrix)
                records.append({'side': scene['side'], 'attached_object': oi, 'against_object': other, 'seed': scene['seed'],
                                'source_frame': frame, 'against_object_pose_provenance': provenance,
                                **result, 'physical_task_accepted': False})
            if len(records) % 50 == 0:
                print(json.dumps({'side': scene['side'], 'source_frame': frame, 'complete_material_scene_checks': len(records), 'elapsed_seconds': time.monotonic() - started}), flush=True)
    assert len(records) == int(holds.sum()) * len(boundaries)
    summaries = []
    for scene in scenes['scenes']:
        for other in boundaries:
            selected = [v for v in records if v['side'] == scene['side'] and v['attached_object'] == scene['object'] and v['against_object'] == other]
            summaries.append({'side': scene['side'], 'attached_object': scene['object'], 'against_object': other,
                              'inferred_hold_frames_checked': len(selected),
                              'all_original_triangle_limits_certified': all(v['triangle_material_limit_certified'] for v in selected),
                              'failed_source_frames': [v['source_frame'] for v in selected if not v['triangle_material_limit_certified']],
                              'unobserved_against_object_source_frames': [v['source_frame'] for v in selected if v['against_object_pose_provenance'] != 'observed'],
                              'maximum_interior_depth_witness_m': max([0.] + [v['maximum_signed_depth_witness_m'] for v in selected if v['maximum_signed_depth_witness_m'] is not None]),
                              'physical_task_accepted': False})
    a.out.mkdir(parents=True)
    report = {'source_sha256': sha(Path(__file__)), 'metric_triangle_module_sha256': sha(Path(__file__).parent / 'certify_uniform_metric_triangles_v1.py'),
              'boundary_module_sha256': sha(Path(__file__).parent / 'exact_voxel_boundary_v1.py'),
              'bundle_manifest_sha256': bundle_hash, 'scene_report_sha256': sha(a.scenes / 'report.json'),
              'material_manifest_sha256': sha(a.material / 'manifest.json'), 'timing_report_sha256': sha(a.timing / 'report.json'),
              'vertex_and_cross_hand_audit_sha256': sha(a.vertex_audit / 'report.json'), 'controls': tested,
              'source_frames_retained': len(d['frame_indices']), 'inferred_hand_object_hold_frames_checked': int(holds.sum()),
              'complete_material_scene_checks': len(records), 'declared_material_surface_limit_m': .002,
              'own_object_sequence_certificate_groups': groups, 'summaries': summaries, 'frames': records,
              'all_original_surface_limits_certified_on_inferred_holds': all(v['triangle_material_limit_certified'] for v in records),
              'cross_hand_intersection_source_frames': vertices['cross_hand_intersection_source_frames'],
              'elapsed_seconds': time.monotonic() - started, 'original_source_observations_modified': False,
              'full_inferred_hold_surface_hypothesis_only': True, 'table_environment_or_solid_volume_checked': False,
              'approach_release_or_observation_gaps_generated': False, 'continuous_motion_checked': False,
              'new_simulator_run': False, 'contact_known': False, 'physical_task_accepted': False}
    (a.out / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'summaries': summaries, 'all_inferred_hold_surfaces_certified': report['all_original_surface_limits_certified_on_inferred_holds'],
                      'elapsed_seconds': report['elapsed_seconds'], 'physical_task_accepted': False}), flush=True)


if __name__ == '__main__':
    main()
