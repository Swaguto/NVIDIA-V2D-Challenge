"""Current-image-supported entry/exit priors; never promote source validity.

Uses the existing Track 3 mirrored-MANO convention and the median calibrated
root/wrist offset from the original retarget. Only times outside the first/last
original reliable observations are affected. No episode frame/crop choices,
contact annotations or ground truth are used. This remains an inferred replay.
"""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
from scipy.spatial.transform import Rotation

from repaired_retained_release_motion_v4 import RepairedReleaseMotion
from corrected_per_grasp_motion_v1 import load, sha
from propose_robot_contact_motion_v1 import blend,smooth


class ImageSupportedEdgeMotion(RepairedReleaseMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas,
                 proposal=None, *, repaired=None, quality=None, source=None):
        saved = None
        if proposal is not None:
            saved = json.loads((proposal/'report.json').read_text())
            assert saved['motion_module_sha256'] == sha(Path(__file__))
            assert saved['payload_sha256'] == sha(proposal/'robot-motion-proposal.npz')
            assert saved['physical_task_accepted'] is False
            repaired = proposal.parent/saved['base_repaired_proposal']
            quality = proposal.parent/saved['hand_quality_proposal']
        assert repaired is not None and quality is not None and source is not None
        super().__init__(bundle, baseline, parent_proposal, interval_inputs, atlas, repaired)
        self.edge_parent_data = load(repaired/'robot-motion-proposal.npz')
        self.edge_parent_report = self.repair_report.copy()
        receipt = json.loads((quality/'run-receipt.json').read_text())
        assert receipt['status'] == 'completed_consistency_checks_proposals_unaccepted'
        assert receipt['quality_accepted'] is False and receipt['physical_task_accepted'] is False
        assert receipt['effective_method_unchanged_during_run']
        assert receipt['frame_evidence_sha256'] == sha(quality/'frame-evidence.json')
        assert receipt['geometry_export_verification_sha256'] == sha(quality/'geometry-export-verification.json')
        verified = json.loads((quality/'geometry-export-verification.json').read_text())
        # The verification receipt binds every native export and checked mesh.
        if isinstance(verified,dict): verified = verified['exports']
        verification = {(v['side'],v['frame']):v for v in verified}
        records = {}
        for path in (quality/'accepted/records').glob('*/*.json'):
            record = json.loads(path.read_text())
            identity = ('right' if record['is_right'] else 'left',int(record['frame_idx']))
            assert identity not in records
            records[identity] = path
        sys.path.insert(0,str(source/'source/robotic_grounding'))
        from robotic_grounding.retarget.track3_bundle import wrist_rotation
        from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
        mapping_path = source/'source/robotic_grounding/robotic_grounding/retarget/track3_bundle.py'
        retarget = load(baseline/'retarget.npz')
        self.edge_evidence = []
        for si,side in enumerate(('left','right')):
            reliable = retarget['robot_valid'][:,si] & self.source['hand_directly_observed'][:,si]
            reliable_rows = np.flatnonzero(reliable)
            assert len(reliable_rows)
            original = self.free_priors[si].copy()
            target = original.copy()
            supported = reliable.copy()
            q = retarget['robot_qpos'][reliable,si]
            wrists = self.source['hand_joints_world'][reliable,si,0]
            offsets = Rotation.from_quat(q[:,3:7]).inv().apply(q[:,:3]-wrists)
            offset = np.median(offsets,axis=0)
            correction = setup_dex3_kinematics(side=side,max_iter=1).get_frame_rotation_correction(f'{side}_hand_palm_link')
            rows = []
            for row,frame in enumerate(self.source['frame_indices']):
                # No changes inside the original observed span, including gaps.
                if reliable_rows[0] <= row <= reliable_rows[-1]: continue
                path = quality/f'geometry/{side}/{int(frame):06d}.npz'
                record_path = records.get((side,int(frame)))
                if not path.exists() or record_path is None: continue
                g = load(path)
                if not bool(g['accepted']): continue
                record = json.loads(record_path.read_text())
                assert record['directly_observed'] is True and record['geometry_export_verified'] is True
                assert record['quality_accepted'] is False and record['physical_task_accepted'] is False
                v = verification[(side,int(frame))]
                assert v['geometry_sha256'] == sha(path)
                assert v['record_sha256'] == sha(record_path)
                camera = self.source['camera_c2w'][row]
                wrist = camera[:3,:3] @ g['joints'][0] + camera[:3,3]
                rotation = camera[:3,:3] @ wrist_rotation(record,side) @ (np.eye(3) if side=='left' else correction)
                target[row,:3] = wrist + rotation @ offset
                target[row,3:7] = Rotation.from_matrix(rotation).as_quat()
                supported[row] = True
                rows.append(int(frame))
            # Interpolate only each unobserved edge; clamp beyond the available
            # current-image support and label that state as inferred/display-only.
            support_rows = np.flatnonzero(supported)
            for row in list(range(reliable_rows[0]))+list(range(reliable_rows[-1]+1,len(self.times))):
                hi = int(np.searchsorted(support_rows,row))
                if hi == 0: target[row,:7] = target[support_rows[0],:7]
                elif hi == len(support_rows): target[row,:7] = target[support_rows[-1],:7]
                else:
                    lo,up = support_rows[hi-1:hi+1]
                    fraction = (self.times[row]-self.times[lo])/(self.times[up]-self.times[lo])
                    target[row,:7] = blend(target[lo],target[up],fraction)[:7]

            handoff = max(.5,float(self.free_blend))
            for row in list(range(reliable_rows[0]))+list(range(reliable_rows[-1]+1,len(self.times))):
                edge_time = self.times[reliable_rows[0] if row<reliable_rows[0] else reliable_rows[-1]]
                gate = float(smooth(abs(self.times[row]-edge_time)/handoff))
                target[row,:7] = blend(original[row],target[row],gate)[:7]
            target[:,7:] = original[:,7:]
            np.testing.assert_array_equal(target[reliable_rows[0]:reliable_rows[-1]+1],original[reliable_rows[0]:reliable_rows[-1]+1])
            self.free_priors[si] = target
            self.edge_evidence.append({'side':side,'current_image_supported_edge_frames':rows,
                'original_reliable_edge_frames':[int(self.source['frame_indices'][r]) for r in reliable_rows[[0,-1]]],
                'median_root_to_wrist_local_offset_m':offset.tolist(),
                'calibration_offset_p95_spread_m':float(np.percentile(np.linalg.norm(offsets-offset,axis=1),95)),
                'supported_mask':supported.tolist(),'edge_handoff_duration_s':handoff})
        self.edge_input_locks = {'base_repaired_report_sha256':sha(repaired/'report.json'),
            'hand_quality_receipt_sha256':sha(quality/'run-receipt.json'),
            'track3_wrist_mapping_sha256':sha(mapping_path)}
        q = np.array([self.evaluate(float(t))[0] for t in self.times])
        anchors = self.edge_parent_data['robot_contact_intent_inferred'].any(axis=2)
        np.testing.assert_array_equal(q[anchors],self.edge_parent_data['robot_qpos_inferred'][anchors])
        np.testing.assert_array_equal(q[:,:,7:],self.edge_parent_data['robot_qpos_inferred'][:,:,7:])
        if saved is not None:
            for k,v in self.edge_input_locks.items(): assert saved[k] == v
            assert saved['edge_support'] == self.edge_evidence
            data = load(proposal/'robot-motion-proposal.npz')
            for key in self.edge_parent_data:
                if key.startswith('source_') or key in ('frame_indices','timestamps_s','robot_contact_intent_inferred','robot_contact_intent_bridge','robot_contact_intent_trailing_extension'):
                    np.testing.assert_array_equal(data[key],self.edge_parent_data[key])
            assert data['robot_pose_is_inferred'].all() and not data['robot_motion_target_validated'].any()
            np.testing.assert_array_equal(q,data['robot_qpos_inferred'])
            self.repair_report = saved
        self.source_sample_maximum_error = 0.


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','parent-proposal','interval-inputs','atlas','repaired','quality','out'):
        p.add_argument('--'+name,type=Path,required=True)
    a = p.parse_args()
    assert not a.out.exists() and a.out.parent.resolve() == a.repaired.parent.resolve() == a.quality.parent.resolve()
    motion = ImageSupportedEdgeMotion(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,
        repaired=a.repaired,quality=a.quality,source=a.source)
    data = {k:v.copy() for k,v in motion.edge_parent_data.items()}
    q,kinds,details = (np.asarray(v) for v in zip(*(motion.evaluate(float(t)) for t in motion.times)))
    changed = np.any(q != data['robot_qpos_inferred'],axis=2)
    displacement = q[:,:,:3]-data['robot_qpos_inferred'][:,:,:3]
    data['robot_transition_translation_delta_m'] += displacement
    data['robot_qpos_inferred'] = q
    data['robot_pose_inference_kind'] = kinds
    data['robot_edge_prior_changed'] = changed
    a.out.mkdir(parents=True)
    payload = a.out/'robot-motion-proposal.npz'
    np.savez_compressed(payload,**data)
    report = {**motion.edge_parent_report,**motion.edge_input_locks,
        'motion_module_sha256':sha(Path(__file__)),'payload_sha256':sha(payload),
        'base_repaired_proposal':a.repaired.name,'hand_quality_proposal':a.quality.name,
        'edge_support':motion.edge_evidence,'changed_hand_frame_count':int(changed.sum()),
        'current_image_proposals_promoted_to_source_observations':False,
        'all_grasp_anchors_and_finger_arrays_unchanged':True,'annotations_or_GT_read':False,
        'physical_task_accepted':False,'new_simulator_run':False,
        'method':'regularized_image_supported_edges_over_bounded_retained_release'}
    (a.out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'changed_hand_frames':int(changed.sum()),'supported_edge_frames':[len(v['current_image_supported_edge_frames']) for v in motion.edge_evidence],'physical_task_accepted':False}))


if __name__ == '__main__': main()
