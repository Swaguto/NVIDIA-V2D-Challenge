"""Screen inferred release alignment against locked full-scene vertices.

Choose the largest feasible retained anchor transform on a fixed global grid.
If none passes the finite vertex screen, record the least violating candidate
and refuse to mark it accepted. Original triangle certificates are still needed.
No source annotations, episode frame choices or recovered observations are used
as optimization targets or modified.
"""
import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np
import pinocchio as pin
import trimesh
from scipy.spatial.transform import Rotation

from source_following_release_motion_v5 import SourceFollowingMotion
from corrected_per_grasp_motion_v1 import load, sha


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("source", "bundle", "baseline", "parent-proposal", "interval-inputs",
                 "atlas", "proposal", "material", "out"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    motion = SourceFollowingMotion(a.bundle, a.baseline, a.parent_proposal,
                                   a.interval_inputs, a.atlas, a.proposal)
    report = motion.repair_report
    mm = json.loads((a.material / "manifest.json").read_text())
    assert report["material_manifest_sha256"] == sha(a.material / "manifest.json")
    assert mm["source_bundle_payload_sha256"] == sha(a.bundle / "episode.npz")
    sys.path.insert(0, str(a.source / "source/robotic_grounding"))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    from robotic_grounding.retarget.track3_collision_voxels import solid_depth_bounds
    verify_robot_assets(report, a.source / "source/robotic_grounding/robotic_grounding/assets")
    materials = {}
    for entry in mm["objects"]:
        path = a.material / f"object_{entry['object']}.npz"
        assert sha(path) == entry["payload_sha256"]
        materials[entry["object"]] = load(path)
    dense_times = np.unique(np.r_[motion.breakpoints,
                                  (motion.breakpoints[:-1] + motion.breakpoints[1:]) / 2])
    probe_times = np.unique(np.r_[dense_times, (dense_times[:-1] + dense_times[1:]) / 2])
    records = []
    for si, side in enumerate(motion.sides):
        kin = setup_dex3_kinematics(side=side["side"], max_iter=1)
        geom = kin.robot.collision_model
        gd = geom.createData()
        points = []
        for obj in geom.geometryObjects:
            mesh = trimesh.load(Path(obj.meshPath), force="mesh", process=False)
            v = np.unique(np.asarray(mesh.vertices, dtype=float), axis=0)
            points.append(v * np.asarray(obj.meshScale))
        for phase in side["phases"]:
            prefix = phase["prefix"]
            last = phase["interval"][1]
            end = min(motion.times[-1], last + max(phase["duration_s"], phase["release_duration_s"]) + motion.free_blend)
            times = probe_times[(probe_times > last) & (probe_times <= end)]
            assert len(times)
            transforms = {}
            for t in times:
                poses = {}
                for oi in materials:
                    rotation, translation, scale = motion.object_pose(oi, float(t))
                    matrix = rotation * scale
                    poses[oi] = (translation, np.linalg.inv(matrix),
                                 float(np.linalg.svd(matrix, compute_uv=False).min()))
                transforms[float(t)] = poses
            original_offset = {k: v.copy() for k, v in motion.morphology_offsets[prefix].items()}
            trials = []
            for alpha in np.linspace(0., 1., 21):
                motion.morphology_offsets[prefix] = {
                    "source_prior_local_translation_m": original_offset["source_prior_local_translation_m"] * alpha,
                    "source_prior_relative_rotation_xyzw": Rotation.from_rotvec(
                        Rotation.from_quat(original_offset["source_prior_relative_rotation_xyzw"]).as_rotvec() * alpha).as_quat()}
                max_lower = 0.
                sum_hinge = 0.
                failures = 0
                worst = None
                for t in times:
                    q = motion.evaluate(float(t))[0][si]
                    kin.configuration.update(q)
                    pin.updateGeometryPlacements(kin.robot.model, kin.configuration.data, geom, gd, q)
                    world = np.concatenate([v @ tf.rotation.T + tf.translation for v, tf in zip(points, gd.oMg)])
                    for oi, grid in materials.items():
                        translation, inverse, smin = transforms[float(t)][oi]
                        local = (world - translation) @ inverse.T
                        lower, _, _ = solid_depth_bounds(local, grid["solid_cells"],
                            grid["empty_center_distance_m"], grid["origin_m"], float(grid["pitch_m"]))
                        depth = max(0., float(lower.max()) * smin)
                        if depth > max_lower:
                            max_lower = depth
                            worst = {"timestamp_s": float(t), "object": oi}
                        failures += int(depth > .002)
                        sum_hinge += max(0., depth - .002)**2
                trials.append({"alignment_retention": float(alpha), "maximum_vertex_depth_lower_m": max_lower,
                               "finite_explicit_failure_count": failures,
                               "squared_excess_depth_sum_m2": sum_hinge, "worst_witness": worst})
            feasible = [i for i, v in enumerate(trials) if v["finite_explicit_failure_count"] == 0]
            selected = max(feasible, key=lambda i: trials[i]["alignment_retention"]) if feasible else min(
                range(len(trials)), key=lambda i: (trials[i]["maximum_vertex_depth_lower_m"],
                    trials[i]["squared_excess_depth_sum_m2"], -trials[i]["alignment_retention"]))
            motion.morphology_offsets[prefix] = original_offset
            records.append({"prefix": prefix, "side": side["side"], "interval_s": list(phase["interval"]),
                            "probe_times": len(times), "selected_index": selected,
                            "selected_retention": trials[selected]["alignment_retention"],
                            "finite_screen_found_feasible_retention": bool(feasible), "trials": trials})
            print(json.dumps({"prefix": prefix, "selected": records[-1]["selected_retention"],
                              "finite_screen_feasible": bool(feasible),
                              "maximum_depth_lower_m": trials[selected]["maximum_vertex_depth_lower_m"],
                              "elapsed_seconds": time.monotonic() - started}), flush=True)
    result = {
        "source_sha256": sha(Path(__file__)),
        "motion_module_sha256": sha(Path(__file__).with_name("source_following_release_motion_v5.py")),
        "proposal_report_sha256": sha(a.proposal / "report.json"),
        "bundle_manifest_sha256": sha(a.bundle / "manifest.json"),
        "material_manifest_sha256": sha(a.material / "manifest.json"),
        "global_retention_grid": np.linspace(0., 1., 21).tolist(),
        "selection_rule": "largest retained fitted transform among finite-screen feasible; otherwise minimum maximum lower depth, squared excess and then largest retention",
        "maximum_allowed_material_depth_m": .002,
        "grasps": records,
        "all_finite_screens_found_feasible_retention": all(v["finite_screen_found_feasible_retention"] for v in records),
        "original_triangle_surfaces_certified": False,
        "continuous_scene_clearance_certified": False,
        "source_hand_pose_accuracy_accepted": False,
        "annotations_or_GT_read": False,
        "source_observations_modified": False,
        "episode_specific_frames_or_crops": False,
        "new_simulator_run": False,
        "physical_task_accepted": False,
        "elapsed_seconds": time.monotonic() - started}
    a.out.mkdir(parents=True)
    (a.out / "report.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
