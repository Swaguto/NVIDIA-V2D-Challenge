"""Couple the existing translation objective across one automatic source gap.

One vector serves all witness times, multiplied by their smooth window weights.
Independent original-triangle certificates still determine static rejection.
"""
import itertools
import numpy as np
from scipy.optimize import minimize
from scipy.spatial.transform import Rotation

from fit_dex3_source_grasp_v14 import trilinear
from audit_static_hold_scene_triangles_v3 import mesh_certificate


def solve_translation(contexts, materials, reserve=.0005, maximum_norm_m=.010):
    assert contexts and 0 < reserve <= .001 and maximum_norm_m == .010
    cuts = [[] for _ in contexts]
    cache, gradient_errors = {}, []
    for context in contexts:
        weight = context['weight']
        assert 0 < weight <= 1.
        for oi, (field, _, pitch, _, _) in materials.items():
            coords = np.array([[3.13, 5.72, 7.38], [8.37, 9.16, 4.61]])
            _, grad = trilinear(field, coords)
            inverse = context['poses'][oi][2]
            analytic = grad @ inverse / pitch * .001 * weight
            for axis in range(3):
                step = .00001
                dc = inverse[:, axis] * .001 * weight / pitch * step
                numeric = (trilinear(field, coords+dc)[0] - trilinear(field, coords-dc)[0]) / (2*step)
                error = float(abs(numeric-analytic[:, axis]).max())
                assert error < 1e-7
                gradient_errors.append(error)

    def evaluate(x):
        if 'x' in cache and np.array_equal(x, cache['x']):
            return cache['value'], cache['gradient']
        values, gradients = [], []
        for ci, context in enumerate(contexts):
            weight = context['weight']
            points = np.concatenate([context['world']] + cuts[ci]) + x[None, :] * .001 * weight
            for oi, (field, origin, pitch, _, _) in materials.items():
                translation, matrix, inverse = context['poses'][oi]
                coords = ((points-translation) @ inverse.T - origin) / pitch
                value, gradient = trilinear(field, coords)
                smax = float(np.linalg.svd(matrix, compute_uv=False).max())
                # The old solver demanded a positive 1 mm gap everywhere.
                # Use the same world depth limit as the triangle certificate,
                # reserving only a weight-scaled correction neighborhood.
                values.append((value*smax+.002-(reserve+.0001)*weight)*1000.)
                gradients.append(gradient @ inverse / pitch * weight*smax)
        cache.update(x=x.copy(), value=np.concatenate(values), gradient=np.concatenate(gradients))
        return cache['value'], cache['gradient']

    source_axes = Rotation.from_matrix(contexts[0]['poses'][min(materials)][1]).as_matrix()
    directions = np.array([v for v in itertools.product((-1., 0., 1.), repeat=3) if any(v)])
    directions /= np.linalg.norm(directions, axis=1)[:, None]
    directions = directions @ source_axes.T
    seeds = [np.zeros(3)] + [r*d for r in (1., 2., 4., 8., 10.) for d in directions]
    seed_records = []
    for seed in seeds:
        margin = evaluate(seed)[0]
        seed_records.append({'translation_mm': seed.tolist(), 'minimum_proxy_margin_mm': float(margin.min()),
                             'squared_hinge_sum_mm2': float(np.maximum(-margin, 0.) @ np.maximum(-margin, 0.))})
    feasible = [i for i, v in enumerate(seed_records) if v['minimum_proxy_margin_mm'] >= -1e-6]
    selected = (min(feasible, key=lambda i: (float(seeds[i] @ seeds[i]), i)) if feasible else
                min(range(len(seeds)), key=lambda i: (seed_records[i]['squared_hinge_sum_mm2'], float(seeds[i] @ seeds[i]), i)))
    x = seeds[selected].copy()
    history = []
    for cycle in range(6):
        cache.clear()
        if float(evaluate(x)[0].min()) < -1e-6 or np.linalg.norm(x) > 1e-6:
            result = minimize(lambda y: .5*(y @ y), x, jac=lambda y: y, bounds=[(-10., 10.)]*3,
                              constraints=[{'type':'ineq', 'fun':lambda y:evaluate(y)[0], 'jac':lambda y:evaluate(y)[1]},
                                           {'type':'ineq', 'fun':lambda y:(maximum_norm_m*1000.)**2-y@y,
                                            'jac':lambda y:-2*y}],
                              method='SLSQP', options={'maxiter':120, 'ftol':1e-9})
            x = result.x
            solver = {'success':bool(result.success), 'message':str(result.message), 'iterations':int(result.nit),
                      'maximum_translation_norm_m':maximum_norm_m, 'world_depth_limit_m':.002,
                      'search_uses_interpolated_SDF_not_a_distance_certificate':True,
                      'additional_certificate_search_headroom_m':.0001}
        else:
            solver = {'success':True, 'message':'all proxy constraints satisfied', 'iterations':0}
        certificates, newcuts = [], [[] for _ in contexts]
        for ci, context in enumerate(contexts):
            weight = context['weight']
            for oi, (_, _, _, boundary, box) in materials.items():
                translation, matrix, inverse = context['poses'][oi]
                triangles = context['triangles_loader']() if 'triangles_loader' in context else context['triangles']
                canonical = (triangles + x[None, None, :]*.001*weight - translation) @ inverse.T
                padding = reserve * weight
                smin = float(np.linalg.svd(matrix, compute_uv=False).min())
                certificate = mesh_certificate(boundary, box, canonical, matrix,
                                               canonical_displacement_padding_m=padding/smin,
                                               world_displacement_padding_m=padding)
                certificates.append({'context':ci, 'against_object':oi, **certificate})
                if not certificate['triangle_material_limit_certified'] and certificate['witness'] is not None:
                    world = np.array(certificate['witness']['point_object_local_m']) @ matrix.T + translation
                    newcuts[ci].append((world-x*.001*weight)[None, :])
        history.append({'cycle':cycle, 'solver':solver, 'translation_amplitude_m':(x*.001).tolist(),
                        'minimum_proxy_margin_mm':float(evaluate(x)[0].min()), 'original_surface_certificates':certificates})
        passed = all(v['triangle_material_limit_certified'] for v in certificates) and np.linalg.norm(x)*.001 <= maximum_norm_m+1e-12
        if passed or cycle == 5 or not any(newcuts):
            break
        for ci, additions in enumerate(newcuts):
            cuts[ci].extend(additions)
    assert np.linalg.norm(x)*.001 <= maximum_norm_m+1e-10, "Translation norm guard violated"
    return x*.001, history, seed_records, selected, sum(map(len, cuts)), passed, max(gradient_errors)
