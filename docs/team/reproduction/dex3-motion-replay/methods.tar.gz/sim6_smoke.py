"""Check actual RTX renderer startup before adapting the full replay."""
import json
import importlib.metadata
from pathlib import Path
from isaacsim import SimulationApp

app=SimulationApp({'headless':True,'width':640,'height':480})
try:
    import omni.usd
    from pxr import UsdGeom
    stage=omni.usd.get_context().get_stage()
    UsdGeom.Cube.Define(stage,'/World/TestCube')
    for _ in range(20):app.update()
    Path(__file__).with_name('sim6-smoke-complete.json').write_text(json.dumps({
        'isaacsim':importlib.metadata.version('isaacsim'),
        'status':'startup_and_updates_completed','updates':20,
        'full_replay_verified':False},indent=2))
finally:
    app.close()
