"""All-frame declared-material vertex bounds for object-attached grasp hypotheses.

This is not a generated approach/release trajectory, a surface certificate or
source hand repair. Original observation masks and inferred hold states persist.
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import coal
import numpy as np


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def model(vertices, faces):
    assert vertices.ndim == 2 and vertices.shape[1] == 3 and np.isfinite(vertices).all()
    assert faces.ndim == 2 and faces.shape[1] == 3
    assert faces.min() >= 0 and faces.max() < len(vertices)
    points = coal.StdVec_Vec3s()
    points.extend(np.asarray(vertices, dtype=float))
    triangles = coal.StdVec_Triangle()
    for face in faces:
        triangles.append(coal.Triangle(int(face[0]), int(face[1]), int(face[2])))
    geometry = coal.BVHModelOBBRSS()
    assert geometry.beginModel(len(faces), len(vertices)) == 0
    assert geometry.addSubModel(points, triangles) == 0
    assert geometry.endModel() == 0
    assert geometry.num_tris == len(faces) and geometry.num_vertices == len(vertices)
    return geometry


def cross_hand(first, second):
    request = coal.CollisionRequest()
    request.enable_contact = True
    request.num_max_contacts = 100
    result = coal.CollisionResult()
    identity = coal.Transform3s(np.eye(3), np.zeros(3))
    coal.collide(first, identity, second, identity, request, result)
    contacts = result.getContacts()
    return {'original_triangle_surface_intersection': bool(result.isCollision()),
            'returned_contacts': len(contacts), 'contact_limit_reached': len(contacts) == 100,
            'triangle_contact_distance_min_m': min((float(v.penetration_depth) for v in contacts), default=None)}


def controls():
    first = model(np.array([[-.01, -.01, 0.], [.01, -.01, 0.], [0., .01, 0.]]), np.array([[0, 1, 2]]))
    second_vertices = np.array([[0., -.005, -.01], [0., -.005, .01], [0., .005, 0.]])
    crossed = cross_hand(first, model(second_vertices, np.array([[0, 1, 2]])))
    assert crossed['original_triangle_surface_intersection'] and crossed['returned_contacts'] > 0
    separated = cross_hand(first, model(second_vertices + [.1, 0, 0], np.array([[0, 1, 2]])))
    assert not separated['original_triangle_surface_intersection']
    return {'original_triangle_crossing_detected': True, 'separated_original_triangles_refused': True,
            'all_mesh_vertices_and_triangles_loaded': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'bundle', 'scenes', 'material', 'timing', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    a = parser.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    tested = controls()
    bm = json.loads((a.bundle / 'manifest.json').read_text())
    scenes = json.loads((a.scenes / 'report.json').read_text())
    mm = json.loads((a.material / 'manifest.json').read_text())
    timing = json.loads((a.timing / 'report.json').read_text())
    bundle_hash = sha(a.bundle / 'manifest.json')
    assert scenes['bundle_manifest_sha256'] == timing['bundle_manifest_sha256'] == bundle_hash
    assert bm['payload']['sha256'] == mm['source_bundle_payload_sha256'] == sha(a.bundle / 'episode.npz')
    assert timing['payload_sha256'] == sha(a.timing / 'hold-hypotheses.npz')
    sys.path.insert(0, str(a.source / 'source/robotic_grounding'))
    from robotic_grounding.retarget.track3_collision_voxels import solid_depth_bounds
    import robotic_grounding.retarget.track3_collision_voxels as voxel_module
    with np.load(a.bundle / 'episode.npz', allow_pickle=False) as archive:
        d = {k: archive[k] for k in archive.files}
    with np.load(a.timing / 'hold-hypotheses.npz', allow_pickle=False) as archive:
        h = {k: archive[k] for k in archive.files}
    for key, original in (('frame_indices', 'frame_indices'), ('source_hand_valid', 'hand_valid'), ('source_hand_directly_observed', 'hand_directly_observed')):
        np.testing.assert_array_equal(h[key], d[original])
    observed = np.array([[bm['object_observation_provenance'][obj['name']][str(int(frame))] == 'observed' for obj in bm['objects']] for frame in d['frame_indices']])
    np.testing.assert_array_equal(observed, h['source_object_observed'])
    holds = h['inferred_hold_state'] > 0
    assert np.all(holds.sum(axis=2) <= 1), 'Ambiguous same-hand object assignment needs a separate hypothesis'
    assert not np.any(holds & ~(d['hand_valid'][:, :, None] & d['hand_directly_observed'][:, :, None] & observed[:, None, :]))
    geometries = {}
    geometry_records = []
    for scene in scenes['scenes']:
        si, oi = ('left', 'right').index(scene['side']), scene['object']
        assert scene['every_intended_contact_proxy_passed']
        payload = a.scenes / scene['payload_name']
        assert sha(payload) == scene['payload_sha256']
        with np.load(payload, allow_pickle=False) as archive:
            vertices, faces = archive['robot_vertices_world'], archive['robot_faces']
        reference = d[f'object_{oi}_world'][scene['source_row']]
        local = (vertices - reference[:3, 3]) @ np.linalg.inv(reference[:3, :3]).T
        np.testing.assert_allclose(local @ reference[:3, :3].T + reference[:3, 3], vertices, atol=1e-12, rtol=0)
        geometries[(si, oi)] = (local, faces, scene['seed'])
        geometry_records.append({'side': scene['side'], 'object': oi, 'seed': scene['seed'],
                                 'original_exported_vertices': len(vertices), 'original_exported_triangles': len(faces),
                                 'scene_payload_sha256': scene['payload_sha256']})
    assert all((si, oi) in geometries for si, oi in np.argwhere(holds.any(axis=0)))
    grids = {}
    for entry in mm['objects']:
        path = a.material / f"object_{entry['object']}.npz"
        assert sha(path) == entry['payload_sha256']
        with np.load(path, allow_pickle=False) as archive:
            grids[entry['object']] = {k: archive[k] for k in archive.files}
    n, hands, objects = holds.shape
    lower_max = np.full((n, hands, objects), np.nan)
    upper_max = np.full_like(lower_max, np.nan)
    records, cross_records = [], []
    for row, frame_value in enumerate(d['frame_indices']):
        frame = int(frame_value)
        world_meshes = {}
        for si, oi in np.argwhere(holds[row]):
            local, faces, seed = geometries[(int(si), int(oi))]
            parent = d[f'object_{oi}_world'][row]
            world = local @ parent[:3, :3].T + parent[:3, 3]
            world_meshes[int(si)] = (world, faces)
            for other, grid in grids.items():
                pose = d[f'object_{other}_world'][row]
                matrix = pose[:3, :3] * float(d[f'object_{other}_scale'][row])
                singular = np.linalg.svd(matrix, compute_uv=False)
                assert singular.min() > 0
                points = (world - pose[:3, 3]) @ np.linalg.inv(matrix).T
                lower, upper, inside = solid_depth_bounds(points, grid['solid_cells'], grid['empty_center_distance_m'], grid['origin_m'], float(grid['pitch_m']))
                lower_value = max(0., float(lower.max()) * float(singular.min()))
                upper_value = float(upper.max()) * float(singular.max())
                lower_max[row, si, other] = lower_value
                upper_max[row, si, other] = upper_value
                witness = None
                if lower_value > .002:
                    index = int(np.argmax(lower))
                    witness = {'original_exported_vertex_index': index, 'point_world_m': world[index].tolist(),
                               'point_material_local_m': points[index].tolist(), 'world_metric_depth_lower_m': lower_value}
                provenance = bm['object_observation_provenance'][bm['objects'][other]['name']][str(frame)]
                records.append({'side': ('left', 'right')[si], 'attached_object': int(oi), 'against_object': other, 'seed': seed,
                                'source_frame': frame, 'inferred_hold_state': int(h['inferred_hold_state'][row, si, oi]),
                                'against_object_pose_provenance': provenance, 'source_affine_singular_values': singular.tolist(),
                                'all_original_exported_vertices_checked': len(world), 'inside_vertex_count': int(inside.sum()),
                                'maximum_declared_material_vertex_depth_lower_m': lower_value,
                                'maximum_declared_material_vertex_depth_upper_m': upper_value,
                                'vertex_depth_limit_explicitly_violated': lower_value > .002,
                                'vertex_upper_bound_below_limit': upper_value <= .002,
                                'witness': witness, 'physical_task_accepted': False})
        if len(world_meshes) == 2:
            result = cross_hand(model(*world_meshes[0]), model(*world_meshes[1]))
            cross_records.append({'source_frame': frame, 'all_original_exported_triangles_checked': True,
                                  'source_affine_geometry_preserved_by_world_vertex_BVHs': True, **result, 'physical_task_accepted': False})
        if row % 25 == 0:
            print(json.dumps({'source_frame': frame, 'held_scene_vertex_checks': len(records), 'cross_hand_frames': len(cross_records), 'elapsed_seconds': time.monotonic() - started}), flush=True)
    expected = int(holds.sum()) * objects
    assert len(records) == expected
    assert len(cross_records) == int((holds.any(axis=2).sum(axis=1) == 2).sum())
    summaries = []
    for (si, oi), (_, _, seed) in geometries.items():
        for other in grids:
            selected = [v for v in records if v['side'] == ('left', 'right')[si] and v['attached_object'] == oi and v['against_object'] == other]
            if not selected:
                continue
            worst = max(selected, key=lambda v: v['maximum_declared_material_vertex_depth_lower_m'])
            summaries.append({'side': ('left', 'right')[si], 'attached_object': oi, 'against_object': other, 'seed': seed,
                              'all_inferred_hold_frames_checked': len(selected),
                              'explicit_violation_frames': [v['source_frame'] for v in selected if v['vertex_depth_limit_explicitly_violated']],
                              'worst_source_frame': worst['source_frame'],
                              'maximum_depth_lower_m': worst['maximum_declared_material_vertex_depth_lower_m'],
                              'maximum_depth_upper_m': max(v['maximum_declared_material_vertex_depth_upper_m'] for v in selected),
                              'physical_task_accepted': False})
    a.out.mkdir(parents=True)
    payload = a.out / 'hold-scene-vertex-bounds.npz'
    np.savez_compressed(payload, frame_indices=d['frame_indices'], source_hand_valid=d['hand_valid'],
                        source_hand_directly_observed=d['hand_directly_observed'], source_object_observed=observed,
                        inferred_hold_state=h['inferred_hold_state'], maximum_material_vertex_depth_lower_m=lower_max,
                        maximum_material_vertex_depth_upper_m=upper_max)
    report = {'source_sha256': sha(Path(__file__)), 'voxel_module_sha256': sha(Path(voxel_module.__file__)),
              'bundle_manifest_sha256': bundle_hash, 'scene_report_sha256': sha(a.scenes / 'report.json'),
              'material_manifest_sha256': sha(a.material / 'manifest.json'), 'timing_report_sha256': sha(a.timing / 'report.json'),
              'payload_sha256': sha(payload), 'coal_version': coal.__version__, 'controls': tested, 'geometry': geometry_records,
              'source_frames_retained': n, 'inferred_hand_object_hold_frames_checked': int(holds.sum()),
              'vertex_depth_limit_m': .002, 'summaries': summaries, 'frames': records,
              'cross_hand_source_frames_checked': len(cross_records),
              'cross_hand_intersection_source_frames': [v['source_frame'] for v in cross_records if v['original_triangle_surface_intersection']],
              'cross_hand_frames': cross_records, 'elapsed_seconds': time.monotonic() - started,
              'every_declared_source_frame_retained': True, 'original_source_observations_modified': False,
              'hypothesis': 'constant original robot template attached to its source-tracked object only on existing inferred-hold frames',
              'full_material_triangle_surfaces_checked': False, 'table_environment_or_solid_volume_checked': False,
              'continuous_motion_checked': False, 'approach_release_or_observation_gaps_generated': False,
              'new_simulator_run': False, 'contact_known': False, 'physical_task_accepted': False}
    assert sha(a.bundle / 'manifest.json') == bundle_hash
    (a.out / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'summaries': summaries, 'cross_hand_intersection_source_frames': report['cross_hand_intersection_source_frames'],
                      'elapsed_seconds': report['elapsed_seconds'], 'physical_task_accepted': False}), flush=True)


if __name__ == '__main__':
    main()
