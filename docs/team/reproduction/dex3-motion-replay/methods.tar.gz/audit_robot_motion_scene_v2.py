"""Independent original-asset FK and scene audit of an inferred motion proposal.

All source frame indices are retained. Vertex bounds detect failures; they are
not full surface certificates. No acceptance bit or source observation changes.
"""
import argparse
import hashlib
import json
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import coal
import numpy as np
import pinocchio as pin
import trimesh
from scipy.spatial.transform import Rotation

from audit_static_hold_scene_vertices_v1 import model, controls


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def collision(first, tf1, second, tf2):
    request = coal.CollisionRequest()
    request.enable_contact = True
    request.num_max_contacts = 1
    result = coal.CollisionResult()
    coal.collide(first, tf1, second, tf2, request, result)
    return bool(result.isCollision())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'bundle', 'baseline', 'proposal', 'material', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    tested = controls()
    bm = json.loads((a.bundle / 'manifest.json').read_text())
    baseline = json.loads((a.baseline / 'manifest.json').read_text())
    proposal = json.loads((a.proposal / 'report.json').read_text())
    mm = json.loads((a.material / 'manifest.json').read_text())
    bh = sha(a.bundle / 'manifest.json')
    assert proposal['bundle_manifest_sha256'] == baseline['episode_bundle_manifest_sha256'] == bh
    assert proposal['baseline_manifest_sha256'] == sha(a.baseline / 'manifest.json')
    assert proposal['payload_sha256'] == sha(a.proposal / 'robot-motion-proposal.npz')
    assert bm['payload']['sha256'] == mm['source_bundle_payload_sha256'] == sha(a.bundle / 'episode.npz')
    with np.load(a.bundle / 'episode.npz', allow_pickle=False) as z:
        d = {k: z[k] for k in z.files}
    with np.load(a.proposal / 'robot-motion-proposal.npz', allow_pickle=False) as z:
        motion = {k: z[k] for k in z.files}
    for key, orig in (('frame_indices', 'frame_indices'), ('timestamps_s', 'timestamps_s'),
                      ('source_hand_valid', 'hand_valid'), ('source_hand_directly_observed', 'hand_directly_observed')):
        np.testing.assert_array_equal(motion[key], d[orig])
    assert motion['robot_pose_is_inferred'].all() and not motion['robot_motion_target_validated'].any()
    q = motion['robot_qpos_inferred']
    n = len(d['frame_indices'])
    assert q.shape == (n, 2, 14) and np.isfinite(q).all()
    np.testing.assert_allclose(np.linalg.norm(q[:, :, 3:7], axis=2), 1., atol=1e-12, rtol=0)
    sys.path.insert(0, str(a.source / 'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    from robotic_grounding.retarget.track3_collision_voxels import solid_depth_bounds
    import robotic_grounding.retarget.track3_collision_voxels as voxels
    assets = a.source / 'source/robotic_grounding/robotic_grounding/assets'
    verify_robot_assets(proposal, assets)
    grids = {}
    for entry in mm['objects']:
        path = a.material / f"object_{entry['object']}.npz"
        assert sha(path) == entry['payload_sha256']
        with np.load(path, allow_pickle=False) as z:
            grids[entry['object']] = {k: z[k] for k in z.files}
    hands, geometry_records, summaries = [], [], []
    dt = np.diff(d['timestamps_s'])
    assert (dt > 0).all() and (np.diff(d['frame_indices']) == 1).all()
    for si, side in enumerate(('left', 'right')):
        kin = setup_dex3_kinematics(side=side, max_iter=1)
        geom = kin.robot.collision_model
        gd = geom.createData()
        original, points, faces, names = [], [], [], []
        for obj in geom.geometryObjects:
            mesh = trimesh.load(Path(obj.meshPath), force='mesh', process=False)
            vertices, inverse = np.unique(np.asarray(mesh.vertices, dtype=float), axis=0, return_inverse=True)
            vertices *= np.asarray(obj.meshScale)
            triangles = inverse[mesh.faces]
            original.append(model(vertices, triangles))
            points.append(vertices)
            faces.append(triangles)
            names.append(kin.robot.model.frames[obj.parentFrame].name)
            geometry_records.append({'side': side, 'link': names[-1], 'mesh_sha256': sha(Path(obj.meshPath)),
                                     'all_original_vertices': len(vertices), 'all_original_triangles': len(triangles)})
        xml = ET.parse(assets / f'urdfs/g1/dex3_{side}.urdf').getroot()
        adjacent = {frozenset([j.find('parent').attrib['link'], j.find('child').attrib['link']]) for j in xml.findall('joint')}
        pairs = [(i, j) for i in range(len(names)) for j in range(i + 1, len(names))
                 if names[i] != names[j] and frozenset([names[i], names[j]]) not in adjacent]
        limits = baseline['joints'][side]
        lo, hi, velocity = (np.array(limits[k]) for k in ('lower_radians', 'upper_radians', 'velocity_limits_rad_s'))
        position_bad = ((q[:, si, 7:] < lo - 1e-6) | (q[:, si, 7:] > hi + 1e-6))
        speeds = abs(np.diff(q[:, si, 7:], axis=0)) / dt[:, None]
        speed_bad = speeds > velocity + 1e-5
        root_speed = np.linalg.norm(np.diff(q[:, si, :3], axis=0), axis=1) / dt
        rotations = Rotation.from_quat(q[:, si, 3:7])
        angular_speed = (rotations[:-1].inv() * rotations[1:]).magnitude() / dt
        summaries.append({'side': side, 'position_violation_frames': d['frame_indices'][position_bad.any(axis=1)].tolist(),
                          'finger_velocity_violating_source_pairs': [[int(d['frame_indices'][r]), int(d['frame_indices'][r + 1])]
                                                                   for r in np.flatnonzero(speed_bad.any(axis=1))],
                          'maximum_finger_speed_rad_s': float(speeds.max()), 'maximum_root_speed_m_s': float(root_speed.max()),
                          'maximum_root_angular_speed_rad_s': float(angular_speed.max()), 'root_velocity_limit_declared': False})
        hands.append((kin, geom, gd, original, points, faces, names, pairs))
    lower = np.full((n, 2, len(grids)), np.nan)
    upper = np.full_like(lower, np.nan)
    records, self_records, cross_records = [], [], []
    transforms = {}
    frame_poses = {side: np.full((n, len(baseline['joints'][side]['frame_names']), 7), np.nan) for side in ('left', 'right')}
    for row, fv in enumerate(d['frame_indices']):
        frame = int(fv)
        for si, side in enumerate(('left', 'right')):
            kin, geom, gd, original, points, faces, names, pairs = hands[si]
            kin.configuration.update(q[row, si])
            pin.updateGeometryPlacements(kin.robot.model, kin.configuration.data, geom, gd, q[row, si])
            transforms[si] = [coal.Transform3s(tf.rotation, tf.translation) for tf in gd.oMg]
            world = np.concatenate([v @ tf.rotation.T + tf.translation for v, tf in zip(points, gd.oMg)])
            bad = [[names[i], names[j]] for i, j in pairs if collision(original[i], transforms[si][i], original[j], transforms[si][j])]
            self_records.append({'source_frame': frame, 'side': side, 'intersecting_nonadjacent_original_surface_pairs': bad})
            for fi, name in enumerate(baseline['joints'][side]['frame_names']):
                tf = kin.configuration.get_transform_frame_to_world(name)
                frame_poses[side][row, fi] = np.r_[tf.translation, Rotation.from_matrix(tf.rotation).as_quat()]
            for oi, grid in grids.items():
                pose = d[f'object_{oi}_world'][row]
                matrix = pose[:3, :3] * float(d[f'object_{oi}_scale'][row])
                singular = np.linalg.svd(matrix, compute_uv=False)
                local = (world - pose[:3, 3]) @ np.linalg.inv(matrix).T
                lb, ub, inside = solid_depth_bounds(local, grid['solid_cells'], grid['empty_center_distance_m'],
                                                     grid['origin_m'], float(grid['pitch_m']))
                lower[row, si, oi] = max(0., float(lb.max()) * float(singular.min()))
                upper[row, si, oi] = float(ub.max()) * float(singular.max())
                k = int(np.argmax(lb))
                records.append({'source_frame': frame, 'side': side, 'against_object': oi,
                                'object_pose_provenance': bm['object_observation_provenance'][bm['objects'][oi]['name']][str(frame)],
                                'robot_inference_kind': int(motion['robot_pose_inference_kind'][row, si]),
                                'source_hand_valid': bool(d['hand_valid'][row, si]),
                                'depth_lower_m': lower[row, si, oi], 'depth_upper_m': upper[row, si, oi],
                                'vertex_limit_explicitly_violated': lower[row, si, oi] > .002,
                                'inside_vertices': int(inside.sum()), 'original_vertex_witness': k,
                                'witness_world_m': world[k].tolist()})
        cross = []
        for i, first in enumerate(hands[0][3]):
            for j, second in enumerate(hands[1][3]):
                if collision(first, transforms[0][i], second, transforms[1][j]):
                    cross.append([hands[0][6][i], hands[1][6][j]])
        cross_records.append({'source_frame': frame, 'intersecting_cross_hand_original_surface_pairs': cross})
        if row % 25 == 0:
            print(json.dumps({'source_frame': frame, 'scene_vertex_checks': len(records), 'elapsed_seconds': time.monotonic() - started}), flush=True)
    assert len(records) == n * 2 * len(grids) and len(self_records) == n * 2 and len(cross_records) == n
    for si, side in enumerate(('left', 'right')):
        summaries[si]['self_intersection_frames'] = [v['source_frame'] for v in self_records if v['side'] == side and v['intersecting_nonadjacent_original_surface_pairs']]
        summaries[si]['material'] = [{'object': oi, 'explicit_vertex_violation_frames': [v['source_frame'] for v in records if v['side'] == side and v['against_object'] == oi and v['vertex_limit_explicitly_violated']],
                                    'maximum_vertex_depth_lower_m': float(lower[:, si, oi].max()), 'maximum_vertex_depth_upper_m': float(upper[:, si, oi].max())} for oi in grids]
    a.out.mkdir(parents=True)
    payload = a.out / 'robot-motion-scene-audit.npz'
    np.savez_compressed(payload, **motion, maximum_material_vertex_depth_lower_m=lower, maximum_material_vertex_depth_upper_m=upper,
                        robot_left_frame_poses=frame_poses['left'], robot_right_frame_poses=frame_poses['right'])
    report = {'source_sha256': sha(Path(__file__)), 'bundle_manifest_sha256': bh,
              'baseline_manifest_sha256': sha(a.baseline / 'manifest.json'), 'proposal_report_sha256': sha(a.proposal / 'report.json'),
              'material_manifest_sha256': sha(a.material / 'manifest.json'), 'voxel_module_sha256': sha(Path(voxels.__file__)),
              'payload_sha256': sha(payload), 'controls': tested, 'pinocchio_version': pin.__version__, 'coal_version': coal.__version__,
              'original_geometry': geometry_records, 'source_frames_checked': n, 'summaries': summaries, 'material_frames': records,
              'self_frames': self_records, 'cross_hand_frames': cross_records,
              'cross_hand_intersection_frames': [v['source_frame'] for v in cross_records if v['intersecting_cross_hand_original_surface_pairs']],
              'elapsed_seconds': time.monotonic() - started, 'whole_original_triangle_material_surfaces_certified': False,
              'continuous_motion_checked': False, 'table_environment_checked': False, 'source_accuracy_accepted': False,
              'source_observations_modified': False, 'new_simulator_run': False, 'physical_task_accepted': False}
    (a.out / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False, default=lambda v: v.item() if isinstance(v, np.generic) else (_ for _ in ()).throw(TypeError(type(v).__name__))) + '\n')
    print(json.dumps({'summaries': summaries, 'cross_hand_intersection_frames': report['cross_hand_intersection_frames'],
                      'elapsed_seconds': report['elapsed_seconds'], 'physical_task_accepted': False}), flush=True)


if __name__ == '__main__':
    main()
