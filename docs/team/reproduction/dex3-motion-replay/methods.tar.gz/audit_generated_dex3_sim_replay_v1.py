"""Independent source-mask, root/joint/camera and video audit of generated replay.

Root/joint math reuses the measured replay verifier's calculations. Link fields
are renderer-computed aggregate errors, not independently saved absolute poses.
Color presence flags possible visibility problems; it is not a flicker verdict.
"""
import argparse
import hashlib
import json
from pathlib import Path

import imageio.v2 as imageio
import numpy as np
from PIL import Image
from scipy.spatial.transform import Rotation

VERIFIER_PARENT_SHA = '46801dfc6ee42d729a12a06bbf1f93c5d42127b051bd9dcc48252ac9d86d6cfd'
RENDERER_SHA = '2449bb6f692493fd174463806ba2d65e14943c603f0d4f25adaf89a3323eabc1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def arrays(path):
    with np.load(path, allow_pickle=False) as z:
        return {key: z[key] for key in z.files}


def audit(a):
    source = arrays(a.bundle / 'episode.npz')
    base = arrays(a.baseline / 'retarget.npz')
    proposal = arrays(a.proposal / 'robot-motion-proposal.npz')
    actual = arrays(a.replay / 'simulator-readback.npz')
    bm = json.loads((a.bundle / 'manifest.json').read_text())
    baseline = json.loads((a.baseline / 'manifest.json').read_text())
    motion = json.loads((a.proposal / 'report.json').read_text())
    report = json.loads((a.replay / 'complete.json').read_text())
    assert not (a.replay / 'failure.json').exists()
    assert bm['payload']['sha256'] == sha(a.bundle / 'episode.npz')
    assert baseline['payload']['sha256'] == sha(a.baseline / 'retarget.npz')
    assert motion['payload_sha256'] == report['generated_motion_payload_sha256'] == sha(a.proposal / 'robot-motion-proposal.npz')
    assert motion['baseline_manifest_sha256'] == sha(a.baseline / 'manifest.json')
    assert report['generated_motion_report_sha256'] == sha(a.proposal / 'report.json')
    assert report['bundle_manifest_sha256'] == sha(a.bundle / 'manifest.json')
    assert report['source_sha256'] == RENDERER_SHA
    assert report['readback_sha256'] == sha(a.replay / 'simulator-readback.npz')
    assert report['video_sha256'] == sha(a.replay / 'replay.mp4')
    assert report['source_observation_validity_controls_robot_display'] is False
    assert report['all_displayed_robot_poses_are_inferred'] is True
    assert report['physical_task_accepted'] is False
    frames = source['frame_indices']
    n = len(frames)
    assert report['source_frames'] == report['decoded_video_frames'] == n
    for value in (base['frame_indices'], proposal['frame_indices'], actual['frame_indices']):
        np.testing.assert_array_equal(value, frames)
    for value in (base['robot_valid'], proposal['source_hand_valid'], actual['robot_valid'], actual['source_hand_valid']):
        np.testing.assert_array_equal(value, source['hand_valid'])
    np.testing.assert_array_equal(actual['source_hand_directly_observed'], source['hand_directly_observed'])
    for name in ('robot_pose_is_inferred', 'robot_motion_target_validated', 'robot_pose_inference_kind'):
        np.testing.assert_array_equal(actual[name], proposal[name])
    assert actual['robot_pose_is_inferred'].all()
    assert not actual['robot_motion_target_validated'].any()
    display = actual['simulator_display_valid']
    assert display.shape == (n, 2) and display.dtype == bool and display.all()
    q, expected = actual['robot_qpos'], proposal['robot_qpos_inferred']
    assert q.shape == expected.shape == (n, 2, 14)
    assert np.isfinite(q).all() and np.isfinite(expected).all()
    np.testing.assert_allclose(np.linalg.norm(q[..., 3:7], axis=-1), 1., atol=1e-6, rtol=0)
    np.testing.assert_allclose(np.linalg.norm(expected[..., 3:7], axis=-1), 1., atol=1e-6, rtol=0)
    # Same independent vector norms / quaternion-sign-invariant relative rotation
    # as the frozen original verifier, now covering every explicit inferred state.
    errors = {
        'root_position_m': float(np.linalg.norm(q[display, :3] - expected[display, :3], axis=1).max()),
        'joint_angle_rad': float(np.abs(q[display, 7:] - expected[display, 7:]).max()),
        'root_rotation_rad': float((Rotation.from_quat(q[display, 3:7]).inv() * Rotation.from_quat(expected[display, 3:7])).magnitude().max()),
    }
    for key in ('usd_link_position_error_m', 'physics_link_position_error_m'):
        assert actual[key].shape == (n, 2) and np.isfinite(actual[key]).all()
        errors['renderer_' + key] = float(actual[key].max())
    assert max(errors.values()) <= 1e-4, errors
    camera = actual['camera_c2w_readback']
    assert camera.shape == source['camera_c2w'].shape and np.isfinite(camera).all()
    camera_errors = {
        'position_m': float(np.linalg.norm(camera[:, :3, 3] - source['camera_c2w'][:, :3, 3], axis=1).max()),
        'rotation_rad': float((Rotation.from_matrix(camera[:, :3, :3]).inv() * Rotation.from_matrix(source['camera_c2w'][:, :3, :3])).magnitude().max()),
        'intrinsics_px': float(np.abs(actual['camera_intrinsics_readback'] - source['intrinsics']).max()),
    }
    assert camera_errors['position_m'] <= 1e-4 and camera_errors['rotation_rad'] <= 1e-4 and camera_errors['intrinsics_px'] <= 1e-3
    reader = imageio.get_reader(a.replay / 'replay.mp4')
    decoded = 0
    try:
        fps = float(reader.get_meta_data()['fps'])
        for image in reader:
            assert image.std() >= 1., decoded
            decoded += 1
    finally:
        reader.close()
    assert decoded == n and abs(fps - float(report['fps'])) <= 1e-3
    files = {p.name for p in (a.replay / 'frames').glob('*.png')}
    assert files == {f'{int(frame):06d}.png' for frame in frames}
    counts = np.zeros((n, 2), dtype=np.int64)
    for row, frame in enumerate(frames):
        rgb = np.asarray(Image.open(a.replay / 'frames' / f'{int(frame):06d}.png').convert('RGB'), dtype=float)
        assert rgb.std() >= 1.
        counts[row, 0] = np.count_nonzero((rgb[..., 2] > 1.5 * rgb[..., 0]) & (rgb[..., 2] > 1.3 * rgb[..., 1]) & (rgb[..., 2] > 40))
        counts[row, 1] = np.count_nonzero((rgb[..., 0] > 1.5 * rgb[..., 2]) & (rgb[..., 0] > 1.2 * rgb[..., 1]) & (rgb[..., 0] > 40))
    np.testing.assert_array_equal(counts, actual['hand_review_color_pixels'])
    visibility = []
    for side_id, side in enumerate(('left', 'right')):
        low = counts[:, side_id] < 20
        isolated = low[1:-1] & ~low[:-2] & ~low[2:]
        visibility.append({'side': side, 'minimum_color_pixels': int(counts[:, side_id].min()),
                           'below20_color_pixel_source_frames': frames[low].tolist(),
                           'isolated_below20_color_pixel_source_frames': frames[1:-1][isolated].tolist()})
    return {
        'status': 'passed declared input/state/camera/video audit; visual and physical acceptance pending',
        'auditor_sha256': sha(Path(__file__)), 'original_verifier_math_reference_sha256': VERIFIER_PARENT_SHA,
        'simulator_complete_report_sha256': sha(a.replay / 'complete.json'),
        'source_frames': n, 'decoded_video_frames': decoded, 'explicit_inferred_robot_states': int(display.sum()),
        'source_hand_valid_counts': source['hand_valid'].sum(axis=0).tolist(),
        'original_source_masks_exact': True, 'all_robot_poses_inferred_and_targets_unaccepted': True,
        'independently_recomputed_root_joint_errors': errors, 'independently_recomputed_camera_errors': camera_errors,
        'independent_absolute_link_readback_available': False,
        'renderer_aggregate_link_error_fields_checked': True,
        'visibility_color_indicators': visibility,
        'color_presence_is_not_segmentation_or_flicker_truth': True,
        'flicker_free_visual_result_verified': False, 'physical_task_accepted': False,
    }


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('bundle', 'baseline', 'proposal', 'replay', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists()
    result = audit(a)
    a.out.mkdir(parents=True)
    (a.out / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
