"""Join declared grasp corridors without changing source observations or timing.

Reuse the existing corridor evaluator's object interpolation and local path,
and the GitHub retarget's inferred free wrist poses. A separate corridor serves
each automatic grasp; all generated targets remain unvalidated. This proposal
does not certify the other object, cross-hand separation, table or full task.
"""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from generated_corridor_motion_v2 import CorridorMotion, sha
from propose_robot_contact_motion_v1 import blend, smooth, interpolate_priors, controls


def load(path):
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key].copy() for key in archive.files}


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


class PerGraspMotion(CorridorMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas):
        self.bm = read(bundle / 'manifest.json')
        self.rm = read(baseline / 'manifest.json')
        self.pr = read(parent_proposal / 'report.json')
        self.ir = read(interval_inputs / 'report.json')
        self.atlas = read(atlas)
        self.atlas_path = atlas
        bundle_hash = sha(bundle / 'manifest.json')
        assert self.rm['episode_bundle_manifest_sha256'] == self.pr['bundle_manifest_sha256'] == self.ir['bundle_manifest_sha256'] == bundle_hash
        assert self.bm['payload']['sha256'] == sha(bundle / 'episode.npz')
        assert self.rm['payload']['sha256'] == sha(baseline / 'retarget.npz')
        assert self.pr['payload_sha256'] == sha(parent_proposal / 'robot-motion-proposal.npz')
        assert self.pr['baseline_manifest_sha256'] == sha(baseline / 'manifest.json')
        assert self.ir['parent_proposal_report_sha256'] == sha(parent_proposal / 'report.json')
        assert self.atlas['interval_report_sha256'] == sha(interval_inputs / 'report.json')
        self.source = load(bundle / 'episode.npz')
        self.original = load(parent_proposal / 'robot-motion-proposal.npz')
        baseline_data = load(baseline / 'retarget.npz')
        self.times = self.source['timestamps_s']
        self.free_blend = .2
        self.sides, self.locks, self.breakpoints = [], [], list(self.times)
        np.testing.assert_array_equal(self.original['frame_indices'], self.source['frame_indices'])
        np.testing.assert_array_equal(self.original['timestamps_s'], self.times)
        for target, source_key in (('source_hand_valid', 'hand_valid'), ('source_hand_directly_observed', 'hand_directly_observed')):
            np.testing.assert_array_equal(self.original[target], self.source[source_key])
            np.testing.assert_array_equal(baseline_data[target], self.source[source_key])
        np.testing.assert_array_equal(baseline_data['robot_valid'], self.source['hand_valid'])
        assert self.original['robot_pose_is_inferred'].all()
        assert not self.original['robot_motion_target_validated'].any()
        expected = {row['prefix'] for row in self.ir['grasps']}
        provided = [row['prefix'] for row in self.atlas['grasps']]
        assert len(set(provided)) == len(provided) and set(provided) == expected
        self.free_priors = []
        for si, side in enumerate(('left', 'right')):
            phases = []
            for interval in [v for v in self.ir['grasps'] if v['side'] == side]:
                spec = next(v for v in self.atlas['grasps'] if v['prefix'] == interval['prefix'])
                paths = {name: (atlas.parent / spec[name]).resolve() for name in ('templates', 'scenes', 'corridor')}
                reports = {name: read(path / 'report.json') for name, path in paths.items()}
                template, scenes, corridor = (reports[name] for name in ('templates', 'scenes', 'corridor'))
                for name, report in reports.items():
                    assert sha(paths[name] / 'report.json') == spec[name + '_report_sha256']
                    assert report['bundle_manifest_sha256'] == bundle_hash
                assert template['region_report_sha256'] == scenes['region_report_sha256']
                assert template['region_report_sha256'] in (interval['region_report_sha256'], self.ir['parent_region_report_sha256']), 'A different per-grasp fit cannot serve this interval'
                assert corridor['template_report_sha256'] == scenes['template_report_sha256'] == spec['templates_report_sha256']
                assert corridor['scene_report_sha256'] == spec['scenes_report_sha256']
                assert not corridor['failed_levels']
                assert corridor['payload_sha256'] == sha(paths['corridor'] / 'opening-corridor.npz')
                selected = [v for v in scenes['scenes'] if v['side'] == side and v['object'] == interval['object']]
                assert len(selected) == 1, 'Every grasp needs an automatic single-scene selection'
                scene = selected[0]
                candidate = next(v for v in template['templates'] if v['side'] == side and v['object'] == interval['object'] and v.get('seed') == scene['seed'])
                assert candidate['success'] and not candidate['physical_task_accepted']
                payload = load(paths['corridor'] / 'opening-corridor.npz')
                qpath = payload[f'{side}_qpos_object_frame_inferred']
                np.testing.assert_array_equal(qpath[0], candidate['qpos_object_frame'])
                limits = np.asarray(self.rm['joints'][side]['velocity_limits_rad_s'])
                steps = np.diff(qpath, axis=0)
                required = np.maximum(np.linalg.norm(steps[:, :3], axis=1), np.max(abs(steps[:, 7:]) / limits, axis=1))
                assert (required > 0).all()
                duration = max(.3, float(required.sum()))
                clock = np.r_[0., np.cumsum(required)] * duration / required.sum()
                frames = self.source['frame_indices']
                rows = np.flatnonzero((frames >= interval['start_frame']) & (frames <= interval['end_frame']))
                assert len(rows) == interval['intent_rows'] and np.all(np.diff(rows) == 1)
                first, last = float(self.times[rows[0]]), float(self.times[rows[-1]])
                phase = {'prefix': interval['prefix'], 'side': side, 'object': interval['object'],
                         'grasp_index': interval['grasp_index'], 'seed': scene['seed'],
                         'qpath': qpath, 'clock': clock, 'duration_s': duration,
                         'interval': (first, last), 'source_rows': rows.tolist(),
                         'parent_trial_terminal': template.get('source_trial_terminal', not template.get('partial_search_snapshot', False))}
                centre = np.mean([pad['point_object_scaled_m'] for pad in candidate['pads']], axis=0)
                retreat = qpath[0, :3] - centre
                retreat[candidate['source_region_normal_axis']] = 0.
                assert np.linalg.norm(retreat) > 1e-6
                phase['retreat_object_direction'] = (retreat / np.linalg.norm(retreat)).tolist()
                phase['fitting_region_scope'] = ('own automatic grasp' if template['region_report_sha256'] == interval['region_report_sha256'] else 'declared pooled episode candidate')
                phases.append(phase)
                self.breakpoints.extend(first - clock)
                self.breakpoints.extend(last + clock)
                self.breakpoints.extend((first - duration - self.free_blend, last + duration + self.free_blend))
                self.locks.append({'prefix': interval['prefix'], **spec,
                                   'selected_seed': scene['seed'], 'corridor_payload_sha256': corridor['payload_sha256']})
            phases.sort(key=lambda row: row['interval'][0])
            assert phases
            expected_intent = np.zeros_like(self.original['robot_contact_intent_inferred'][:, si])
            for phase in phases:
                expected_intent[phase['source_rows'], phase['object']] = True
                np.testing.assert_allclose(phase['qpath'][-1, 7:], phases[0]['qpath'][-1, 7:], atol=1e-12, rtol=0)
            np.testing.assert_array_equal(expected_intent, self.original['robot_contact_intent_inferred'][:, si])
            for previous, current in zip(phases[:-1], phases[1:]):
                assert previous['interval'][1] + previous['duration_s'] + self.free_blend <= current['interval'][0] - current['duration_s'] - self.free_blend, 'Overlapping grasp schedules need planning; never truncate either contact'
            reliable = baseline_data['robot_valid'][:, si] & self.source['hand_directly_observed'][:, si]
            prior, observed_rows, inside = interpolate_priors(self.times, baseline_data['robot_qpos'][:, si], reliable)
            for phase, edge_rows, entering in (
                    (phases[0], np.arange(observed_rows[0]), True),
                    (phases[-1], np.arange(observed_rows[-1] + 1, len(self.times)), False)):
                event = phase['interval'][0 if entering else 1]
                edge = event - phase['duration_s'] - self.free_blend if entering else event + phase['duration_s'] + self.free_blend
                observed_edge_row = observed_rows[0 if entering else -1]
                observed_edge_time = float(self.times[observed_edge_row])
                free_edge = observed_edge_time < edge if entering else observed_edge_time > edge
                observed_edge = prior[observed_edge_row].copy()
                if free_edge:
                    edge = observed_edge_time
                for row in edge_rows:
                    amount = .2 * float(smooth((edge - self.times[row] if entering else self.times[row] - edge) / .5))
                    matrix, translation, _ = self.object_pose(phase['object'], observed_edge_time if free_edge else float(self.times[row]))
                    direction = matrix @ np.asarray(phase['retreat_object_direction'])
                    direction /= np.linalg.norm(direction)
                    if free_edge:
                        q = observed_edge.copy()
                        q[:3] += amount * direction
                    else:
                        q = phase['qpath'][-1].copy()
                        q[:3] = matrix @ q[:3] + translation + amount * direction
                        q[3:7] = Rotation.from_matrix(matrix @ Rotation.from_quat(q[3:7]).as_matrix()).as_quat()
                    prior[row] = q
            prior[:, 7:] = phases[0]['qpath'][-1, 7:]
            assert np.isfinite(prior).all()
            self.free_priors.append(prior)
            self.sides.append({'side': side, 'phases': phases, 'reliable_prior_rows': observed_rows.tolist(),
                               'unobserved_entry_exit_waypoint_count': int(observed_rows[0] + len(self.times) - observed_rows[-1] - 1)})
        self.breakpoints = np.unique(self.breakpoints)
        self.breakpoints = self.breakpoints[(self.breakpoints >= self.times[0]) & (self.breakpoints <= self.times[-1])]

    def prior(self, si, time):
        row, fraction = self.bracket(time)
        return blend(self.free_priors[si][row], self.free_priors[si][row + 1], fraction)

    def evaluate(self, time):
        values, kinds, details = [], [], []
        for si, side in enumerate(self.sides):
            phase = min(side['phases'], key=lambda row: (0. if row['interval'][0] <= time <= row['interval'][1] else min(abs(time - row['interval'][0]), abs(time - row['interval'][1])), row['grasp_index']))
            first, last = phase['interval']
            duration = phase['duration_s']
            if first <= time <= last:
                opening_time, weight, kind = 0., 1., 2
            elif first - duration <= time < first:
                opening_time, weight, kind = first - time, 1., 9
            elif last < time <= last + duration:
                opening_time, weight, kind = time - last, 1., 9
            else:
                opening_time = duration
                distance = min(abs(time - first), abs(time - last))
                weight = float(smooth(1. - (distance - duration) / self.free_blend))
                kind = 10 if weight else 7
            prior = self.prior(si, time)
            if weight:
                local = self.local_path(phase, opening_time)
                matrix, translation, _ = self.object_pose(phase['object'], time)
                attached = local.copy()
                attached[:3] = matrix @ local[:3] + translation
                attached[3:7] = Rotation.from_matrix(matrix @ Rotation.from_quat(local[3:7]).as_matrix()).as_quat()
                value = blend(prior, attached, weight)
            else:
                value = prior
                reliable_rows = side['reliable_prior_rows']
                if time < self.times[reliable_rows[0]] or time > self.times[reliable_rows[-1]]:
                    kind = 6
            values.append(value)
            kinds.append(kind)
            details.append((phase['grasp_index'] if weight else -1, phase['object'] if weight else -1, opening_time, weight))
        return np.asarray(values), np.asarray(kinds, dtype=np.int8), np.asarray(details)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('bundle', 'baseline', 'parent-proposal', 'interval-inputs', 'atlas', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    a = parser.parse_args()
    assert not a.out.exists()
    tested = controls()
    motion = PerGraspMotion(a.bundle, a.baseline, a.parent_proposal, a.interval_inputs, a.atlas)
    original = {key: value.copy() for key, value in motion.original.items()}
    sampled, kinds, details = (np.asarray(value) for value in zip(*(motion.evaluate(float(time)) for time in motion.times)))
    dense_times = np.unique(np.r_[motion.breakpoints, (motion.breakpoints[:-1] + motion.breakpoints[1:]) / 2])
    dense, dense_kinds, dense_details = (np.asarray(value) for value in zip(*(motion.evaluate(float(time)) for time in dense_times)))
    assert np.isfinite(sampled).all() and np.isfinite(dense).all() and np.isin(motion.times, dense_times).all()
    np.testing.assert_allclose(np.linalg.norm(dense[:, :, 3:7], axis=2), 1., atol=1e-12, rtol=0)
    hold_controls = []
    for si, side in enumerate(motion.sides):
        for phase in side['phases']:
            q = phase['qpath'][0]
            rows = phase['source_rows']
            poses = motion.source[f'object_{phase["object"]}_world'][rows]
            expected_xyz = np.einsum('bij,j->bi', poses[:, :3, :3], q[:3]) + poses[:, :3, 3]
            expected_rotation = Rotation.from_matrix(poses[:, :3, :3] @ Rotation.from_quat(q[3:7]).as_matrix()).as_matrix()
            np.testing.assert_allclose(sampled[rows, si, :3], expected_xyz, atol=1e-12, rtol=0)
            np.testing.assert_allclose(Rotation.from_quat(sampled[rows, si, 3:7]).as_matrix(), expected_rotation, atol=1e-12, rtol=0)
            np.testing.assert_allclose(sampled[rows, si, 7:], np.broadcast_to(q[7:], (len(rows), 7)), atol=1e-12, rtol=0)
            hold_controls.append({'prefix': phase['prefix'], 'all_original_intent_rows_retained': len(rows), 'closed_corridor_anchor_verified_at_every_hold': True})
        limits = np.asarray(motion.rm['joints'][side['side']]['velocity_limits_rad_s'])
        speed = abs(np.diff(dense[:, si, 7:], axis=0)) / np.diff(dense_times)[:, None]
        assert np.all(speed <= limits + 1e-8), 'Finger velocity limit exceeded'
    original['robot_qpos_inferred'] = sampled
    kinds[motion.original['robot_contact_intent_bridge'].any(axis=2)] = 3
    original['robot_pose_inference_kind'] = kinds
    original['robot_grasp_phase_index_inferred'] = details[:, :, 0].astype(np.int16)
    original['robot_blend_object'] = details[:, :, 1].astype(np.int16)
    original['robot_corridor_opening_clock_s'] = details[:, :, 2]
    original['robot_corridor_prior_blend_weight'] = details[:, :, 3]
    original['parent_robot_contact_blend_weight'] = original.pop('robot_contact_blend_weight')
    original['robot_motion_target_validated'][:] = False
    a.out.mkdir(parents=True)
    payload = a.out / 'robot-motion-proposal.npz'
    np.savez_compressed(payload, **original)
    dense_payload = a.out / 'generated-corridor-waypoints.npz'
    np.savez_compressed(dense_payload, timestamps_s=dense_times, robot_qpos_inferred=dense,
                        robot_pose_inference_kind=dense_kinds, robot_grasp_phase_details=dense_details,
                        robot_pose_is_inferred=np.ones(dense.shape[:2], dtype=bool), robot_motion_target_validated=np.zeros(dense.shape[:2], dtype=bool))
    report = {'source_sha256': sha(Path(__file__)), 'reused_corridor_evaluator_sha256': sha(Path(__file__).with_name('generated_corridor_motion_v2.py')),
              'reused_prior_and_blend_helper_sha256': sha(Path(__file__).with_name('propose_robot_contact_motion_v1.py')),
              'bundle_manifest_sha256': sha(a.bundle / 'manifest.json'), 'baseline_manifest_sha256': sha(a.baseline / 'manifest.json'),
              'parent_proposal_report_sha256': sha(a.parent_proposal / 'report.json'), 'interval_report_sha256': sha(a.interval_inputs / 'report.json'),
              'atlas_sha256': sha(a.atlas), 'robot_assets': motion.rm['robot_assets'], 'payload_sha256': sha(payload),
              'generated_waypoint_payload_sha256': sha(dense_payload), 'controls': tested, 'hold_controls': hold_controls,
              'source_frames': len(sampled), 'generated_timeline_samples': len(dense_times), 'grasp_input_locks': motion.locks,
              'phases': [{**{key: value for key, value in phase.items() if key not in ('qpath', 'clock')}, 'clock_s': phase['clock'].tolist()} for side in motion.sides for phase in side['phases']],
              'free_prior': 'original GitHub-retarget inferred wrist/root with neutral URDF fingers; missing observations remain missing',
              'free_prior_blend_duration_s': motion.free_blend, 'minimum_corridor_duration_s': .3, 'relative_root_planning_speed_m_s': 1.,
              'all_source_observation_and_hold_arrays_preserved': True, 'all_original_contact_intent_and_bridge_arrays_preserved': True,
              'all_four_automatic_grasps_retained': True, 'episode_specific_frames_or_crops': False,
              'all_generated_robot_poses_are_inferred': True, 'source_hand_pose_accuracy_accepted': False,
              'source_annotations_or_GT_used': False, 'contact_known': False,
              'unknown_entry_exit': 'certified corridor neutral endpoint plus existing smooth 0.2 m / 0.5 s object-tangent retreat; explicitly inferred',
              'unobserved_entry_exit_waypoint_counts': [side['unobserved_entry_exit_waypoint_count'] for side in motion.sides],
              'robot_inference_kinds': {'6': 'explicit unobserved approach/exit waypoint; source remains missing',
                  '2': 'original source-inferred hold anchors robot to object',
                  '3': 'bounded robot-intent bridge; original hand observation unchanged',
                  '7': 'GitHub-retarget inferred free wrist with neutral URDF fingers',
                  '9': 'generated grasp-specific opening corridor',
                  '10': 'generated neutral-finger blend between free wrist and corridor'},
              'full_scene_continuous_contact_table_or_penetration_accepted': False, 'new_simulator_run': False,
              'physical_task_accepted': False, 'status': 'complete timeline proposal; source, scene, simulator and continuous full-task checks pending'}
    (a.out / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'source_frames': len(sampled), 'generated_timeline_samples': len(dense_times), 'grasp_anchors_verified': hold_controls, 'physical_task_accepted': False}))


if __name__ == '__main__':
    main()
