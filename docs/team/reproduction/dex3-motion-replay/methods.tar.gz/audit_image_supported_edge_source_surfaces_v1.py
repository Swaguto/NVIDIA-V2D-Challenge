"""Check complete original hand triangle surfaces at every source timestamp.

This is a static certificate against the declared development material proxy,
with the actual source affine transforms and scales. It does not certify the
continuous path, physical object geometry, dynamics, table or source accuracy.
"""
import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np
import pinocchio as pin
import trimesh

from corrected_per_grasp_motion_v1 import load, sha
from exact_voxel_boundary_v1 import Boundary
from audit_static_hold_scene_triangles_v3 import material_box, mesh_certificate
from certify_uniform_metric_triangles_v1 import controls


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'bundle', 'baseline', 'proposal', 'material', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument("--reuse-parent-proposal", type=Path)
    p.add_argument("--reuse-parent-certificate", type=Path)
    a = p.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    tested = controls()
    report = json.loads((a.proposal / 'report.json').read_text())
    bm = json.loads((a.bundle / 'manifest.json').read_text())
    rm = json.loads((a.baseline / 'manifest.json').read_text())
    mm = json.loads((a.material / 'manifest.json').read_text())
    assert report['bundle_manifest_sha256'] == rm['episode_bundle_manifest_sha256'] == sha(a.bundle / 'manifest.json')
    assert report['baseline_manifest_sha256'] == sha(a.baseline / 'manifest.json')
    assert report['payload_sha256'] == sha(a.proposal / 'robot-motion-proposal.npz')
    assert bm['payload']['sha256'] == mm['source_bundle_payload_sha256'] == sha(a.bundle / 'episode.npz')
    assert report['material_manifest_sha256'] == sha(a.material / 'manifest.json')
    source, motion = load(a.bundle / 'episode.npz'), load(a.proposal / 'robot-motion-proposal.npz')
    for target, key in (('frame_indices','frame_indices'), ('timestamps_s','timestamps_s'),
                        ('source_hand_valid','hand_valid'), ('source_hand_directly_observed','hand_directly_observed')):
        np.testing.assert_array_equal(motion[target], source[key])
    assert motion['robot_pose_is_inferred'].all() and not motion['robot_motion_target_validated'].any()
    sys.path.insert(0, str(a.source / 'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    verify_robot_assets(report, a.source / 'source/robotic_grounding/robotic_grounding/assets')
    materials = {}
    for entry in mm['objects']:
        path = a.material / f"object_{entry['object']}.npz"
        assert sha(path) == entry['payload_sha256']
        g = load(path)
        boundary = Boundary(g['solid_cells'], g['origin_m'], float(g['pitch_m']))
        materials[entry['object']] = (boundary, material_box(boundary))
    hands, geometry = [], []
    for side in ('left','right'):
        kin = setup_dex3_kinematics(side=side, max_iter=1)
        geom = kin.robot.collision_model
        triangles = []
        for obj in geom.geometryObjects:
            mesh = trimesh.load(Path(obj.meshPath), force='mesh', process=False)
            tri = np.asarray(mesh.vertices, dtype=float)[mesh.faces]*np.asarray(obj.meshScale)
            triangles.append(tri)
            geometry.append({'side':side, 'mesh_sha256':sha(Path(obj.meshPath)), 'original_triangles':len(tri)})
        hands.append((kin,geom,geom.createData(),triangles))
    reused_rows = {}
    parent_q = None
    reuse_hash = None
    assert (a.reuse_parent_proposal is None)==(a.reuse_parent_certificate is None)
    if a.reuse_parent_proposal is not None:
        parent_report = json.loads((a.reuse_parent_proposal/"report.json").read_text())
        parent_certificate = json.loads((a.reuse_parent_certificate/"report.json").read_text())
        assert parent_report["payload_sha256"]==sha(a.reuse_parent_proposal/"robot-motion-proposal.npz")
        assert parent_report["robot_assets"]==report["robot_assets"]
        assert parent_certificate["proposal_report_sha256"]==sha(a.reuse_parent_proposal/"report.json")
        assert parent_certificate["bundle_manifest_sha256"]==sha(a.bundle/"manifest.json")
        assert parent_certificate["material_manifest_sha256"]==sha(a.material/"manifest.json")
        assert parent_certificate["source_sha256"]==sha(Path(__file__).with_name("audit_corrected_motion_source_surfaces_v2.py"))
        for key,filename in (("triangle_certificate_sha256","audit_static_hold_scene_triangles_v3.py"),("uniform_metric_certificate_sha256","certify_uniform_metric_triangles_v1.py"),("boundary_module_sha256","exact_voxel_boundary_v1.py")):
            assert parent_certificate[key]==sha(Path(__file__).with_name(filename))
        assert parent_certificate["original_geometry"]==geometry
        assert parent_certificate["all_source_state_original_surfaces_within_declared_2mm_material_limit"] and not parent_certificate["failed_or_unresolved_checks"]
        old = load(a.reuse_parent_proposal/"robot-motion-proposal.npz")
        np.testing.assert_array_equal(old["frame_indices"],source["frame_indices"])
        np.testing.assert_array_equal(old["timestamps_s"],source["timestamps_s"])
        parent_q = old["robot_qpos_inferred"]
        for record in parent_certificate["checks"]:
            key = (record["source_frame"],record["side"],record["against_object"])
            assert key not in reused_rows and record["triangle_material_limit_certified"]
            reused_rows[key] = record
        assert len(reused_rows)==len(source["frame_indices"])*2*len(materials)
        reuse_hash = sha(a.reuse_parent_certificate/"report.json")
    fresh_checks,reused_checks = 0,0
    rows, failures = [], []
    for row, frame in enumerate(source['frame_indices']):
        for si, (kin,geom,gd,original_triangles) in enumerate(hands):
            q = motion['robot_qpos_inferred'][row,si]
            kin.configuration.update(q)
            pin.updateGeometryPlacements(kin.robot.model,kin.configuration.data,geom,gd,q)
            world = np.concatenate([v @ tf.rotation.T + tf.translation for v,tf in zip(original_triangles,gd.oMg)])
            for oi, (boundary,box) in materials.items():
                key = (int(frame),("left","right")[si],oi)
                if parent_q is not None and np.array_equal(q,parent_q[row,si]):
                    record = dict(reused_rows[key])
                    record["reused_from_parent_certificate_sha256"] = reuse_hash
                    rows.append(record)
                    reused_checks += 1
                    continue
                fresh_checks += 1
                pose = source[f'object_{oi}_world'][row]
                scale = float(source[f'object_{oi}_scale'][row])
                matrix = pose[:3,:3]*scale
                assert np.linalg.det(matrix) > 0 and np.isfinite(matrix).all()
                canonical = (world-pose[:3,3]) @ np.linalg.inv(matrix).T
                certificate = mesh_certificate(boundary,box,canonical,matrix)
                record = {'source_frame':int(frame), 'side':('left','right')[si], 'against_object':oi,
                          'object_pose_provenance':bm['object_observation_provenance'][bm['objects'][oi]['name']][str(int(frame))],
                          'actual_source_affine_and_scale_preserved':True, **certificate}
                rows.append(record)
                if not certificate['triangle_material_limit_certified']:
                    failures.append(record)
        if row % 10 == 0:
            print(json.dumps({'source_frame':int(frame), 'complete_surface_checks':len(rows),
                              'failed_or_unresolved':len(failures), 'elapsed_seconds':time.monotonic()-started}),flush=True)
    a.out.mkdir(parents=True)
    final = {'source_sha256':sha(Path(__file__)), 'triangle_certificate_sha256':sha(Path(__file__).with_name('audit_static_hold_scene_triangles_v3.py')),
             'uniform_metric_certificate_sha256':sha(Path(__file__).with_name('certify_uniform_metric_triangles_v1.py')),
             'boundary_module_sha256':sha(Path(__file__).with_name('exact_voxel_boundary_v1.py')),
             'proposal_report_sha256':sha(a.proposal / 'report.json'), 'bundle_manifest_sha256':sha(a.bundle / 'manifest.json'),
             'material_manifest_sha256':sha(a.material / 'manifest.json'), 'controls':tested, 'original_geometry':geometry,
             'source_frames_checked':len(source['frame_indices']), 'complete_surface_checks':len(rows),
             "fresh_complete_surface_checks":fresh_checks, "exact_state_certificates_reused":reused_checks,
             "parent_certificate_sha256":reuse_hash,
             "reuse_requires_identical_source_bundle_material_original_assets_and_bit_exact_qpos":True,
             'all_source_state_original_surfaces_within_declared_2mm_material_limit':not failures,
             'failed_or_unresolved_checks':failures, 'checks':rows, 'all_original_source_masks_unchanged':True,
             'between_timestamp_continuous_clearance_checked':False, 'cross_hand_or_self_checked_here':False,
             'table_or_other_environment_checked':False, 'physical_material_geometry_ground_truth':False,
             'physical_task_accepted':False, 'elapsed_seconds':time.monotonic()-started}
    (a.out / 'report.json').write_text(json.dumps(final,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:final[k] for k in ('source_frames_checked','complete_surface_checks','all_source_state_original_surfaces_within_declared_2mm_material_limit','elapsed_seconds')}))


if __name__ == '__main__':
    main()
