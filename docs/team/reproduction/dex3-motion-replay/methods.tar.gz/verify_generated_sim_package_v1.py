"""Verify and restore a frozen private simulator-input archive using SHA256."""
import argparse
import hashlib
import json
import tarfile
from pathlib import Path, PurePosixPath


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive', type=Path, required=True)
    p.add_argument('--sha256', required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    assert sha(a.archive) == a.sha256, 'Archive bytes do not match the transfer receipt'
    assert not a.out.exists(), 'Use a fresh restoration directory'
    with tarfile.open(a.archive) as tar:
        members = tar.getmembers()
        names = [v.name for v in members]
        assert len(names) == len(set(names)), 'Duplicate tar member'
        for member in members:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
        manifest = json.load(tar.extractfile('file-manifest.json'))
        assert set(names) == set(manifest['files_sha256']) | {'file-manifest.json'}
        a.out.mkdir(parents=True)
        tar.extractall(a.out, filter='data')
    for name, expected in manifest['files_sha256'].items():
        assert sha(a.out / name) == expected, name
    result = {
        'archive_sha256': a.sha256, 'manifest_sha256': sha(a.out / 'file-manifest.json'),
        'verified_files': len(manifest['files_sha256']), 'episode': manifest['episode'],
        'status': 'all transferred input bytes verified', 'new_simulator_run': False,
        'physical_task_accepted': False,
    }
    (a.out / 'verified-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
