"""Track declared original pad faces through the actual per-grasp trajectory.

All source timestamps and analytic boundary/midpoint probes are evaluated.
Source-only labels enter validation after geometric measurements. Contact is a
development proxy; no observation, force or target acceptance is fabricated.
"""
import argparse
import json
from pathlib import Path
import sys
import time
import xml.etree.ElementTree as ET

import numpy as np
import trimesh
from scipy.spatial.transform import Rotation

from corrected_per_grasp_motion_v5 import CorrectedPerGraspMotion
from corrected_per_grasp_motion_v1 import load, sha
from closest_mesh_surface_v2 import Surface, closest_triangle_points, analytic_controls
from exact_voxel_boundary_v1 import Boundary, controls as boundary_controls


def affine_nearby_facets(boundary, point, robot_normal_world, matrix, translation, distance_limit=.002):
    """Retain every possibly near square; each passing foot is an actual face point."""
    singular = np.linalg.svd(matrix, compute_uv=False)
    radius = distance_limit/singular.min()+np.sqrt(2)*boundary.pitch/2+1e-12
    ids = np.asarray(sorted(boundary.tree.query_ball_point(point,radius,eps=0)),dtype=np.int64)
    if not len(ids):
        return []
    feet = boundary.centers[ids]+np.clip(point-boundary.centers[ids],-boundary.half[ids],boundary.half[ids])
    world_point = matrix @ point+translation
    world_feet = feet @ matrix.T+translation
    normals = np.zeros((len(ids),3))
    normals[np.arange(len(ids)),boundary.axes[ids]] = boundary.signs[ids]
    normals = normals @ np.linalg.inv(matrix)
    normals /= np.linalg.norm(normals,axis=1)[:,None]
    distance = np.linalg.norm(world_point-world_feet,axis=1)
    plane = np.einsum('ij,ij->i',world_point-(boundary.centers[ids] @ matrix.T+translation),normals)
    dots = normals @ robot_normal_world
    passing = (distance<=distance_limit+1e-12)&(plane>=-.0005-1e-12)&(dots<=-.5+1e-12)
    return [{'original_boundary_square_index':int(ids[i]),'distance_m':float(distance[i]),
             'signed_outward_plane_gap_m':float(plane[i]),'world_outward_normal':normals[i].tolist(),
             'robot_material_normal_dot':float(dots[i])} for i in np.flatnonzero(passing)]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','parent-proposal','interval-inputs','atlas','proposal','material','annotation','out'):
        p.add_argument('--'+name,type=Path,required=True)
    a = p.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    tested = {'original_triangle_controls':analytic_controls(),'exact_boundary_controls':boundary_controls()}
    motion = CorrectedPerGraspMotion(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,a.proposal)
    mm = json.loads((a.material/'manifest.json').read_text())
    assert mm['source_bundle_payload_sha256'] == sha(a.bundle/'episode.npz')
    assert motion.repair_report['material_manifest_sha256'] == sha(a.material/'manifest.json')
    sys.path.insert(0,str(a.source/'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    assets = a.source/'source/robotic_grounding/robotic_grounding/assets'
    verify_robot_assets(motion.repair_report,assets)
    boundaries = {}
    for entry in mm['objects']:
        path = a.material/f"object_{entry['object']}.npz"
        assert sha(path) == entry['payload_sha256']
        g = load(path)
        boundaries[entry['object']] = Boundary(g['solid_cells'],g['origin_m'],float(g['pitch_m']))
    dense = np.unique(np.r_[motion.breakpoints,(motion.breakpoints[:-1]+motion.breakpoints[1:])/2])
    timestamps = np.unique(np.r_[dense,(dense[:-1]+dense[1:])/2])
    original = load(a.proposal/'robot-motion-proposal.npz')
    geometry, records, phase_bindings = [], [], []
    for si,side in enumerate(('left','right')):
        kin = setup_dex3_kinematics(side=side,max_iter=1)
        tree = ET.parse(assets/f'urdfs/g1/dex3_{side}.urdf').getroot()
        surfaces = {}
        for finger,suffix in (('thumb','2'),('index','1')):
            name = f'{side}_hand_{finger}_{suffix}_link'
            collision = tree.find(f"link[@name='{name}']/collision")
            spec = collision.find('geometry/mesh')
            path = assets/'meshes'/spec.attrib['filename'].removeprefix('package://')
            mesh = trimesh.load(path,force='mesh',process=False)
            vertices = np.asarray(mesh.vertices,dtype=float)*np.fromstring(spec.attrib.get('scale','1 1 1'),sep=' ')
            origin = collision.find('origin')
            if origin is not None:
                vertices = vertices @ Rotation.from_euler('xyz',np.fromstring(origin.attrib.get('rpy','0 0 0'),sep=' ')).as_matrix().T+np.fromstring(origin.attrib.get('xyz','0 0 0'),sep=' ')
            surfaces[finger] = (name,Surface(vertices,mesh.faces))
            geometry.append({'side':side,'finger':finger,'mesh_sha256':sha(path),'original_triangles':len(mesh.faces)})
        for phase in motion.sides[si]['phases']:
            spec = next(v for v in motion.atlas['grasps'] if v['prefix']==phase['prefix'])
            template = json.loads((a.atlas.parent/spec['templates']/'report.json').read_text())
            assert sha(a.atlas.parent/spec['templates']/'report.json') == spec['templates_report_sha256']
            candidate = next(v for v in template['templates'] if v['side']==side and v['object']==phase['object'] and v.get('seed')==phase['seed'])
            np.testing.assert_array_equal(phase['qpath'][0],candidate['qpos_object_frame'])
            selected_times = timestamps[(timestamps>=phase['interval'][0]-phase['duration_s']-motion.free_blend-1e-10)&
                                        (timestamps<=phase['interval'][1]+phase['duration_s']+motion.free_blend+1e-10)]
            phase_bindings.append({'prefix':phase['prefix'],'template_report_sha256':spec['templates_report_sha256'],
                                   'closed_intent_interval_s':list(phase['interval']),'opening_duration_s':phase['duration_s'],
                                   'selected_original_triangles':{v['finger']:v['original_mesh_triangle_index'] for v in candidate['pads']},
                                   'source_and_analytic_timestamps_checked':len(selected_times)})
            for timestamp in selected_times:
                q,_,detail = motion.evaluate(float(timestamp))
                kin.configuration.update(q[si])
                matrix_no_scale,translation,scale = motion.object_pose(phase['object'],float(timestamp))
                matrix = matrix_no_scale*scale
                inverse = np.linalg.inv(matrix)
                singular = np.linalg.svd(matrix,compute_uv=False)
                boundary = boundaries[phase['object']]
                pads = []
                for intended in candidate['pads']:
                    finger = intended['finger']
                    name,surface = surfaces[finger]
                    tf = kin.configuration.get_transform_frame_to_world(name)
                    target_local_object = np.asarray(intended['target_object_scaled_m'])/candidate['template_reference_scale']
                    target_world = matrix @ target_local_object+translation
                    target_link = tf.rotation.T @ (target_world-tf.translation)
                    fixed_id = int(intended['original_mesh_triangle_index'])
                    fixed_point = closest_triangle_points(surface.triangles[fixed_id:fixed_id+1],target_link[None])[0]
                    full_point,full_normal,full_id,full_gap,count = surface.nearest(target_link)
                    for kind,point,normal,face,gap in (
                            ('declared_fixed_face',fixed_point,surface.normals[fixed_id],fixed_id,float(np.linalg.norm(fixed_point-target_link))),
                            ('full_original_pad',full_point,full_normal,full_id,full_gap)):
                        world = tf.rotation @ point+tf.translation
                        robot_normal = tf.rotation @ normal
                        canonical = inverse @ (world-translation)
                        distance,_,_ = boundary.unsigned(canonical[None])
                        inside = bool(boundary.inside(canonical[None])[0])
                        signed_low,signed_high = ((-distance[0]*singular.max(),-distance[0]*singular.min()) if inside else
                                                  (distance[0]*singular.min(),distance[0]*singular.max()))
                        facets = affine_nearby_facets(boundary,canonical,robot_normal,matrix,translation)
                        eligible = gap<=.002+1e-12 and signed_low>=-.0005-1e-12 and signed_high<=.002+1e-12 and bool(facets)
                        pads.append({'finger':finger,'geometry_kind':kind,'original_triangle_index':face,
                                     'target_gap_m':gap,'signed_material_gap_lower_m':float(signed_low),'signed_material_gap_upper_m':float(signed_high),
                                     'robot_point_world_m':world.tolist(),'target_point_world_m':target_world.tolist(),
                                     'robot_normal_world':robot_normal.tolist(),'possible_facing_facets':facets,'geometric_pad_proxy':bool(eligible),
                                     'full_pad_complete_candidate_triangles':count})
                passing = {}
                for kind in ('declared_fixed_face','full_original_pad'):
                    selected = [v for v in pads if v['geometry_kind']==kind]
                    assert {v['finger'] for v in selected} == {'thumb','index'}
                    first,second = (next(v for v in selected if v['finger']==f) for f in ('thumb','index'))
                    dots = [float(np.dot(f['world_outward_normal'],s['world_outward_normal']))
                            for f in first['possible_facing_facets'] for s in second['possible_facing_facets']]
                    passing[kind] = all(v['geometric_pad_proxy'] for v in selected) and bool(dots) and min(dots)<=-.5+1e-12
                row,frac = motion.bracket(float(timestamp))
                exact_source_rows = np.flatnonzero(motion.times==timestamp)
                source_row = int(exact_source_rows[0]) if len(exact_source_rows) else None
                records.append({'prefix':phase['prefix'],'side':side,'object':phase['object'],'timestamp_s':float(timestamp),
                                'source_frame':None if source_row is None else int(motion.source['frame_indices'][source_row]),
                                'source_hand_valid':None if source_row is None else bool(motion.source['hand_valid'][source_row,si]),
                                'source_hand_directly_observed':None if source_row is None else bool(motion.source['hand_directly_observed'][source_row,si]),
                                'closed_intent_at_timestamp':bool(phase['interval'][0]<=timestamp<=phase['interval'][1]),
                                'phase_opening_clock_s':float(detail[si,2]),'prior_blend_weight':float(detail[si,3]),
                                'pads':pads,'declared_faces_two_pad_opposition_proxy':bool(passing['declared_fixed_face']),
                                'full_pad_two_pad_opposition_proxy':bool(passing['full_original_pad'])})
            print(json.dumps({'completed_grasp':phase['prefix'],'geometric_samples':len(selected_times),'elapsed_seconds':time.monotonic()-started}),flush=True)
    # Only now read the independent source annotations, for validation.
    labels = json.loads(a.annotation.read_text())
    validation = []
    bm = json.loads((a.bundle/'manifest.json').read_text())
    for label in labels['visible_grasp_intervals']:
        oi = next(v['index'] for v in bm['objects'] if v['name']==label['object_id'])
        core_frames = list(range(label['definite_core_start_frame'],label['definite_core_end_frame']+1))
        selected = [v for v in records if v['side']==label['hand'] and v['object']==oi and v['source_frame'] in core_frames]
        by_frame = {v['source_frame']:v for v in selected}
        assert len(by_frame)==len(selected), 'Overlapping grasp review windows must be disambiguated'
        missing_fixed = [f for f in core_frames if f not in by_frame or not by_frame[f]['declared_faces_two_pad_opposition_proxy']]
        missing_full = [f for f in core_frames if f not in by_frame or not by_frame[f]['full_pad_two_pad_opposition_proxy']]
        validation.append({'grasp_id':label['grasp_id'],'source_definite_core_frames':core_frames,
                           'declared_fixed_face_proxy_missing_core_frames':missing_fixed,
                           'full_original_pad_proxy_missing_core_frames':missing_full,
                           'core_frames_not_sampled': [f for f in core_frames if f not in by_frame],
                           'declared_face_proxy_core_fraction':1-len(missing_fixed)/len(core_frames),
                           'full_pad_proxy_core_fraction':1-len(missing_full)/len(core_frames)})
    a.out.mkdir(parents=True)
    final = {'source_sha256':sha(Path(__file__)), 'motion_module_sha256':sha(Path(__file__).with_name('corrected_per_grasp_motion_v5.py')),
             'surface_module_sha256':sha(Path(__file__).with_name('closest_mesh_surface_v2.py')),
             'boundary_module_sha256':sha(Path(__file__).with_name('exact_voxel_boundary_v1.py')),
             'proposal_report_sha256':sha(a.proposal/'report.json'),'bundle_manifest_sha256':sha(a.bundle/'manifest.json'),
             'atlas_sha256':sha(a.atlas),'material_manifest_sha256':sha(a.material/'manifest.json'),
             'annotation_sha256':sha(a.annotation),'controls':tested,'original_geometry':geometry,
             'phase_bindings':phase_bindings,'measurements':records,'source_label_validation':validation,
             'target_and_contact_distance_limit_m':.002,'interior_tolerance_m':.0005,'opposition_normal_dot_limit':-.5,
             'labels_read_only_after_all_geometric_measurements':True,'source_observation_arrays_changed':False,
             'contact_force_or_grasp_stability_measured':False,'continuous_contact_certificate':False,
             'physical_task_accepted':False,'new_simulator_run':False,'elapsed_seconds':time.monotonic()-started}
    (a.out/'report.json').write_text(json.dumps(final,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'samples':len(records),'source_label_validation':validation,'physical_task_accepted':False}))


if __name__ == '__main__':
    main()
