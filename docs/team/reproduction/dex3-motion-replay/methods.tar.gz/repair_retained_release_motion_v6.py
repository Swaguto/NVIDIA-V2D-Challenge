"""Repair locked penetration witnesses in inferred noncontact robot motion.

Use automatic source-bracket windows with fixed shoulders, clamped outside every
inferred grasp. Reuse the existing original-surface translation solver. Human
observations remain unchanged even where an inferred robot prior is corrected.
"""
import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np
import pinocchio as pin
import trimesh
from scipy.ndimage import distance_transform_edt

from retained_source_following_release_motion_v7 import RetainedReleaseMotion
from corrected_per_grasp_motion_v1 import load, sha
from corrected_per_grasp_motion_v5 import window_weight
from exact_voxel_boundary_v1 import Boundary
from audit_static_hold_scene_triangles_v3 import material_box
from solve_depth_consistent_translation_v7 import solve_translation
from release_repair_witnesses_v1 import collect_witnesses
from fit_dex3_source_grasp_v14 import trilinear


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','parent-proposal','interval-inputs','atlas','proposal','probe','material','out'):
        p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--repair-shoulder-seconds',type=float,default=.2)
    p.add_argument('--source-surface-audit',type=Path,required=True)
    p.add_argument('--witness-repair-attempt',type=Path)
    a = p.parse_args()
    assert not a.out.exists() and 0<a.repair_shoulder_seconds<=.5
    assert a.proposal.parent.resolve()==a.out.parent.resolve()
    started = time.monotonic()
    base = RetainedReleaseMotion(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,a.proposal)
    probe = json.loads((a.probe/'report.json').read_text())
    mm = json.loads((a.material/'manifest.json').read_text())
    assert probe['proposal_report_sha256']==sha(a.proposal/'report.json')
    assert probe['corrected_motion_module_sha256']==sha(Path(__file__).with_name('retained_source_following_release_motion_v7.py'))
    assert probe['bundle_manifest_sha256']==sha(a.bundle/'manifest.json')
    assert probe['material_manifest_sha256']==sha(a.material/'manifest.json')
    assert probe['payload_sha256']==sha(a.probe/'midpoint-probe.npz')
    assert mm['source_bundle_payload_sha256']==sha(a.bundle/'episode.npz')
    failed, surface_evidence = collect_witnesses(base,probe,a.source_surface_audit,a.proposal,a.bundle,a.material)
    surface = json.loads((a.source_surface_audit/'report.json').read_text())
    frame_rows = {int(frame):row for row,frame in enumerate(base.source['frame_indices'])}
    known_surface_points = {}
    for record in surface['failed_or_unresolved_checks']:
        row = frame_rows[record['source_frame']]
        si = ('left','right').index(record['side'])
        oi = record['against_object']
        pose = base.source[f'object_{oi}_world'][row]
        matrix = pose[:3,:3]*float(base.source[f'object_{oi}_scale'][row])
        point = np.asarray(record['witness']['point_object_local_m'])@matrix.T+pose[:3,3]
        known_surface_points.setdefault((float(base.times[row]),si),[]).append(point)

    assert failed
    groups = {}
    for timestamp,si in failed:
        row,_ = base.bracket(timestamp)
        ta = max(float(base.times[0]),float(base.times[row])-a.repair_shoulder_seconds)
        tb = min(float(base.times[-1]),float(base.times[row+1])+a.repair_shoulder_seconds)
        for phase in base.sides[si]['phases']:
            first,last = phase['interval']
            if timestamp<first:
                tb = min(tb,first)
            elif timestamp>last:
                ta = max(ta,last)
            else:
                raise AssertionError('Penetration inside an inferred grasp requires a new fit, not free-motion repair')
        ta = float(base.times[np.searchsorted(base.times,ta-1e-10,side='left')])
        tb = float(base.times[np.searchsorted(base.times,tb+1e-10,side='right')-1])
        assert ta<timestamp<tb
        groups.setdefault((si,ta,tb),[]).append(timestamp)
    # Merge overlapping automatic witness shoulders, retaining all witness
    # times. Original holds were already used to clamp every window.
    merged = {}
    for si in range(2):
        spans = sorted((ta,tb,groups[(si,ta,tb)]) for s,ta,tb in groups if s==si)
        pending = None
        for ta,tb,witnesses in spans:
            if pending is None:
                pending = (ta,tb,list(witnesses))
            elif ta<=pending[1]:
                pending = (pending[0],max(tb,pending[1]),pending[2]+list(witnesses))
            else:
                merged[(si,pending[0],pending[1])] = sorted(set(pending[2]))
                pending = (ta,tb,list(witnesses))
        if pending is not None:
            merged[(si,pending[0],pending[1])] = sorted(set(pending[2]))
    groups = merged
    sys.path.insert(0,str(a.source/'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    verify_robot_assets(base.repair_report,a.source/'source/robotic_grounding/robotic_grounding/assets')
    materials = {}
    for entry in mm['objects']:
        path = a.material/f"object_{entry['object']}.npz"
        assert sha(path)==entry['payload_sha256']
        z = load(path)
        solid,origin,pitch = z['solid_cells'],z['origin_m'],float(z['pitch_m'])
        field = (distance_transform_edt(~solid)-distance_transform_edt(solid))*pitch
        field = np.where(solid,field+pitch/2,field-pitch/2)
        boundary = Boundary(solid,origin,pitch)
        materials[entry['object']] = (field,origin,pitch,boundary,material_box(boundary))
    attempt_hash = None
    warm_witness_count = 0
    if a.witness_repair_attempt is not None:
        previous = json.loads((a.witness_repair_attempt/'report.json').read_text())
        assert previous['physical_task_accepted'] is False
        assert previous['base_retained_release_report_sha256']==sha(a.proposal/'report.json')
        assert previous['automatic_failure_probe_report_sha256']==sha(a.probe/'report.json')
        assert previous['bundle_manifest_sha256']==sha(a.bundle/'manifest.json')
        assert previous['material_manifest_sha256']==sha(a.material/'manifest.json')
        assert previous['robot_assets']==base.repair_report['robot_assets']
        assert previous['source_sha256']==sha(Path(__file__).with_name('repair_retained_release_motion_v3.py'))
        assert previous['coupled_solver_sha256']==sha(Path(__file__).with_name('solve_depth_consistent_translation_v5.py'))
        assert previous['payload_sha256']==sha(a.witness_repair_attempt/'robot-motion-proposal.npz')
        assert previous['translation_profiles_sha256']==sha(a.witness_repair_attempt/previous['translation_profiles'])
        attempt_hash = sha(a.witness_repair_attempt/'report.json')
        for audit in previous['translation_profile_audits']:
            profile = audit['profile']
            si = ('left','right').index(profile['side'])
            timestamps = profile['all_constrained_timestamps_s']
            for cycle in audit['history']:
                vector = np.asarray(cycle['translation_amplitude_m'])
                for certificate in cycle['original_surface_certificates']:
                    if certificate['triangle_material_limit_certified'] or certificate['witness'] is None:
                        continue
                    timestamp = float(timestamps[certificate['context']])
                    oi = certificate['against_object']
                    rotation,translation,scale = base.object_pose(oi,timestamp)
                    world = np.asarray(certificate['witness']['point_object_local_m']) @ (rotation*scale).T + translation
                    world -= vector*window_weight(timestamp,profile['time_start_s'],profile['time_end_s'])
                    known_surface_points.setdefault((timestamp,si),[]).append(world)
                    warm_witness_count += 1
        print(json.dumps({'stage':'rejected_geometry_witnesses_loaded','count':warm_witness_count}),flush=True)
    a.out.mkdir(parents=True)
    profiles,audits = [],[]
    for (si,ta,tb),witness_times in sorted(groups.items()):
        kin = setup_dex3_kinematics(side=('left','right')[si],max_iter=1)
        geom,points,faces = kin.robot.collision_model,[],[]
        gd = geom.createData()
        for obj in geom.geometryObjects:
            mesh = trimesh.load(Path(obj.meshPath),force='mesh',process=False)
            vertices,inverse = np.unique(np.asarray(mesh.vertices,dtype=float),axis=0,return_inverse=True)
            vertices *= np.asarray(obj.meshScale)
            points.append(vertices);faces.append(vertices[inverse[mesh.faces]])
        # Constrain every available analytic probe inside the window, as well as
        # every source timestamp and the actual failing witness.
        with np.load(a.probe/'midpoint-probe.npz',allow_pickle=False) as z:
            probe_times = z['generated_timestamps_s']
        timestamps = sorted(set(witness_times)|{float(t) for t in np.r_[base.times,probe_times] if ta<t<tb})
        contexts = []
        for timestamp in timestamps:
            q = base.evaluate(timestamp)[0][si]
            kin.configuration.update(q)
            pin.updateGeometryPlacements(kin.robot.model,kin.configuration.data,geom,gd,q)
            poses = {}
            for oi in materials:
                rotation,translation,scale = base.object_pose(oi,timestamp)
                matrix = rotation*scale
                poses[oi] = (translation,matrix,np.linalg.inv(matrix))
            world = np.concatenate([v@tf.rotation.T+tf.translation for v,tf in zip(points,gd.oMg)])
            active = []
            for oi,(field,origin,pitch,_,_) in materials.items():
                translation,_,inverse = poses[oi]
                coords = ((world-translation)@inverse.T-origin)/pitch
                value,_ = trilinear(field,coords)
                active.append(int(value.argmin()))
            initial = world[np.unique(active)].copy()
            # Start with known original-triangle interior witnesses as well.
            # These are geometry constraints, never source annotations or GT.
            known = known_surface_points.get((timestamp,si),[])
            if known:
                initial = np.concatenate((initial,np.asarray(known)))
            # One original triangle array serves every context. Fixed FK
            # transforms reconstruct the complete surface for each certificate.
            transforms = [(tf.rotation.copy(),tf.translation.copy()) for tf in gd.oMg]
            def original_triangles(transforms=transforms):
                return np.concatenate([v@rotation.T+translation for v,(rotation,translation) in zip(faces,transforms)])
            contexts.append({'world':initial,'triangles_loader':original_triangles,
                             'poses':poses,'weight':window_weight(timestamp,ta,tb)})
            if len(contexts)%25==0:
                print(json.dumps({'stage':'context_setup','contexts':len(contexts),'total_contexts':len(timestamps)}),flush=True)
        print(json.dumps({'stage':'certificate_driven_solve','contexts':len(contexts),
                          'initial_active_original_vertices':sum(len(v['world']) for v in contexts)}),flush=True)
        vector,history,seeds,selected,cuts,passed,error = solve_translation(contexts,materials)
        passed = bool(passed)
        profile = {'side':('left','right')[si],'time_start_s':ta,'time_end_s':tb,'translation_amplitude_m':vector.tolist(),
                   'automatic_witness_times_s':witness_times,'all_constrained_timestamps_s':timestamps,
                   'gate':'sin(pi*fraction)^2 inside; exactly zero outside','repair_shoulder_seconds':a.repair_shoulder_seconds}
        profiles.append(profile)
        audits.append({'profile':profile,'original_surface_checks_passed':passed,'history':history,
                       'geometry_only_initializations':seeds,'selected_initialization_index':selected,
                       'new_witness_constraints':cuts,'weighted_affine_gradient_max_error':error,
                       'profile_speed_bound_m_s':float(np.pi*np.linalg.norm(vector)/(tb-ta)),
                       'profile_acceleration_bound_m_s2':float(2*np.pi**2*np.linalg.norm(vector)/(tb-ta)**2)})
        partial = {'status':'partial_not_accepted','source_sha256':sha(Path(__file__)),
                   'coupled_solver_sha256':sha(Path(__file__).with_name('solve_depth_consistent_translation_v7.py')),
                   'base_report_sha256':sha(a.proposal/'report.json'),
                   'completed_profiles':len(profiles),'translation_profile_audits':audits,
                   'full_run_terminal':False,'physical_task_accepted':False}
        (a.out/'profile-checkpoint.json').write_text(json.dumps(partial,indent=2)+'\n')
        print(json.dumps({'profiles_completed':len(profiles),'surface_checks_passed':passed,'elapsed_seconds':time.monotonic()-started}),flush=True)
        if not passed:
            raise SystemExit('Full surface profile refused; saved partial checkpoint; no dependent stage')
    data = load(a.proposal/'robot-motion-proposal.npz')
    before = data['robot_qpos_inferred'].copy()
    extra = np.zeros(before.shape[:2]+(3,))
    for profile in profiles:
        si = ('left','right').index(profile['side'])
        weights = np.array([window_weight(float(t),profile['time_start_s'],profile['time_end_s']) for t in base.times])
        extra[:,si] += weights[:,None]*profile['translation_amplitude_m']
    changed = np.any(extra!=0,axis=2)
    assert not changed[data['robot_contact_intent_inferred'].any(axis=2)].any()
    data['robot_qpos_inferred'][:,:,:3] += extra
    data['robot_transition_translation_delta_m'] += extra
    data['robot_pose_inference_kind'][changed] = 14
    payload = a.out/'robot-motion-proposal.npz'
    np.savez_compressed(payload,**data)
    path = a.out/'translation-profiles.json'
    path.write_text(json.dumps({'profiles':profiles},indent=2)+'\n')
    report = dict(base.repair_report)
    report.pop('generated_waypoint_payload_sha256',None)
    report.pop('dense_timeline_samples',None)
    report.update(source_sha256=sha(Path(__file__)),motion_module_sha256=sha(Path(__file__).with_name('repaired_retained_release_motion_v4.py')),
                  base_retained_release_proposal=a.proposal.name,base_retained_release_report_sha256=sha(a.proposal/'report.json'),
                  automatic_failure_probe_report_sha256=sha(a.probe/'report.json'),payload_sha256=sha(payload),
                  surface_witness_evidence=surface_evidence,rejected_attempt_witness_report_sha256=attempt_hash,rejected_attempt_witnesses_loaded=warm_witness_count,
                  failed_profile_or_certificate_reused_for_acceptance=False,exact_boundary_witness_search=True,
                  known_original_triangle_witness_points_in_initial_constraints=True,
                  translation_profiles=path.name,translation_profiles_sha256=sha(path),translation_profile_audits=audits,
                  failed_or_unresolved_translation_profiles=[v for v in audits if not v['original_surface_checks_passed']],
                  coupled_solver_sha256=sha(Path(__file__).with_name('solve_depth_consistent_translation_v7.py')),
                  added_corrected_source_states=int(changed.sum()),
                  changed_inferred_source_states=int(changed.sum()),
                  changed_source_frames_by_side={s:base.source['frame_indices'][changed[:,si]].tolist() for si,s in enumerate(('left','right'))},
                  maximum_added_translation_norm_m=max(float(np.linalg.norm(v['profile']['translation_amplitude_m'])) for v in audits),
                  maximum_permitted_translation_norm_m=.010,certificate_search_headroom_m=.0001,
                  original_triangles_loaded_per_certificate=True,certificate_driven_constraint_generation=True,
                  geometry_downsampled_for_acceptance=False,
                  optimizer_success_all_cycles=all(c['solver']['success'] for v in audits for c in v['history']),changed_robot_priors_with_valid_human_source_observations=int(changed[base.source['hand_valid']].sum()),
                  all_original_source_arrays_and_inferred_grasp_anchors_unchanged=True,
                  source_annotations_or_GT_used=False,complete_scene_clearance_certified=False,
                  physical_task_accepted=False,new_simulator_run=False,elapsed_seconds=time.monotonic()-started)
    report['robot_inference_kinds'] = {**report['robot_inference_kinds'],'14':'geometry-derived smooth noncontact translation; human observations unchanged'}
    (a.out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False,default=lambda value:value.item())+'\n')
    print(json.dumps({'profiles':len(profiles),'unresolved':len(report['failed_or_unresolved_translation_profiles']),'changed_states':int(changed.sum()),'physical_task_accepted':False}))


if __name__=='__main__':
    main()
