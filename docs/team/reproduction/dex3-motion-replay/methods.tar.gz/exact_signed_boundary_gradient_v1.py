"""Signed clearance and a nearest-face gradient for the frozen voxel union.

This is a search objective over inferred material, not physical object truth.
Original triangle certificates remain the acceptance test.
"""
import numpy as np


def signed_clearance_gradient(boundary, points):
    points = np.asarray(points, dtype=float)
    distance, face, _ = boundary.unsigned(points)
    closest = np.clip(points, boundary.centers[face] - boundary.half[face],
                      boundary.centers[face] + boundary.half[face])
    sign = np.where(boundary.inside(points), -1., 1.)
    gradient = np.zeros_like(points)
    nonzero = distance > 1e-14
    gradient[nonzero] = sign[nonzero, None] * (points[nonzero] - closest[nonzero]) / distance[nonzero, None]
    zero = ~nonzero
    gradient[np.flatnonzero(zero), boundary.axes[face[zero]]] = boundary.signs[face[zero]]
    return sign * distance, gradient
