"""Development-only source-region grasp templates, not source hand repairs.

Fit static Dex3 geometry to material-surface targets at its actual finger spread.
Source pixel evidence supplies the region; hidden contacts, hand offsets and
robot orientations remain inferred. No annotations, GT or display holds enter.
"""
import argparse
import hashlib
import json
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import pinocchio as pin
import trimesh
from scipy.ndimage import distance_transform_edt
from scipy.optimize import minimize, least_squares
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from dex3_self_distance_v5 import SelfDistances
from closest_mesh_surface_v2 import Surface,closest_triangle_points
from exact_voxel_boundary_v1 import Boundary
from audit_source_scene_triangle_bound_v2 import certify

def sha(path):
    with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()

def left_jacobian(rotvec):
    angle=np.linalg.norm(rotvec)
    skew=pin.skew(rotvec)
    if angle<1e-6:return np.eye(3)+skew/2+skew@skew/6
    return np.eye(3)+(1-np.cos(angle))/angle**2*skew+(angle-np.sin(angle))/angle**3*(skew@skew)

def trilinear(field,coordinates):
    inside=np.all((coordinates>=0)&(coordinates<=np.array(field.shape)-1),axis=1)
    base=np.floor(coordinates).astype(np.int64)
    base=np.clip(base,0,np.array(field.shape)-2)
    fraction=coordinates-base
    value=np.zeros(len(coordinates));gradient=np.zeros((len(coordinates),3))
    for a in (0,1):
        for b in (0,1):
            for c in (0,1):
                bits=np.array([a,b,c]);w=np.where(bits,fraction,1-fraction)
                signed=np.where(bits,1.,-1.)
                sample=field[base[:,0]+a,base[:,1]+b,base[:,2]+c]
                value+=sample*w.prod(axis=1)
                for axis in range(3):
                    other=[k for k in range(3) if k!=axis]
                    gradient[:,axis]+=sample*signed[axis]*w[:,other].prod(axis=1)
    value[~inside]=1.;gradient[~inside]=0
    return value,gradient

def interpolation_controls():
    x,y,z=np.meshgrid(np.arange(5.),np.arange(5.),np.arange(5.),indexing='ij')
    field=x+2*y-3*z+.3*x*y*z
    points=np.array([[1.2,2.3,.4],[.5,.7,3.4]])
    values,gradient=trilinear(field,points)
    expected=points[:,0]+2*points[:,1]-3*points[:,2]+.3*points.prod(axis=1)
    np.testing.assert_allclose(values,expected,atol=1e-12)
    worst=0.
    for axis in range(3):
        step=np.zeros_like(points);step[:,axis]=1e-6
        plus,_=trilinear(field,points+step);minus,_=trilinear(field,points-step)
        worst=max(worst,float(np.max(np.abs((plus-minus)/2e-6-gradient[:,axis]))))
    assert worst<1e-8
    return {'trilinear_derivative_max_error':worst,'coordinates_checked':3}

def boundary_faces(solid,origin,pitch):
    points=[];normals=[]
    for axis in range(3):
        for sign in (-1,1):
            neighbor=np.roll(solid,-sign,axis=axis)
            edge=[slice(None)]*3;edge[axis]=-1 if sign==1 else 0
            neighbor[tuple(edge)]=False
            indices=np.argwhere(solid&~neighbor)
            p=origin+indices*pitch;p[:,axis]+=sign*pitch/2
            normal=np.zeros((len(p),3));normal[:,axis]=sign
            points.append(p);normals.append(normal)
    return np.concatenate(points),np.concatenate(normals)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','regions','material','warm-start','digits','out'):
        parser.add_argument('--'+name,type=Path,required=True)
    a=parser.parse_args()
    controls=json.loads((Path(__file__).parent/'self-distance-controls-v5.json').read_text())
    assert controls['gradient_accepted']
    assert controls['self_distance_source_sha256']==sha(Path(__file__).parent/'dex3_self_distance_v5.py')
    surface_controls=json.loads((Path(__file__).parent/'closest-robot-surface-controls-v3.json').read_text())
    assert surface_controls['surface_module_sha256']==sha(Path(__file__).parent/'closest_mesh_surface_v2.py')
    assert all(v['maximum_exhaustive_oracle_distance_error_m']<1e-10 for v in surface_controls['meshes'])
    started=time.monotonic()
    assert not a.out.exists()
    a.out.mkdir(parents=True)
    sys.path.insert(0,str(a.source/'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    from robotic_grounding.retarget.track3_collision_voxels import solid_depth_bounds
    bm=json.loads((a.bundle/'manifest.json').read_text())
    rm=json.loads((a.baseline/'manifest.json').read_text())
    rr=json.loads((a.regions/'report.json').read_text())
    mm=json.loads((a.material/'manifest.json').read_text())
    warm=json.loads((a.warm_start/'report.json').read_text())
    digits=json.loads((a.digits/'report.json').read_text())
    assert digits['region_report_sha256']==sha(a.regions/'report.json')
    assert digits['bundle_manifest_sha256']==sha(a.bundle/'manifest.json')
    assert digits['payload_sha256']==sha(a.digits/'digits.npz')
    assert warm['bundle_manifest_sha256']==sha(a.bundle/'manifest.json')
    # Earlier inferred templates may seed the new source-region diagnostic;
    # their different region hash is retained, not silently rebound.
    assert warm['robot_assets']==rm['robot_assets']
    assert warm['material_manifest_sha256']==sha(a.material/'manifest.json')
    assert rr['bundle_manifest_sha256']==sha(a.bundle/'manifest.json')==rm['episode_bundle_manifest_sha256']
    assert rr['regions_payload_sha256']==sha(a.regions/'regions.npz')
    assert rm['payload']['sha256']==sha(a.baseline/'retarget.npz')
    assert bm['payload']['sha256']==sha(a.bundle/'episode.npz')==mm['source_bundle_payload_sha256']
    assets=a.source/'source/robotic_grounding/robotic_grounding/assets'
    verify_robot_assets(rm,assets)
    with np.load(a.bundle/'episode.npz',allow_pickle=False) as archive:d={k:archive[k] for k in archive.files}
    with np.load(a.baseline/'retarget.npz',allow_pickle=False) as archive:q={k:archive[k] for k in archive.files}
    with np.load(a.regions/'regions.npz',allow_pickle=False) as archive:r={k:archive[k] for k in archive.files}
    assert np.array_equal(r['source_hand_valid'],d['hand_valid']) and np.array_equal(r['source_hand_directly_observed'],d['hand_directly_observed'])
    protocol={'source_sha256':sha(Path(__file__)),'bundle_manifest_sha256':sha(a.bundle/'manifest.json'),
              'baseline_manifest_sha256':sha(a.baseline/'manifest.json'),'region_report_sha256':sha(a.regions/'report.json'),
              'material_manifest_sha256':sha(a.material/'manifest.json'),'robot_assets':rm['robot_assets'],
              'self_clearance_module_sha256':sha(Path(__file__).parent/'dex3_self_distance_v5.py'),
              'self_clearance_control_receipt_sha256':sha(Path(__file__).parent/'self-distance-controls-v5.json'),
              'self_clearance':'all21nonadjacent link convex hull pairs, signed clearance>=0.5mm, saturated above5mm with the same feasible set; original triangle meshes independently audited',
              'self_clearance_margin_m':.0005,'self_distance_saturation_m':.005,
              'method':'original-mesh-hull and actual-region morphology feasibility only: static inferred robot grasp offsets from source-supported region and model geometry; offset does not repair human tracking',
              'maximum_samples_per_collision_link':768,'root_translation_norm_bound_m':.080,
              'root_rotation_delta_norm_bound_rad':np.pi,'collision_surrogate_margin_m':.0005,
              'minimum_total_region_points':64,'minimum_source_frames':10,'max_iterations_per_seed':200,
              'feasibility_initialization':'L-BFGS-B100iterations, bounded scalar surface-distance least squares200evaluations with exact envelope derivatives, collision hinge weight1000, norm guard weight1000; then hard SLSQP',
              'pad_target_metric':'exact nearest point on every original distal triangle; KD complete candidate bound; scalar distance residual, not a fixed-point vector residual derivative',
              'surface_module_sha256':sha(Path(__file__).parent/'closest_mesh_surface_v2.py'),
              'surface_control_receipt_sha256':sha(Path(__file__).parent/'closest-robot-surface-controls-v3.json'),
              'material_cutting_planes':'up to five automatic original-surface witness points per seed; full-triangle depth certificate against target material after each fit; any explicit intrusion or unresolved surface refuses certification',
              'material_surface_limit_m':.002,'maximum_added_surface_witnesses_per_seed':5,
              'witness_constraints_carried_between_seeds':False,
              'full_triangle_certificate_source_sha256':sha(Path(__file__).parent/'audit_source_scene_triangle_bound_v2.py'),
              'translation_parameters':'millimetres relative to source root, converted to metres for FK',
              'warm_start_report_sha256':sha(a.warm_start/'report.json'),'warm_start_region_report_sha256':warm['region_report_sha256'],'warm_start_region_matches_new_regions':warm['region_report_sha256']==sha(a.regions/'report.json'),
              'digit_region_report_sha256':sha(a.digits/'report.json'),
              'digit_region_labels':'inferred nearest original source joint chains evaluated at actual stereo points; no finger/contact observations upgraded',
              'region_point_source':'actual stereo points, nearest CAD samples not substituted',
              'contact_face_hypotheses':'enumerate both opposing assignments; hidden-contact sidedness remains inferred, not determined by visible anatomy',
              'source_anatomy_assignment_is_unique_truth':False,
              'contact_layout':'source-supported robot thumb/index two-pad pinch; enumerate every reliable non-thumb source digit-region as the robot index contact region; third robot finger collision-constrained only; anatomical names remain inferred source labels, not a literal human-to-robot digit correspondence',
              'contact_partner_regions_enumerated':['index','middle','ring','pinky'],
              'partner_region_minimum_points':32,'partner_region_minimum_source_frames':10,
              'all_hypotheses_retained_not_episode_selected':True,
              'contact_feature_selection':'for each seed and planned pad, select the nearest original distal triangle among faces already satisfying declared material-facing dot<=-0.5; retain its index throughout fitting and witness refits',
              'selected_face_is_a_contact_hypothesis':True,'globally_closest_face_after_fit_is_separate_diagnostic':True,
              'normal_constraints_use_fixed_original_triangle':True,
              'declared_pad_target_face_normal_dot_limit':-.5,'normal_initialization_hinge_weight':1000.,
              'normal_constraint_derivative_control_tolerance':1e-5,
              'three_pad_grasp_claimed':False,
              'minimum_digit_region_points':32,'minimum_digit_source_frames':10,
              'warm_start_selection':'lowest objective two per assignment among earlier finite templates obeying80mm/pi norm guards and vertex lower depth<=2mm, plus all four source/adapted rotation seeds and four neutral self-safe finger seeds',
              'target_contact_layout':'two planned robot pads at source thumb and each supported partner region; every planned pad required, original index-only and three-pad failures retained'  ,
              'objective_weights':{'each_targeted_pad_mm2':1.,'inferred_robot_root_prior_mm2':.005,'rotation_rad2':1.,'finger_delta_rad2':.01},
              'interpolation_controls':interpolation_controls(),'source_observations_modified':False,
              'human_poses_modified':False,'object_camera_or_scale_modified':False,'grasp_annotations_used':False,
              'gt_used':False,'display_holds_used':False,'contact_known':False,'physical_task_accepted':False}
    (a.out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    reports=[]
    for si,side in enumerate(('left','right')):
        kin=setup_dex3_kinematics(side=side,max_iter=1)
        self_checker=SelfDistances(kin,assets/f'urdfs/g1/dex3_{side}.urdf')
        geometry=[];full_geometry=[];pad_geometry={};full_triangle_geometry=[];pad_surfaces={}
        xml=ET.parse(assets/f'urdfs/g1/dex3_{side}.urdf').getroot()
        for link in xml.findall('link'):
            for collision in link.findall('collision'):
                spec=collision.find('geometry/mesh')
                mesh=trimesh.load(assets/'meshes'/spec.attrib['filename'].removeprefix('package://'),force='mesh',process=False)
                raw_points=np.asarray(mesh.vertices,dtype=float)*np.fromstring(spec.attrib.get('scale','1 1 1'),sep=' ')
                points=np.unique(raw_points,axis=0)
                origin=collision.find('origin')
                if origin is not None:
                    points=points@Rotation.from_euler('xyz',np.fromstring(origin.attrib.get('rpy','0 0 0'),sep=' ')).as_matrix().T+np.fromstring(origin.attrib.get('xyz','0 0 0'),sep=' ')
                    raw_points=raw_points@Rotation.from_euler('xyz',np.fromstring(origin.attrib.get('rpy','0 0 0'),sep=' ')).as_matrix().T+np.fromstring(origin.attrib.get('xyz','0 0 0'),sep=' ')
                full_triangle_geometry.append((link.attrib['name'],raw_points[np.asarray(mesh.faces)]))
                selection=np.linspace(0,len(points)-1,min(768,len(points)),dtype=np.int64)
                full_geometry.append((link.attrib['name'],points))
                geometry.append((link.attrib['name'],points[selection]))
                for finger,suffix in (('thumb','2'),('index','1'),('middle','1')):
                    if link.attrib['name']==f'{side}_hand_{finger}_{suffix}_link':
                        pad_geometry[finger]=len(geometry)-1
                        pad_surfaces[finger]=(link.attrib['name'],Surface(raw_points,mesh.faces))
        base_geometry=[(name,points.copy()) for name,points in geometry]
        for oi,obj in enumerate(bm['objects']):
            selected=(r['candidate_rows_hand_object'][:,1]==si)&(r['candidate_rows_hand_object'][:,2]==oi)
            contacts=r['candidate_stereo_points_object_local_m'][selected]
            rows=np.unique(r['candidate_rows_hand_object'][selected,0])
            if len(contacts)<64 or len(rows)<10:
                reports.append({'side':side,'object':oi,'status':'insufficient source region support','source_region_points':len(contacts),'source_region_frames':len(rows)})
                continue
            scales=d[f'object_{oi}_scale'][rows]
            assert np.ptp(scales)<1e-6
            scale=float(np.median(scales))
            poses=d[f'object_{oi}_world'][rows]
            local_roots=np.einsum('bji,bj->bi',poses[:,:3,:3],d['hand_joints_world'][rows,si,0]-poses[:,:3,3])
            source_root=np.median(local_roots,axis=0)
            source_rot=poses[:,:3,:3].transpose(0,2,1)@Rotation.from_quat(q['robot_qpos'][rows,si,3:7]).as_matrix()
            source_rotation=Rotation.from_matrix(source_rot).mean().as_matrix()
            source_fingers=np.median(q['robot_qpos'][rows,si,7:],axis=0)
            path=a.material/f'object_{oi}.npz'
            assert sha(path)==next(o['payload_sha256'] for o in mm['objects'] if o['object']==oi)
            with np.load(path,allow_pickle=False) as archive:g={k:archive[k] for k in archive.files}
            pitch=float(g['pitch_m']);solid=g['solid_cells'];exact_boundary=Boundary(solid,g['origin_m'],pitch)
            field=(distance_transform_edt(~solid)-distance_transform_edt(solid))*pitch
            field=np.where(solid,field+pitch/2,field-pitch/2)
            boundary,normals=boundary_faces(solid,g['origin_m'],pitch)
            center=np.median(contacts,axis=0)*scale
            labelled={v['digit_inferred']:v for v in digits['summaries'] if v['side']==side and v['object']==oi and v['points']>=32 and v['source_frames']>=10 and v['digit_inferred']!='unknown'}
            if not all(finger in labelled for finger in ('thumb','index')):
                reports.append({'side':side,'object':oi,'status':'insufficient inferred thumb/index region labels'})
                continue
            desired={'thumb':np.array(labelled['thumb']['center_object_local_m'])*scale,
                     'index':np.array(labelled['index']['center_object_local_m'])*scale}
            if 'pinky' in labelled:
                desired['middle']=np.array(labelled['pinky']['center_object_local_m'])*scale
                long_axis=desired['middle']-desired['index'];long_axis/=np.linalg.norm(long_axis)
            else:
                covariance=np.cov(contacts.T)
                eigenvalue,eigenvector=np.linalg.eigh(covariance)
                long_axis=eigenvector[:,2]
            # Choose its sign nearest to the source palm Z for a deterministic
            # morphology adaptation, not a new human wrist observation.
            if long_axis@source_rotation[:,2]<0:long_axis=-long_axis
            other=np.mean([v for k,v in desired.items() if k!='thumb'],axis=0)
            opposition=desired['thumb']-other
            opposition-=long_axis*(opposition@long_axis)
            normal_axis=int(np.argmax(np.abs(opposition)))
            source_assignment=int(np.sign(opposition[normal_axis]))
            assert source_assignment in (-1,1)
            direction=np.zeros(3);direction[normal_axis]=1
            nearby=np.linalg.norm(boundary*scale-center,axis=-1)<.065
            face_sets={sign:boundary[nearby&(normals[:,normal_axis]==sign)]*scale for sign in (-1,1)}
            assert all(len(v)>0 for v in face_sets.values())
            output=a.out/f'{side}-object{oi}';output.mkdir()
            traces=[]
            def q_from_x(x):
                return np.r_[source_root+x[:3]*.001,Rotation.from_matrix(Rotation.from_rotvec(x[3:6]).as_matrix()@source_rotation).as_quat(),x[6:]]
            def parameter_map(x):
                rotation=Rotation.from_quat(q_from_x(x)[3:7]).as_matrix()
                M=np.eye(kin.robot.model.nv)
                M[:3,:3]=rotation.T*.001
                M[3:6,3:6]=rotation.T@left_jacobian(x[3:6])
                return M
            cache={};active_contact_faces={}
            def evaluate(x):
                if 'x' in cache and np.array_equal(cache['x'],x):return cache['data']
                kin.configuration.update(q_from_x(x))
                M=parameter_map(x)
                all_world=[];all_J=[];ranges=[]
                for name,points in geometry:
                    transform=kin.configuration.get_transform_frame_to_world(name)
                    body=kin.configuration.get_frame_jacobian(name)
                    world=points@transform.rotation.T+transform.translation
                    skew=np.array([pin.skew(p) for p in points])
                    J=np.einsum('ij,pjk->pik',transform.rotation,body[:3][None]-skew@body[3:])@M
                    ranges.append((sum(len(p) for p in all_world),sum(len(p) for p in all_world)+len(points)))
                    all_world.append(world);all_J.append(J)
                world=np.concatenate(all_world);J=np.concatenate(all_J)
                coordinates=(world/scale-g['origin_m'])/pitch
                phi,gradient=trilinear(field,coordinates)
                phi*=scale;gradient/=pitch
                constraints_J=np.einsum('pi,pij->pj',gradient,J)
                result=(world,J,phi,constraints_J,ranges)
                self_distance,self_J,self_records=self_checker.evaluate(q_from_x(x))
                cache['self']=(np.minimum(self_distance,.005),self_J*(self_distance<.005)[:,None]@M,self_distance,self_records)
                cache['x']=x.copy();cache['data']=result
                return result
            def exact_pad(x,finger,target_point):
                # evaluate() synchronizes native FK before this call.
                evaluate(x)
                name,surface=pad_surfaces[finger]
                transform=kin.configuration.get_transform_frame_to_world(name)
                local_target=transform.rotation.T@(target_point-transform.translation)
                if finger in active_contact_faces:
                    triangle=active_contact_faces[finger]
                    local=closest_triangle_points(surface.triangles[triangle:triangle+1],local_target[None])[0]
                    normal=surface.normals[triangle];gap=float(np.linalg.norm(local-local_target));candidates=1
                else:
                    local,normal,triangle,gap,candidates=surface.nearest(local_target)
                world=transform.rotation@local+transform.translation
                body=kin.configuration.get_frame_jacobian(name)
                J=transform.rotation@(body[:3]-pin.skew(local)@body[3:])@parameter_map(x)
                normal_world=transform.rotation@normal
                normal_J=-pin.skew(normal_world)@(transform.rotation@body[3:])@parameter_map(x)
                return world,J,gap,normal_world,triangle,candidates,normal_J
            initial=np.r_[np.zeros(6),source_fingers]
            # Independent real-point kinematic parameter derivative control.
            worst=0.
            for rotation_probe in (np.zeros(3),np.array([.31,-.27,.19])):
                probe=initial.copy();probe[3:6]=rotation_probe
                world,J,_,_,_=evaluate(probe)
                representative=np.linspace(0,len(world)-1,16,dtype=int)
                for coordinate in range(len(initial)):
                    step=np.zeros_like(initial);step[coordinate]=1e-7
                    plus=evaluate(probe+step)[0][representative]
                    minus=evaluate(probe-step)[0][representative]
                    worst=max(worst,float(np.max(np.abs((plus-minus)/2e-7-J[representative,:,coordinate]))))
            assert worst<1e-7,worst
            root_X=source_rotation[:,0]-long_axis*(source_rotation[:,0]@long_axis)
            root_X/=np.linalg.norm(root_X)
            adapted_rotation=np.column_stack((root_X,np.cross(long_axis,root_X),long_axis))
            seeds=[np.zeros(3),Rotation.from_matrix(adapted_rotation@source_rotation.T).as_rotvec()]
            for yaw in (-np.pi/4,np.pi/4):
                rotated=Rotation.from_rotvec(long_axis*yaw).as_matrix()@adapted_rotation
                seeds.append(Rotation.from_matrix(rotated@source_rotation.T).as_rotvec())
            for partner_source_digit in ('index','middle','ring','pinky'):
                if partner_source_digit not in labelled:continue
                for assignment in (source_assignment,-source_assignment):
                    target=[]
                    targeted_fingers=('thumb','index')
                    for finger in targeted_fingers:
                        sign=assignment if finger=='thumb' else -assignment
                        candidates=face_sets[sign]
                        desired_point=desired['thumb'] if finger=='thumb' else np.array(labelled[partner_source_digit]['center_object_local_m'])*scale
                        best=np.argmin(np.linalg.norm(candidates-desired_point,axis=-1))
                        target.append(candidates[best]+sign*direction*.0005)
                    target=np.array(target)
                    target_normals=np.array([assignment*direction if finger=='thumb' else -assignment*direction for finger in targeted_fingers])
                    def normal_constraints(x):
                        values=[];derivatives=[]
                        for fi,finger in enumerate(targeted_fingers):
                            actual,point_J,gap,normal,triangle,count,normal_J=exact_pad(x,finger,target[fi])
                            values.append(-.5-normal@target_normals[fi])
                            derivatives.append(-target_normals[fi]@normal_J)
                        return np.array(values),np.array(derivatives)
                    previous=[v for v in warm['templates'] if v['side']==side and v['object']==oi and 'pads' in v and v['seed'].startswith(f'assignment{assignment}-') and v['root_delta_m']<=.080+1e-6 and v['rotation_delta_rad']<=np.pi+1e-6 and v['whole_mesh_vertex_lower_max_m']<=.002]
                    previous=sorted(previous,key=lambda v:v['objective'])[:2]
                    initial_seeds=[]
                    for v in previous:
                        q0=np.array(v['qpos_object_frame'])
                        rotation_seed=Rotation.from_matrix(Rotation.from_quat(q0[3:7]).as_matrix()@source_rotation.T).as_rotvec()
                        initial_seeds.append(np.r_[(q0[:3]-source_root)*1000,rotation_seed,q0[7:]])
                    for rotation_seed in seeds:
                        x0=initial.copy();x0[3:6]=rotation_seed*min(1.,(np.pi-.001)/max(np.linalg.norm(rotation_seed),1e-9))
                        initial_seeds.append(x0)
                    for rotation_seed in seeds:
                        x0=initial.copy();x0[3:6]=rotation_seed*min(1.,(np.pi-.001)/max(np.linalg.norm(rotation_seed),1e-9));x0[6:]=kin.robot.q0[7:]
                        initial_seeds.append(x0)
                    for seed_index,x0 in enumerate(initial_seeds):
                        geometry=[(name,points.copy()) for name,points in base_geometry]
                        cache.clear();active_contact_faces.clear();trace=[];surface_rounds=[];added_witnesses=[]
                        evaluate(x0);initial_qpos=q_from_x(x0).copy();initial_features={}
                        for fi,finger in enumerate(targeted_fingers):
                            link_name,surface=pad_surfaces[finger]
                            transform=kin.configuration.get_transform_frame_to_world(link_name)
                            local_target=transform.rotation.T@(target[fi]-transform.translation)
                            local_material_normal=transform.rotation.T@target_normals[fi]
                            allowed=np.flatnonzero(surface.normals@local_material_normal<=-.5)
                            assert len(allowed)>0,(side,finger,'no initially facing original triangle')
                            points=closest_triangle_points(surface.triangles[allowed],np.tile(local_target,(len(allowed),1)))
                            squared=np.einsum('ij,ij->i',points-local_target,points-local_target)
                            selected=int(np.argmin(squared));triangle=int(allowed[selected])
                            active_contact_faces[finger]=triangle
                            initial_features[finger]={'original_triangle_index':triangle,'eligible_original_triangles':len(allowed),
                                                      'target_distance_m':float(np.sqrt(squared[selected])),
                                                      'normal_dot':float(surface.normals[triangle]@local_material_normal)}
                        selected_faces=dict(active_contact_faces)
                        normal_control_error=0.;selected_face_cost_control_error=0.
                        for rotation_offset in (np.zeros(3),np.array([.31,-.27,.19])):
                            probe=x0.copy();probe[3:6]+=rotation_offset
                            value,jacobian=normal_constraints(probe)
                            original=[]
                            for fi,finger in enumerate(targeted_fingers):
                                actual,point_J,gap,normal,triangle,count,normal_J=exact_pad(probe,finger,target[fi])
                                original.append(((actual-target[fi])@point_J,gap*gap/2))
                            for coordinate in range(len(probe)):
                                step=np.zeros_like(probe);step[coordinate]=1e-7
                                plus=normal_constraints(probe+step)[0];minus=normal_constraints(probe-step)[0]
                                normal_control_error=max(normal_control_error,float(np.max(np.abs((plus-minus)/2e-7-jacobian[:,coordinate]))))
                                for fi,finger in enumerate(targeted_fingers):
                                    gaps=[exact_pad(probe+sign*step,finger,target[fi])[2] for sign in (1,-1)]
                                    derivative=(gaps[0]**2-gaps[1]**2)/4e-7
                                    selected_face_cost_control_error=max(selected_face_cost_control_error,abs(derivative-original[fi][0][coordinate]))
                        assert normal_control_error<1e-5,normal_control_error
                        assert selected_face_cost_control_error<1e-7,selected_face_cost_control_error
                        def objective(x):
                            world,J,phi,pJ,ranges=evaluate(x)
                            cost=0.;derivative=np.zeros_like(x)
                            for fi,finger in enumerate(targeted_fingers):
                                actual,point_J,gap,normal,triangle,count,normal_J=exact_pad(x,finger,target[fi])
                                offset=actual-target[fi]
                                cost+=float(offset@offset)*1e6
                                derivative+=2e6*offset@point_J
                            cost+=.005*float(x[:3]@x[:3])+float(x[3:6]@x[3:6])+.01*float((x[6:]-source_fingers)@(x[6:]-source_fingers))
                            derivative[:3]+=.01*x[:3];derivative[3:6]+=2*x[3:6];derivative[6:]+=.02*(x[6:]-source_fingers)
                            return cost,derivative
                        def constraints(x):
                            _,_,phi,pJ,_=evaluate(x)
                            return np.r_[(phi-.0005)*1000,(cache['self'][0]-.0005)*1000,1.-(x[:3]@x[:3])/80.**2,1.-(x[3:6]@x[3:6])/np.pi**2,normal_constraints(x)[0]]
                        def constraints_jac(x):
                            _,_,phi,pJ,_=evaluate(x)
                            root=np.zeros_like(x);root[:3]=-2*x[:3]/80.**2
                            rot=np.zeros_like(x);rot[3:6]=-2*x[3:6]/np.pi**2
                            return np.vstack((pJ*1000,cache['self'][1]*1000,root,rot,normal_constraints(x)[1]))
                        def callback(x):
                            world,J,phi,pJ,ranges=evaluate(x)
                            trace.append({'iteration':len(trace),'objective':float(objective(x)[0]),'min_sampled_sdf_m':float(phi.min()),'root_delta_m':float(np.linalg.norm(x[:3])*.001),'rotation_delta_rad':float(np.linalg.norm(x[3:6]))})
                        bounds=[(-80.,80.)]*3+[(-np.pi,np.pi)]*3+list(zip(kin.robot.model.lowerPositionLimit[7:],kin.robot.model.upperPositionLimit[7:]))
                        def residual(x):
                            world,J,phi,pJ,ranges=evaluate(x)
                            pieces=[];derivatives=[]
                            for fi,finger in enumerate(targeted_fingers):
                                actual,point_J,gap,normal,triangle,count,normal_J=exact_pad(x,finger,target[fi])
                                offset=actual-target[fi]
                                # d(distance)/dx = offset @ point_J / distance.
                                # Sliding closest barycentrics cancel in this scalar
                                # derivative; they do not cancel in a 3-vector J.
                                pieces.append(np.array([gap*1000]))
                                derivatives.append(((offset@point_J/gap) if gap>1e-14 else np.zeros_like(x))[None]*1000)
                            pieces.append(np.maximum(.0005-phi,0)*1000*np.sqrt(1000.))
                            derivatives.append(-pJ*(phi<.0005)[:,None]*1000*np.sqrt(1000.))
                            self_distance,self_J,_,_=cache['self']
                            pieces.append(np.maximum(.0005-self_distance,0)*1000*np.sqrt(1000.))
                            derivatives.append(-self_J*(self_distance<.0005)[:,None]*1000*np.sqrt(1000.))
                            normal_value,normal_jac=normal_constraints(x)
                            pieces.append(np.maximum(-normal_value,0)*np.sqrt(1000.))
                            derivatives.append(-normal_jac*(normal_value<0)[:,None]*np.sqrt(1000.))
                            regularizer=np.r_[x[:3]*np.sqrt(.005),x[3:6],(x[6:]-source_fingers)*.1]
                            pieces.append(regularizer);derivatives.append(np.diag(np.r_[np.full(3,np.sqrt(.005)),np.ones(3),np.full(7,.1)]))
                            norms=np.array([np.linalg.norm(x[:3])/80,np.linalg.norm(x[3:6])/np.pi])
                            guard=np.zeros((2,len(x)))
                            if norms[0]>1:guard[0,:3]=x[:3]/np.linalg.norm(x[:3])/80*1000
                            if norms[1]>1:guard[1,3:6]=x[3:6]/np.linalg.norm(x[3:6])/np.pi*1000
                            pieces.append(np.maximum(norms-1,0)*1000);derivatives.append(guard)
                            return np.concatenate(pieces),np.vstack(derivatives)
                        lower,upper=np.array(bounds).T
                        feasible=minimize(lambda x:.5*float(residual(x)[0]@residual(x)[0]),x0,jac=lambda x:residual(x)[0]@residual(x)[1],method='L-BFGS-B',bounds=bounds,options={'maxiter':100,'ftol':1e-12,'gtol':1e-6})
                        initialized=least_squares(lambda x:residual(x)[0],np.clip(feasible.x,lower+1e-10,upper-1e-10),jac=lambda x:residual(x)[1],bounds=(lower,upper),max_nfev=200,x_scale='jac',ftol=1e-10,xtol=1e-10,gtol=1e-8)
                        restart=initialized.x
                        for cutting_round in range(6):
                            result=minimize(lambda x:objective(x)[0],restart,jac=lambda x:objective(x)[1],method='SLSQP',bounds=bounds,
                                            constraints={'type':'ineq','fun':constraints,'jac':constraints_jac},callback=callback,
                                            options={'maxiter':200,'ftol':1e-8,'disp':False})
                            evaluate(result.x)
                            world_triangles=[]
                            for link_name,local_triangles in full_triangle_geometry:
                                transform=kin.configuration.get_transform_frame_to_world(link_name)
                                world_triangles.append(local_triangles@transform.rotation.T+transform.translation)
                            certificate=certify(exact_boundary,np.concatenate(world_triangles)/scale,scale)
                            surface_rounds.append({'round':cutting_round,'solver_success':bool(result.success),'certificate':certificate})
                            if certificate['triangle_material_limit_certified'] or cutting_round==5 or certificate['status'].startswith('unresolved'):break
                            witness=certificate['witness'];index=witness['original_triangle_index'];offset=0
                            for geometry_index,(link_name,local_triangles) in enumerate(full_triangle_geometry):
                                if offset<=index<offset+len(local_triangles):break
                                offset+=len(local_triangles)
                            else:raise AssertionError('original witness triangle mapping')
                            transform=kin.configuration.get_transform_frame_to_world(link_name)
                            local_point=transform.rotation.T@(np.array(witness['point_object_local_m'])*scale-transform.translation)
                            name,points=geometry[geometry_index]
                            assert name==link_name
                            geometry[geometry_index]=(name,np.vstack((points,local_point)))
                            added_witnesses.append({'link':name,'original_link_triangle_index':int(index-offset),'point_link_local_m':local_point.tolist(),'failed_certificate_witness':witness})
                            cache.clear();restart=result.x
                        x=result.x
                        world,J,phi,pJ,ranges=evaluate(x)
                        kin.configuration.update(q_from_x(x))
                        full_lower=0.;full_upper=0.;queries=0
                        for name,points in full_geometry:
                            transform=kin.configuration.get_transform_frame_to_world(name)
                            actual=(points@transform.rotation.T+transform.translation)/scale
                            lo,hi,inside=solid_depth_bounds(actual,solid,g['empty_center_distance_m'],g['origin_m'],pitch)
                            full_lower=max(full_lower,float(lo.max())*scale);full_upper=max(full_upper,float(hi.max())*scale);queries+=len(points)
                        pad=[]
                        for fi,finger in enumerate(targeted_fingers):
                            actual,point_J,gap,normal,triangle,count,normal_J=exact_pad(x,finger,target[fi])
                            material_gap,_=trilinear(field,(actual[None]/scale-g['origin_m'])/pitch)
                            pad.append({'finger':finger,'target_object_scaled_m':target[fi].tolist(),'point_object_scaled_m':actual.tolist(),
                                        'target_distance_m':gap,'interpolated_material_gap_m':float(material_gap[0])*scale,
                                        'original_mesh_triangle_index':triangle,'contact_feature_selection':'fixed initially-facing original triangle per seed','contact_feature_is_inferred':True,'robot_triangle_normal_object_scaled_frame':normal.tolist(),'declared_target_material_normal':target_normals[fi].tolist(),'robot_target_normal_dot':float(normal@target_normals[fi]),
                                        'complete_candidate_bound_triangle_count':count,'target_point_on_full_original_triangle':True})
                        name=f'partner{partner_source_digit}-assignment{assignment}-seed{seed_index}'
                        record={'side':side,'object':oi,'seed':name,'success':bool(result.success),'message':str(result.message),'iterations':int(result.nit),
                                'objective':float(result.fun),'minimum_sampled_sdf_m':float(phi.min()),'minimum_nonadjacent_convex_clearance_m':float(cache['self'][2].min()),'nonadjacent_convex_pairs':len(cache['self'][2]),'whole_mesh_vertex_lower_max_m':full_lower,
                                'whole_mesh_vertex_upper_max_m':full_upper,'vertex_queries':queries,'root_delta_m':float(np.linalg.norm(x[:3])*.001),
                                'static_target_triangle_material_certificate':certificate,'surface_refit_rounds':surface_rounds,'added_surface_witness_constraints':added_witnesses,'initialization_function_evaluations':int(initialized.nfev),'initialization_success':bool(initialized.success),
                                'rotation_delta_rad':float(np.linalg.norm(x[3:6])),'qpos_object_frame':q_from_x(x).tolist(),'pads':pad,
                                'source_region_points':len(contacts),'source_region_frames':len(rows),'source_center_object_scaled_m':center.tolist(),
                                'template_reference_scale':scale,'source_scale_min':float(scales.min()),'source_scale_max':float(scales.max()),
                                'reference_scale_is_template_only':True,
                                'source_root_object_scaled_m':source_root.tolist(),'source_region_principal_axis':long_axis.tolist(),
                                'source_region_normal_axis':normal_axis,'point_parameter_derivative_control_max_error':worst,
                                'initial_qpos_object_frame':initial_qpos.tolist(),'initial_selected_contact_features':initial_features,'selected_original_contact_triangles':selected_faces,'selected_face_squared_distance_parameter_derivative_max_error':selected_face_cost_control_error,'normal_constraint_parameter_derivative_max_error':normal_control_error,'minimum_declared_normal_constraint':float(normal_constraints(x)[0].min()),'robot_index_contact_source_region_inferred':partner_source_digit,'target_source_region_for_robot_finger':{'thumb':'thumb','index':partner_source_digit},'targeted_fingers':list(targeted_fingers),'self_hull_containment_controls':self_checker.hull_controls,'source_digit_contact_desired_object_scaled_m':{k:v.tolist() for k,v in desired.items()},
                                'contact_known':False,'source_hand_pose_accuracy_accepted':False,'physical_task_accepted':False}
                        (output/f'{name}.json').write_text(json.dumps(record,indent=2)+'\n')
                        (output/f'{name}-trace.json').write_text(json.dumps(trace,indent=2)+'\n')
                        reports.append(record)
                        print(json.dumps({k:record[k] for k in ['side','object','seed','success','iterations','minimum_sampled_sdf_m','minimum_nonadjacent_convex_clearance_m','whole_mesh_vertex_lower_max_m','root_delta_m','rotation_delta_rad']}),flush=True)
    report={**protocol,'templates':reports,'elapsed_seconds':time.monotonic()-started,'status':'inferred static development templates only; no trajectory, simulator or task acceptance'}
    (a.out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'elapsed_seconds':report['elapsed_seconds'],'templates':len(reports),'physical_task_accepted':False}),flush=True)

if __name__=='__main__':main()
