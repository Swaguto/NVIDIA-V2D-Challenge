"""Conservative link convex-hull signed distances and point-Jacobian derivatives.

Original BVH triangle surfaces are audited separately. A hull may reject a safe
concave-space pose; hull separation conservatively separates its original mesh.
"""
import xml.etree.ElementTree as ET
from pathlib import Path

import coal
import trimesh
import hashlib
import numpy as np
import pinocchio as pin
from scipy.spatial import ConvexHull

class SelfDistances:
    def __init__(self,kin,urdf):
        self.kin=kin;self.model=kin.robot.collision_model;self.data=self.model.createData()
        adjacent={frozenset([j.find('parent').attrib['link'],j.find('child').attrib['link']]) for j in ET.parse(urdf).getroot().findall('joint')}
        self.convex=[]
        self.hull_controls=[]
        for geometry in self.model.geometryObjects:
            mesh_path=Path(geometry.meshPath)
            mesh=trimesh.load(mesh_path,force='mesh',process=False)
            scale=np.asarray(geometry.meshScale)
            assert np.isfinite(scale).all() and np.all(scale>0)
            original=np.unique(np.asarray(mesh.vertices,dtype=float),axis=0)*scale
            vertices=coal.StdVec_Vec3s()
            vertices.extend(original)
            convex=coal.Convex.convexHull(vertices,True,'Qt')
            hull=ConvexHull(convex.points())
            worst=max(float(np.max(original[start:start+256]@hull.equations[:,:3].T+hull.equations[:,3])) for start in range(0,len(original),256))
            assert worst<1e-10,worst
            self.hull_controls.append({'geometry':geometry.name,'original_vertices':len(original),'loaded_collision_vertices':int(geometry.geometry.num_vertices),'original_mesh_sha256':hashlib.sha256(mesh_path.read_bytes()).hexdigest(),'hull_vertices':int(convex.num_points),'maximum_original_vertex_halfspace_violation_m':worst})
            self.convex.append(convex)
        self.names=[kin.robot.model.frames[g.parentFrame].name for g in self.model.geometryObjects]
        self.pairs=[(i,j) for i in range(len(self.names)) for j in range(i+1,len(self.names)) if self.names[i]!=self.names[j] and frozenset([self.names[i],self.names[j]]) not in adjacent]

    def evaluate(self,q,jacobian=True):
        self.kin.configuration.update(q)
        pin.updateGeometryPlacements(self.kin.robot.model,self.kin.configuration.data,self.model,self.data,q)
        distances=[];derivatives=[];records=[]
        for i,j in self.pairs:
            request=coal.DistanceRequest();request.enable_nearest_points=True;request.enable_signed_distance=True
            request.gjk_tolerance=1e-10
            result=coal.DistanceResult();first=self.data.oMg[i];second=self.data.oMg[j]
            coal.distance(self.convex[i],coal.Transform3s(first.rotation,first.translation),
                          self.convex[j],coal.Transform3s(second.rotation,second.translation),request,result)
            distance=float(result.min_distance)
            normal=np.asarray(result.normal,dtype=float)
            p1=np.asarray(result.getNearestPoint1(),dtype=float);p2=np.asarray(result.getNearestPoint2(),dtype=float)
            assert np.isfinite(distance) and np.isfinite(p1).all() and np.isfinite(p2).all()
            assert np.isfinite(normal).all() and np.linalg.norm(normal)>.5,(self.names[i],self.names[j],distance,normal)
            if abs(distance)>1e-8:
                np.testing.assert_allclose(p2-p1,normal*distance,atol=1e-7,rtol=1e-5)
            normal/=np.linalg.norm(normal)
            distances.append(distance)
            if jacobian:
                point_j=[]
                for index,point in ((i,p1),(j,p2)):
                    frame=self.kin.configuration.get_transform_frame_to_world(self.names[index])
                    local=frame.rotation.T@(point-frame.translation)
                    body=self.kin.configuration.get_frame_jacobian(self.names[index])
                    point_j.append(frame.rotation@(body[:3]-pin.skew(local)@body[3:]))
                derivatives.append(normal@(point_j[1]-point_j[0]))
            records.append({'links':[self.names[i],self.names[j]],'distance_m':distance,'normal_world':normal.tolist(),
                            'first_point_world':p1.tolist(),'second_point_world':p2.tolist()})
        return np.array(distances),np.array(derivatives),records

def derivative_controls(kin,urdf,configurations):
    checker=SelfDistances(kin,urdf);reports=[]
    # Constraints min(distance,5mm)>=0.5mm have exactly the same feasible set
    # as distance>=0.5mm. Saturation avoids irrelevant far-feature derivatives.
    saturation=.005
    for q in configurations:
        q=np.asarray(q);distance,J,records=checker.evaluate(q)
        constraint_J=J*(distance<saturation)[:,None]
        by_pair=np.zeros(len(distance));raw_by_pair=np.zeros(len(distance))
        for coordinate in range(kin.robot.model.nv):
            step=np.zeros(kin.robot.model.nv);step[coordinate]=1e-6
            plus=checker.evaluate(pin.integrate(kin.robot.model,q,step),False)[0]
            minus=checker.evaluate(pin.integrate(kin.robot.model,q,-step),False)[0]
            raw_error=np.abs((plus-minus)/2e-6-J[:,coordinate])
            error=np.abs((np.minimum(plus,saturation)-np.minimum(minus,saturation))/2e-6-constraint_J[:,coordinate])
            by_pair=np.maximum(by_pair,error);raw_by_pair=np.maximum(raw_by_pair,raw_error)
        reports.append({'maximum_constraint_derivative_error':float(by_pair.max()),
                        'maximum_raw_distance_derivative_error':float(raw_by_pair.max()),
                        'saturation_m':saturation,'margin_m':.0005,'pairs':len(distance),'coordinates':kin.robot.model.nv,
                        'active_pairs':int(np.count_nonzero(distance<saturation)),
                        'minimum_signed_convex_distance_m':float(distance.min()),
                        'worst_pair':records[int(by_pair.argmax())]['links'],'per_pair_constraint_error':by_pair.tolist()})
    return {'hull_vertex_containment_controls':checker.hull_controls,'configurations':reports}

def primitive_controls():
    box=coal.Box(.02,.02,.02);identity=coal.Transform3s(np.eye(3),np.zeros(3))
    values=[]
    for offset,expected in ((.015,-.005),(.025,.005)):
        request=coal.DistanceRequest();request.enable_signed_distance=True
        result=coal.DistanceResult()
        coal.distance(box,identity,box,coal.Transform3s(np.eye(3),np.array([offset,0,0])),request,result)
        np.testing.assert_allclose(result.min_distance,expected,atol=1e-9)
        np.testing.assert_allclose(np.asarray(result.getNearestPoint2())-np.asarray(result.getNearestPoint1()),np.asarray(result.normal)*expected,atol=1e-9)
        values.append({'box_center_offset_m':offset,'expected_signed_distance_m':expected,'measured_signed_distance_m':float(result.min_distance)})
    return values
