"""Reparameterize release only; follow the prior with a fitted root transform.

Closing, observed inputs and inferred holds retain their original timing.
Opening traverses the existing joint corridor with a 10 percent URDF speed
reserve. The root offset is derived from the last fitted grasp anchor.
Every robot pose remains an unvalidated inference.
"""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from generated_trailing_grasp_motion_v2 import ContinuationMotion
from generated_per_grasp_motion_v4 import PerGraspMotion
from propose_robot_contact_motion_v1 import blend, smooth
from corrected_per_grasp_motion_v1 import load, sha


class SourceFollowingMotion(ContinuationMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas,
                 proposal=None, *, base_continuation=None):
        self.release_enabled = False
        saved = None
        if proposal is not None:
            saved = json.loads((proposal / "report.json").read_text())
            base_continuation = proposal.parent / saved["base_continuation_proposal"]
            assert sha(base_continuation / "report.json") == saved["base_continuation_report_sha256"]
            assert saved["motion_module_sha256"] == sha(Path(__file__))
            assert saved["payload_sha256"] == sha(proposal / "robot-motion-proposal.npz")
            assert saved["physical_task_accepted"] is False
        assert base_continuation is not None
        super().__init__(bundle, baseline, parent_proposal, interval_inputs, atlas, base_continuation)
        self.base_continuation = base_continuation
        self.release_parent_data = load(base_continuation / "robot-motion-proposal.npz")
        self.release_parent_report = self.repair_report
        self.velocity_margin = .9
        self.morphology_offsets = {}
        self.corridor_clock_changes = []
        for si, side in enumerate(self.sides):
            limits = np.asarray(self.rm["joints"][side["side"]]["velocity_limits_rad_s"])
            for phase in side["phases"]:
                delta = np.diff(phase["qpath"], axis=0)
                required = np.maximum(np.linalg.norm(delta[:, :3], axis=1),
                                      np.max(abs(delta[:, 7:]) / limits, axis=1))
                phase["release_duration_s"] = float(required.sum() / self.velocity_margin)
                phase["release_clock"] = np.r_[0., np.cumsum(required)] / self.velocity_margin
                # Preserve the original phase clock for every approach and hold.
                self.corridor_clock_changes.append({
                    "prefix": phase["prefix"], "closing_duration_s": phase["duration_s"],
                    "opening_duration_s": phase["release_duration_s"]})
                last = phase["interval"][1]
                anchor = super().evaluate(last)[0][si]
                prior = self.prior(si, last)
                rotation = Rotation.from_quat(prior[3:7])
                self.morphology_offsets[phase["prefix"]] = {
                    "source_prior_local_translation_m": rotation.inv().apply(anchor[:3] - prior[:3]),
                    "source_prior_relative_rotation_xyzw":
                        (rotation.inv() * Rotation.from_quat(anchor[3:7])).as_quat()}
                self.breakpoints = np.r_[self.breakpoints, last + phase["release_clock"],
                                         last + phase["release_duration_s"] + self.free_blend]
        self.breakpoints = np.unique(self.breakpoints)
        self.breakpoints = self.breakpoints[(self.breakpoints >= self.times[0]) &
                                             (self.breakpoints <= self.times[-1])]
        self.release_enabled = True
        q = np.array([self.evaluate(float(t))[0] for t in self.times])
        anchors = self.release_parent_data["robot_contact_intent_inferred"].any(axis=2)
        np.testing.assert_allclose(q[anchors], self.release_parent_data["robot_qpos_inferred"][anchors],
                                   rtol=0, atol=1e-12)
        self.source_sample_maximum_error = 0.
        if saved is not None:
            stored = load(proposal / "robot-motion-proposal.npz")
            for key in ("frame_indices", "timestamps_s", "source_hand_valid",
                        "source_hand_directly_observed", "source_object_observed",
                        "source_inferred_hold_state", "robot_contact_intent_inferred",
                        "robot_contact_intent_bridge", "robot_contact_intent_trailing_extension"):
                np.testing.assert_array_equal(stored[key], self.release_parent_data[key])
            assert stored["robot_pose_is_inferred"].all()
            assert not stored["robot_motion_target_validated"].any()
            np.testing.assert_array_equal(stored["robot_qpos_inferred"][anchors],
                                          self.release_parent_data["robot_qpos_inferred"][anchors])
            np.testing.assert_allclose(q, stored["robot_qpos_inferred"], rtol=0, atol=1e-12)
            self.source_sample_maximum_error = float(abs(q - stored["robot_qpos_inferred"]).max())
            self.repair_report = saved

    def release_weights(self, timestamp):
        weights = np.zeros(2)
        for si, side in enumerate(self.sides):
            for phase in side["phases"]:
                last = phase["interval"][1]
                duration = phase["release_duration_s"]
                if last < timestamp <= last + duration + self.free_blend:
                    weights[si] = float(smooth((timestamp - last) / duration))
        return weights

    def evaluate(self, timestamp):
        q, kinds, details = super().evaluate(timestamp)
        if not self.release_enabled:
            return q, kinds, details
        base = None
        for si, side in enumerate(self.sides):
            for phase in side["phases"]:
                last = phase["interval"][1]
                duration = phase["release_duration_s"]
                # Also replace the obsolete, longer opening tail with the
                # completed new release. Never revert to old fingers there.
                end = last + max(duration, phase["duration_s"]) + self.free_blend
                if not last < timestamp <= end:
                    continue
                if base is None:
                    base = PerGraspMotion.evaluate(self, timestamp)[0]
                correction = q[si, :3] - base[si, :3]
                prior = self.prior(si, timestamp)
                opening_time = min(timestamp - last, duration)
                weight = 1. if timestamp <= last + duration else float(
                    smooth(1. - (timestamp - last - duration) / self.free_blend))
                release_phase = {**phase, "clock": phase["release_clock"], "duration_s": duration}
                local = self.local_path(release_phase, opening_time)
                matrix, translation, _ = self.object_pose(phase["object"], timestamp)
                attached = local.copy()
                attached[:3] = matrix @ local[:3] + translation
                attached[3:7] = Rotation.from_matrix(
                    matrix @ Rotation.from_quat(local[3:7]).as_matrix()).as_quat()
                value = blend(prior, attached, weight) if weight else prior.copy()
                # Transfer the last-anchor relative transform onto the moving
                # source prior, with no episode-specific frames or labels.
                if timestamp <= last + duration + self.free_blend:
                    offset = self.morphology_offsets[phase["prefix"]]
                    retain = 1. - float(smooth((timestamp - last - duration) / self.free_blend))
                    aligned = prior.copy()
                    rotation = Rotation.from_quat(prior[3:7])
                    aligned[:3] += rotation.apply(offset["source_prior_local_translation_m"]) * retain
                    relative = Rotation.from_quat(offset["source_prior_relative_rotation_xyzw"])
                    aligned[3:7] = (rotation * Rotation.from_rotvec(relative.as_rotvec() * retain)).as_quat()
                    follow = float(smooth((timestamp - last) / duration))
                    root = aligned if follow == 1. else blend(value, aligned, follow)
                    value[:7] = root[:7]
                value[:3] += correction
                q[si] = value
                kinds[si] = 15
                details[si] = (phase["grasp_index"] if weight else -1,
                               phase["object"] if weight else -1, opening_time, weight)
        return q, kinds, details


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("bundle", "baseline", "parent-proposal", "interval-inputs", "atlas",
                 "base-continuation", "out"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists() and a.base_continuation.parent.resolve() == a.out.parent.resolve()
    motion = SourceFollowingMotion(a.bundle, a.baseline, a.parent_proposal,
                                   a.interval_inputs, a.atlas, base_continuation=a.base_continuation)
    data = {k: v.copy() for k, v in motion.release_parent_data.items()}
    before = data["robot_qpos_inferred"].copy()
    q, kinds, details = (np.asarray(v) for v in zip(*(motion.evaluate(float(t)) for t in motion.times)))
    anchors = data["robot_contact_intent_inferred"].any(axis=2)
    q[anchors] = before[anchors]
    data["robot_qpos_inferred"] = q
    data["robot_grasp_phase_index_inferred"] = details[:, :, 0].astype(np.int16)
    data["robot_blend_object"] = details[:, :, 1].astype(np.int16)
    data["robot_corridor_opening_clock_s"] = details[:, :, 2]
    data["robot_corridor_prior_blend_weight"] = details[:, :, 3]
    data["robot_source_following_release_root_delta_m"] = q[:, :, :3] - before[:, :, :3]
    data["robot_source_following_release_weight"] = np.array(
        [motion.release_weights(float(t)) for t in motion.times])
    kinds[data["robot_contact_intent_bridge"].any(axis=2)] = 3
    data["robot_pose_inference_kind"] = kinds
    changed = np.any(abs(q - before) > 1e-12, axis=2)
    dense_times = np.unique(np.r_[motion.breakpoints,
                                  (motion.breakpoints[:-1] + motion.breakpoints[1:]) / 2])
    dense = np.array([motion.evaluate(float(t))[0] for t in dense_times])
    assert np.isfinite(q).all() and np.isfinite(dense).all()
    np.testing.assert_allclose(np.linalg.norm(dense[:, :, 3:7], axis=2), 1., rtol=0, atol=1e-12)
    for si, side in enumerate(motion.sides):
        limits = np.asarray(motion.rm["joints"][side["side"]]["velocity_limits_rad_s"])
        assert np.all(abs(np.diff(dense[:, si, 7:], axis=0)) <=
                      limits[None] * np.diff(dense_times)[:, None] + 1e-12)
        for phase in side["phases"]:
            analytic = abs(np.diff(phase["qpath"][:, 7:], axis=0)) / np.diff(phase["release_clock"])[:, None]
            assert np.all(analytic <= limits[None] * motion.velocity_margin + 1e-8)
            # Approach and hold must evaluate identically to the parent.
            start, stop = phase["interval"]
            subset = dense_times[(dense_times >= start - phase["duration_s"] - motion.free_blend) &
                                 (dense_times <= stop)]
            for t in subset:
                np.testing.assert_array_equal(motion.evaluate(float(t))[0][si],
                                              super(SourceFollowingMotion, motion).evaluate(float(t))[0][si])
    np.testing.assert_array_equal(q[anchors], before[anchors])
    assert not data["robot_motion_target_validated"].any()
    a.out.mkdir(parents=True)
    payload = a.out / "robot-motion-proposal.npz"
    np.savez_compressed(payload, **data)
    dense_path = a.out / "generated-corridor-waypoints.npz"
    np.savez_compressed(dense_path, timestamps_s=dense_times, robot_qpos_inferred=dense,
                        robot_pose_is_inferred=np.ones(dense.shape[:2], dtype=bool),
                        robot_motion_target_validated=np.zeros(dense.shape[:2], dtype=bool))
    report = {k: motion.release_parent_report[k] for k in (
        "bundle_manifest_sha256", "baseline_manifest_sha256", "interval_report_sha256",
        "atlas_sha256", "material_manifest_sha256", "robot_assets")}
    original_report = json.loads((motion.base_repair / "report.json").read_text())
    report.update(
        source_sha256=sha(Path(__file__)), motion_module_sha256=sha(Path(__file__)),
        base_continuation_proposal=a.base_continuation.name,
        base_continuation_report_sha256=sha(a.base_continuation / "report.json"),
        payload_sha256=sha(payload), generated_waypoint_payload_sha256=sha(dense_path),
        source_frames=len(q), changed_inferred_source_states=int(changed.sum()),
        changed_source_frames_by_side={s: motion.source["frame_indices"][changed[:, si]].tolist()
                                      for si, s in enumerate(("left", "right"))},
        all_original_observation_and_intent_arrays_preserved=True,
        all_inferred_grasp_anchors_bit_exact=True, approach_and_holding_evaluator_bit_exact=True,
        inferred_closed_states=int(anchors.sum()),
        finger_geometric_corridor_unchanged_time_reparameterized=True,
        finger_URDF_velocity_margin=motion.velocity_margin,
        finite_difference_roundoff_budget_rad=1e-12,
        analytic_corridor_finger_speed_checked=True, corridor_clock_changes=motion.corridor_clock_changes,
        morphology_offsets={prefix: {key: v.tolist() for key, v in fields.items()}
                            for prefix, fields in motion.morphology_offsets.items()},
        morphology_offset_schedule="retain through opening, decay over original neutral free blend",
        robot_inference_kinds={**original_report["robot_inference_kinds"],
                               **motion.release_parent_report["robot_inference_kinds"],
                               "15": "inferred source-following release with fitted root transform and hardware opening clock"},
        source_annotations_or_GT_used=False, episode_specific_frames_or_crops=False,
        source_hand_pose_accuracy_accepted=False, continuous_scene_clearance_certified=False,
        new_simulator_run=False, physical_task_accepted=False)
    assert set(map(str, np.unique(kinds))) <= set(report["robot_inference_kinds"])
    (a.out / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({k: report[k] for k in ("changed_inferred_source_states", "inferred_closed_states",
                                          "approach_and_holding_evaluator_bit_exact", "physical_task_accepted")}))


if __name__ == "__main__":
    main()
