"""Schedule an object-relative opening corridor over the complete source task.

Every robot pose is inferred. Original source frames and masks remain intact.
Continuous replay must evaluate this corridor function, not connect the 20 Hz
sampled root poses with a straight chord that skips its intermediate waypoints.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from propose_robot_contact_motion_v1 import blend, smooth


def sha(path):
    with path.open('rb') as h:
        return hashlib.file_digest(h, 'sha256').hexdigest()


class CorridorMotion:
    def __init__(self, bundle, proposal, corridor, baseline, minimum_duration=.3, free_blend=.2, relative_root_speed=1.):
        self.bm = json.loads((bundle / 'manifest.json').read_text())
        self.pr = json.loads((proposal / 'report.json').read_text())
        self.cr = json.loads((corridor / 'report.json').read_text())
        self.rm = json.loads((baseline / 'manifest.json').read_text())
        assert self.pr['bundle_manifest_sha256'] == self.cr['bundle_manifest_sha256'] == sha(bundle / 'manifest.json')
        assert self.pr['payload_sha256'] == sha(proposal / 'robot-motion-proposal.npz')
        assert self.cr['payload_sha256'] == sha(corridor / 'opening-corridor.npz')
        assert self.pr['baseline_manifest_sha256'] == sha(baseline / 'manifest.json')
        assert self.bm['payload']['sha256'] == sha(bundle / 'episode.npz')
        assert not self.cr['failed_levels']
        with np.load(bundle / 'episode.npz', allow_pickle=False) as z:
            self.source = {k: z[k] for k in z.files}
        with np.load(proposal / 'robot-motion-proposal.npz', allow_pickle=False) as z:
            self.original = {k: z[k] for k in z.files}
        with np.load(corridor / 'opening-corridor.npz', allow_pickle=False) as z:
            paths = {k: z[k] for k in z.files}
        self.times = self.source['timestamps_s']
        self.free_blend = free_blend
        self.sides = []
        self.breakpoints = list(self.times)
        for si, side in enumerate(('left', 'right')):
            rows = [v for v in self.cr['waypoints'] if v['side'] == side]
            oi = rows[0]['object']
            qpath = paths[f'{side}_qpos_object_frame_inferred']
            joint_limits = np.array(self.rm['joints'][side]['velocity_limits_rad_s'])
            dq = np.diff(qpath, axis=0)
            required = np.maximum(np.linalg.norm(dq[:, :3], axis=1) / relative_root_speed,
                                  np.max(abs(dq[:, 7:]) / joint_limits[None], axis=1))
            assert (required > 0).all()
            duration = max(minimum_duration, float(required.sum()))
            clock = np.r_[0., np.cumsum(required)]
            clock *= duration / clock[-1]
            intent = self.original['robot_contact_intent_inferred'][:, si, oi]
            starts = np.flatnonzero(intent & ~np.r_[False, intent[:-1]])
            ends = np.flatnonzero(intent & ~np.r_[intent[1:], False])
            assert len(starts) == len(ends)
            intervals = [(float(self.times[first]), float(self.times[last])) for first, last in zip(starts, ends)]
            for previous, current in zip(intervals[:-1], intervals[1:]):
                assert current[0] - previous[1] >= 2 * (duration + free_blend), 'overlapping phase schedules need separate planning'
            for first, last in intervals:
                self.breakpoints.extend(first - clock)
                self.breakpoints.extend(last + clock)
                self.breakpoints.extend((first - duration - free_blend, last + duration + free_blend))
            self.sides.append({'side': side, 'object': oi, 'qpath': qpath, 'clock': clock, 'duration_s': duration,
                               'intervals': intervals, 'original_source_interval_rows': list(zip(starts.tolist(), ends.tolist()))})
        self.breakpoints = np.unique(np.array(self.breakpoints))
        self.breakpoints = self.breakpoints[(self.breakpoints >= self.times[0]) & (self.breakpoints <= self.times[-1])]

    def bracket(self, time):
        assert self.times[0] - 1e-10 <= time <= self.times[-1] + 1e-10
        row = int(np.clip(np.searchsorted(self.times, time, side='right') - 1, 0, len(self.times) - 2))
        fraction = float(np.clip((time - self.times[row]) / (self.times[row + 1] - self.times[row]), 0., 1.))
        return row, fraction

    def object_pose(self, oi, time):
        row, f = self.bracket(time)
        raw = self.source[f'object_{oi}_world'][row:row + 2]
        rotations = Rotation.from_matrix(raw[:, :3, :3])
        rotation = Slerp([0., 1.], rotations)([f]).as_matrix()[0]
        # Keep endpoint source affine residuals explicitly rather than silently
        # rounding source matrices. Their physical/scale family needs a separate
        # complete-task certificate; the static corridor proof alone is weaker.
        residual = raw[:, :3, :3] - rotations.as_matrix()
        rotation += residual[0] * (1 - f) + residual[1] * f
        translation = raw[0, :3, 3] * (1 - f) + raw[1, :3, 3] * f
        scale = float(self.source[f'object_{oi}_scale'][row] * (1 - f) + self.source[f'object_{oi}_scale'][row + 1] * f)
        return rotation, translation, scale

    def prior(self, si, time):
        row, f = self.bracket(time)
        return blend(self.original['robot_qpos_inferred'][row, si], self.original['robot_qpos_inferred'][row + 1, si], f)

    def local_path(self, side, opening_time):
        qpath, clock = side['qpath'], side['clock']
        time = float(np.clip(opening_time, 0., clock[-1]))
        row = int(np.clip(np.searchsorted(clock, time, side='right') - 1, 0, len(clock) - 2))
        fraction = float(np.clip((time - clock[row]) / (clock[row + 1] - clock[row]), 0., 1.))
        return blend(qpath[row], qpath[row + 1], fraction)

    def evaluate(self, time):
        values, kinds, details = [], [], []
        for si, side in enumerate(self.sides):
            first, last = min(side['intervals'], key=lambda pair: 0. if pair[0] <= time <= pair[1] else min(abs(time - pair[0]), abs(time - pair[1])))
            duration = side['duration_s']
            if first <= time <= last:
                opening_time, weight, kind = 0., 1., 2
            elif first - duration <= time < first:
                opening_time, weight, kind = first - time, 1., 9
            elif last < time <= last + duration:
                opening_time, weight, kind = time - last, 1., 9
            else:
                distance = min(abs(time - first), abs(time - last))
                opening_time = duration
                weight = float(smooth(1. - (distance - duration) / self.free_blend))
                kind = 10 if weight > 0 else 7
            local = self.local_path(side, opening_time)
            axis = int(np.argmax(abs(side['qpath'][0, 7:] - side['qpath'][-1, 7:])))
            neutral = side['qpath'][-1, 7 + axis]
            contact_alpha = float((local[7 + axis] - neutral) / (side['qpath'][0, 7 + axis] - neutral))
            details.append((contact_alpha, weight, side['object'] if weight > 0 else -1, opening_time))
            prior = self.prior(si, time)
            if not weight:
                values.append(prior)
                kinds.append(kind)
                continue
            local = self.local_path(side, opening_time)
            rotation, translation, _ = self.object_pose(side['object'], time)
            attached = local.copy()
            attached[:3] = rotation @ local[:3] + translation
            attached[3:7] = Rotation.from_matrix(rotation @ Rotation.from_quat(local[3:7]).as_matrix()).as_quat()
            values.append(blend(prior, attached, weight))
            kinds.append(kind)
        return np.array(values), np.array(kinds, dtype=np.int8), np.array(details)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('bundle', 'proposal', 'corridor', 'baseline', 'continuous-corridor', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists()
    proof = json.loads((a.continuous_corridor / 'report.json').read_text())
    assert proof['corridor_report_sha256'] == sha(a.corridor / 'report.json') and proof['both_complete_corridors_certified']
    motion = CorridorMotion(a.bundle, a.proposal, a.corridor, a.baseline)
    sampled, kinds, details = zip(*(motion.evaluate(float(t)) for t in motion.times))
    sampled = np.array(sampled)
    kinds = np.array(kinds)
    details = np.array(details)
    intent = motion.original['robot_contact_intent_inferred'].any(axis=2)
    np.testing.assert_allclose(sampled[intent, :3], motion.original['robot_qpos_inferred'][intent, :3], atol=1e-12, rtol=0)
    # Preserve original contact anchor bytes after checking the analytical
    # generated evaluation agrees, including quaternion sign equivalence.
    first_rot = Rotation.from_quat(sampled[:, :, 3:7].reshape(-1, 4)).as_matrix().reshape(len(sampled), 2, 3, 3)
    old_rot = Rotation.from_quat(motion.original['robot_qpos_inferred'][:, :, 3:7].reshape(-1, 4)).as_matrix().reshape(len(sampled), 2, 3, 3)
    np.testing.assert_allclose(first_rot[intent], old_rot[intent], atol=1e-12, rtol=0)
    sampled[intent] = motion.original['robot_qpos_inferred'][intent]
    original = {k: v.copy() for k, v in motion.original.items()}
    original['robot_qpos_inferred'] = sampled
    kinds[motion.original['robot_contact_intent_bridge'].any(axis=2)] = 3
    original['robot_pose_inference_kind'] = kinds
    original['parent_robot_contact_blend_weight'] = original.pop('robot_contact_blend_weight')
    original['parent_robot_blend_object'] = original.pop('robot_blend_object')
    original['parent_transition_translation_delta_m'] = original.pop('robot_transition_translation_delta_m')
    original['robot_contact_blend_weight'] = details[:, :, 0]
    original['robot_corridor_prior_blend_weight'] = details[:, :, 1]
    original['robot_blend_object'] = details[:, :, 2].astype(np.int16)
    original['robot_corridor_opening_clock_s'] = details[:, :, 3]
    original['robot_motion_target_validated'][:] = False
    dense_times = np.unique(np.r_[motion.breakpoints, (motion.times[:-1] + motion.times[1:]) / 2])
    dense, dense_kinds, dense_details = zip(*(motion.evaluate(float(t)) for t in dense_times))
    dense = np.array(dense)
    assert np.isfinite(sampled).all() and np.isfinite(dense).all()
    np.testing.assert_allclose(np.linalg.norm(dense[:, :, 3:7], axis=2), 1., atol=1e-12, rtol=0)
    a.out.mkdir(parents=True)
    payload = a.out / 'robot-motion-proposal.npz'
    np.savez_compressed(payload, **original)
    dense_payload = a.out / 'generated-corridor-waypoints.npz'
    np.savez_compressed(dense_payload, timestamps_s=dense_times, robot_qpos_inferred=dense,
                        robot_pose_inference_kind=np.array(dense_kinds), robot_pose_is_inferred=np.ones(dense.shape[:2], dtype=bool),
                        robot_motion_target_validated=np.zeros(dense.shape[:2], dtype=bool), robot_corridor_phase_details=np.array(dense_details))
    inherited_identity = ('bundle_manifest_sha256', 'baseline_manifest_sha256', 'robot_assets', 'region_report_sha256',
                          'template_report_sha256', 'scene_report_sha256', 'timing_report_sha256', 'source_motion_report_sha256',
                          'robot_qpos_convention', 'robot_inference_kinds')
    report = {k: motion.pr[k] for k in inherited_identity}
    report.update(source_observations_or_source_inferred_holds_modified=False, human_display_holds_created=False,
                  all_robot_poses_are_inferred_not_new_observations=True, source_annotations_or_GT_used=False,
                  contact_known=False, parent_pose_geometry_certificates_apply_to_this_candidate=False)
    report.update({'source_sha256': sha(Path(__file__)), 'parent_proposal_report_sha256': sha(a.proposal / 'report.json'),
                   'corridor_report_sha256': sha(a.corridor / 'report.json'),
                   'continuous_corridor_report_sha256': sha(a.continuous_corridor / 'report.json'),
                   'payload_sha256': sha(payload), 'generated_waypoint_payload_sha256': sha(dense_payload),
                   'generated_timeline_samples': len(dense_times), 'original_source_frames_retained': len(sampled),
                   'minimum_opening_duration_s': .3, 'free_prior_blend_duration_s': .2,
                   'relative_root_planning_speed_m_s': 1., 'root_speed_is_not_a_URDF_limit': True,
                   'phases': [{k: v for k, v in side.items() if k not in ('qpath', 'clock')} for side in motion.sides],
                   'original_contact_anchor_bytes_preserved': True,
                   'interpolator': 'evaluate CorridorMotion at actual time; respect all corridor clock breakpoints; do not chord-connect20Hzsamples',
                   'full_scene_physical_audit_passed': False, 'continuous_motion_or_joint_velocity_validated': False,
                   'source_accuracy_accepted': False, 'new_simulator_run': False, 'physical_task_accepted': False,
                   'status': 'complete343-frame generated corridor schedule; actual scene/velocity/source checks pending'})
    report['robot_inference_kinds'] = dict(report['robot_inference_kinds'])
    report['robot_inference_kinds']['9'] = 'generated object-relative opening/closing corridor'
    report['robot_inference_kinds']['10'] = 'generated blend from fully open corridor to source-informed prior'
    (a.out / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'original_frames': len(sampled), 'generated_timeline_samples': len(dense_times), 'phases': report['phases'], 'physical_task_accepted': False}))


if __name__ == '__main__':
    main()
