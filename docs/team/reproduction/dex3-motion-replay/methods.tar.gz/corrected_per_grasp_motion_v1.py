"""Evaluate the per-grasp path with the recorded source-state translation repair.

The repair is piecewise linear in source time. This defines an inferred path;
it does not certify clearance between samples or alter any source observation.
"""
import json
from pathlib import Path

import numpy as np

from generated_per_grasp_motion_v4 import PerGraspMotion, load, sha


class CorrectedPerGraspMotion(PerGraspMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas, proposal):
        super().__init__(bundle, baseline, parent_proposal, interval_inputs, atlas)
        self.repair_report = json.loads((proposal / 'report.json').read_text())
        report = self.repair_report
        assert report['bundle_manifest_sha256'] == sha(bundle / 'manifest.json')
        assert report['baseline_manifest_sha256'] == sha(baseline / 'manifest.json')
        assert report['interval_report_sha256'] == sha(interval_inputs / 'report.json')
        assert report['atlas_sha256'] == sha(atlas)
        assert report['payload_sha256'] == sha(proposal / 'robot-motion-proposal.npz')
        assert not report['physical_task_accepted']
        assert not report['failed_noncontact_states']
        repaired = load(proposal / 'robot-motion-proposal.npz')
        np.testing.assert_array_equal(repaired['timestamps_s'], self.times)
        np.testing.assert_array_equal(repaired['frame_indices'], self.source['frame_indices'])
        for name in ('source_hand_valid', 'source_hand_directly_observed',
                     'source_object_observed', 'source_inferred_hold_state',
                     'robot_contact_intent_inferred', 'robot_contact_intent_bridge'):
            np.testing.assert_array_equal(repaired[name], self.original[name])
        assert repaired['robot_pose_is_inferred'].all()
        assert not repaired['robot_motion_target_validated'].any()
        self.translation_delta = repaired['robot_transition_translation_delta_m']
        assert self.translation_delta.shape == (len(self.times), 2, 3)
        assert np.isfinite(self.translation_delta).all()
        original_samples = np.array([super(CorrectedPerGraspMotion, self).evaluate(float(t))[0]
                                     for t in self.times])
        corrected = original_samples.copy()
        corrected[:, :, :3] += self.translation_delta
        np.testing.assert_allclose(corrected, repaired['robot_qpos_inferred'], rtol=0, atol=1e-12)
        contact = repaired['robot_contact_intent_inferred'].any(axis=2)
        assert not self.translation_delta[contact].any()
        self.source_sample_maximum_error = float(np.abs(corrected - repaired['robot_qpos_inferred']).max())

    def evaluate(self, timestamp):
        q, kinds, details = super().evaluate(timestamp)
        for side in range(2):
            q[side, :3] += np.array([np.interp(timestamp, self.times, self.translation_delta[:, side, axis])
                                    for axis in range(3)])
        return q, kinds, details
