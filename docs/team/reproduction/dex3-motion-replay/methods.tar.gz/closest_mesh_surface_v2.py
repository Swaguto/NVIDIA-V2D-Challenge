"""Exact nearest original-triangle points with a complete grouped-radius KD candidate bounds."""
import numpy as np
from scipy.spatial import cKDTree

def closest_triangle_points(triangles,points):
    triangles=np.asarray(triangles);points=np.asarray(points)
    a,b,c=triangles[:,0],triangles[:,1],triangles[:,2]
    first=b-a;second=c-a;normal=np.cross(first,second);square=np.einsum('ij,ij->i',normal,normal)
    assert np.all(square>1e-30)
    delta=points-a
    projected=points-normal*(np.einsum('ij,ij->i',delta,normal)/square)[:,None]
    relative=projected-a
    u=np.einsum('ij,ij->i',np.cross(relative,second),normal)/square
    v=np.einsum('ij,ij->i',np.cross(first,relative),normal)/square
    interior=(u>=0)&(v>=0)&(u+v<=1)
    candidates=[]
    for start,end in ((a,b),(b,c),(c,a)):
        direction=end-start;length=np.einsum('ij,ij->i',direction,direction)
        assert np.all(length>1e-30)
        fraction=np.clip(np.einsum('ij,ij->i',points-start,direction)/length,0,1)
        candidates.append(start+fraction[:,None]*direction)
    edge=np.stack(candidates,axis=1)
    distances=np.linalg.norm(edge-points[:,None],axis=-1)
    selected=edge[np.arange(len(points)),distances.argmin(axis=1)]
    selected[interior]=projected[interior]
    return selected

class Surface:
    def __init__(self,vertices,faces):
        self.triangles=np.asarray(vertices,dtype=float)[np.asarray(faces,dtype=np.int64)]
        self.centres=self.triangles.mean(axis=1)
        normal=np.cross(self.triangles[:,1]-self.triangles[:,0],self.triangles[:,2]-self.triangles[:,0])
        size=np.linalg.norm(normal,axis=-1);assert np.all(size>1e-15)
        self.normals=normal/size[:,None]
        self.maximum_radius=float(np.linalg.norm(self.triangles-self.centres[:,None],axis=-1).max())
        self.tree=cKDTree(self.centres)
        radii=np.linalg.norm(self.triangles-self.centres[:,None],axis=-1).max(axis=1)
        assert np.all(radii>0)
        # Ratios give identical bins under uniform changes of length unit.
        # Every bin uses its own conservative maximum triangle radius.
        bins=np.floor(np.log2(radii/self.maximum_radius)).astype(np.int64)
        self.radius_groups=[]
        for bucket in np.unique(bins):
            ids=np.flatnonzero(bins==bucket)
            self.radius_groups.append((ids,cKDTree(self.centres[ids]),float(radii[ids].max())))

    def nearest(self,point):
        point=np.asarray(point,dtype=float);assert point.shape==(3,) and np.isfinite(point).all()
        _,initial=self.tree.query(point,k=1)
        first=closest_triangle_points(self.triangles[initial:initial+1],point[None])[0]
        upper=float(np.linalg.norm(first-point))
        candidates=[]
        for ids,tree,radius in self.radius_groups:
            subset=tree.query_ball_point(point,upper+radius+1e-12,eps=0)
            if subset:candidates.extend(ids[np.asarray(subset,dtype=np.int64)].tolist())
        indices=np.asarray(sorted(candidates),dtype=np.int64)
        assert len(indices)>0
        candidate=closest_triangle_points(self.triangles[indices],np.tile(point,(len(indices),1)))
        squared=np.einsum('ij,ij->i',candidate-point,candidate-point)
        selected=int(np.argmin(squared));triangle=int(indices[selected])
        return candidate[selected],self.normals[triangle],triangle,float(np.sqrt(squared[selected])),len(indices)

def analytic_controls():
    triangle=np.array([[[0.,0,0],[1.,0,0],[0,1.,0]]])
    points=np.array([[.2,.3,2.],[-1.,-1,0],[.8,.8,0],[.5,-2,0]])
    repeated=np.repeat(triangle,len(points),axis=0)
    actual=closest_triangle_points(repeated,points)
    np.testing.assert_allclose(actual,[[.2,.3,0],[0,0,0],[.5,.5,0],[.5,0,0]],atol=1e-12)
    mesh=Surface(triangle.reshape(-1,3),np.array([[0,1,2]]))
    point,_,_,distance,_=mesh.nearest(np.array([.2,.3,0.]))
    assert distance==0 and np.min(np.linalg.norm(triangle[0]-point,axis=-1))>.3
    return {'triangle_interior_edge_vertex_analytic_controls':True,'nearest_vertex_can_miss_exact_face_target':True}
