"""Apply the locked automatic release-alignment screen, without accepting poses."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from source_following_release_motion_v5 import SourceFollowingMotion
from corrected_per_grasp_motion_v1 import load, sha


class RetainedReleaseMotion(SourceFollowingMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas,
                 proposal=None, *, base_release=None, calibration=None):
        saved = None
        if proposal is not None:
            saved = json.loads((proposal / "report.json").read_text())
            base_release = proposal.parent / saved["base_release_proposal"]
            calibration = proposal.parent / saved["release_alignment_calibration"]
            assert saved["motion_module_sha256"] == sha(Path(__file__))
            assert saved["payload_sha256"] == sha(proposal / "robot-motion-proposal.npz")
            assert saved["base_release_report_sha256"] == sha(base_release / "report.json")
            assert saved["release_alignment_calibration_report_sha256"] == sha(calibration / "report.json")
            assert saved["physical_task_accepted"] is False
        assert base_release is not None and calibration is not None
        br = json.loads((base_release / "report.json").read_text())
        cr = json.loads((calibration / "report.json").read_text())
        assert br["motion_module_sha256"] == sha(Path(__file__).with_name("source_following_release_motion_v5.py"))
        assert br["payload_sha256"] == sha(base_release / "robot-motion-proposal.npz")
        assert cr["source_sha256"] == sha(Path(__file__).with_name("fit_release_alignment_retention_v1.py"))
        assert cr["proposal_report_sha256"] == sha(base_release / "report.json")
        assert cr["motion_module_sha256"] == br["motion_module_sha256"]
        assert cr["maximum_allowed_material_depth_m"] == .002
        assert not cr["annotations_or_GT_read"] and not cr["source_observations_modified"]
        assert cr["physical_task_accepted"] is False
        super().__init__(bundle, baseline, parent_proposal, interval_inputs, atlas,
                         base_continuation=base_release.parent / br["base_continuation_proposal"])
        assert br["base_continuation_report_sha256"] == sha(self.base_continuation / "report.json")
        self.base_release = base_release
        self.calibration = calibration
        self.base_release_data = load(base_release / "robot-motion-proposal.npz")
        self.base_release_report = br
        self.calibration_report = cr
        entries = {v["prefix"]: v for v in cr["grasps"]}
        assert len(entries) == len(cr["grasps"]) == len(self.morphology_offsets)
        assert set(entries) == set(self.morphology_offsets)
        np.testing.assert_array_equal(cr["global_retention_grid"], np.linspace(0., 1., 21))
        for side in self.sides:
            for phase in side["phases"]:
                entry = entries[phase["prefix"]]
                assert entry["side"] == side["side"]
                assert entry["interval_s"] == list(phase["interval"])
                trials = entry["trials"]
                np.testing.assert_array_equal([v["alignment_retention"] for v in trials], np.linspace(0., 1., 21))
                feasible = [i for i, v in enumerate(trials) if v["finite_explicit_failure_count"] == 0]
                selected = max(feasible, key=lambda i: trials[i]["alignment_retention"]) if feasible else min(
                    range(len(trials)), key=lambda i: (trials[i]["maximum_vertex_depth_lower_m"],
                        trials[i]["squared_excess_depth_sum_m2"], -trials[i]["alignment_retention"]))
                assert entry["selected_index"] == selected
                alpha = trials[selected]["alignment_retention"]
                assert alpha == entry["selected_retention"] and 0 <= alpha <= 1
                assert bool(feasible) == entry["finite_screen_found_feasible_retention"]
                offset = self.morphology_offsets[phase["prefix"]]
                offset["source_prior_local_translation_m"] *= alpha
                relative = Rotation.from_quat(offset["source_prior_relative_rotation_xyzw"])
                offset["source_prior_relative_rotation_xyzw"] = Rotation.from_rotvec(relative.as_rotvec() * alpha).as_quat()
        if saved is not None:
            stored = load(proposal / "robot-motion-proposal.npz")
            for key in ("frame_indices", "timestamps_s", "source_hand_valid", "source_hand_directly_observed",
                        "source_object_observed", "source_inferred_hold_state", "robot_contact_intent_inferred",
                        "robot_contact_intent_bridge", "robot_contact_intent_trailing_extension"):
                np.testing.assert_array_equal(stored[key], self.base_release_data[key])
            assert stored["robot_pose_is_inferred"].all() and not stored["robot_motion_target_validated"].any()
            anchors = stored["robot_contact_intent_inferred"].any(axis=2)
            np.testing.assert_array_equal(stored["robot_qpos_inferred"][anchors],
                                          self.base_release_data["robot_qpos_inferred"][anchors])
            np.testing.assert_array_equal(stored["robot_qpos_inferred"][:, :, 7:],
                                          self.base_release_data["robot_qpos_inferred"][:, :, 7:])
            q = np.array([self.evaluate(float(t))[0] for t in self.times])
            np.testing.assert_allclose(q, stored["robot_qpos_inferred"], rtol=0, atol=1e-12)
            self.source_sample_maximum_error = float(abs(q - stored["robot_qpos_inferred"]).max())
            self.repair_report = saved


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("bundle", "baseline", "parent-proposal", "interval-inputs", "atlas",
                 "base-release", "calibration", "out"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists()
    assert a.out.parent.resolve() == a.base_release.parent.resolve() == a.calibration.parent.resolve()
    motion = RetainedReleaseMotion(a.bundle, a.baseline, a.parent_proposal, a.interval_inputs, a.atlas,
                                   base_release=a.base_release, calibration=a.calibration)
    data = {k: v.copy() for k, v in motion.base_release_data.items()}
    before = data["robot_qpos_inferred"].copy()
    q, kinds, details = (np.asarray(v) for v in zip(*(motion.evaluate(float(t)) for t in motion.times)))
    anchors = data["robot_contact_intent_inferred"].any(axis=2)
    q[anchors] = before[anchors]
    np.testing.assert_allclose(q[:, :, 7:], before[:, :, 7:], rtol=0, atol=1e-12)
    q[:, :, 7:] = before[:, :, 7:]
    data["robot_qpos_inferred"] = q
    data["robot_source_following_release_root_delta_m"] = q[:, :, :3] - motion.release_parent_data["robot_qpos_inferred"][:, :, :3]
    kinds[data["robot_contact_intent_bridge"].any(axis=2)] = 3
    data["robot_pose_inference_kind"] = kinds
    times = np.unique(np.r_[motion.breakpoints, (motion.breakpoints[:-1] + motion.breakpoints[1:]) / 2])
    dense = np.array([motion.evaluate(float(t))[0] for t in times])
    parent_dense = load(a.base_release / "generated-corridor-waypoints.npz")
    np.testing.assert_array_equal(times, parent_dense["timestamps_s"])
    np.testing.assert_array_equal(dense[:, :, 7:], parent_dense["robot_qpos_inferred"][:, :, 7:])
    assert np.isfinite(dense).all() and not data["robot_motion_target_validated"].any()
    a.out.mkdir()
    payload = a.out / "robot-motion-proposal.npz"
    np.savez_compressed(payload, **data)
    dense_path = a.out / "generated-corridor-waypoints.npz"
    np.savez_compressed(dense_path, timestamps_s=times, robot_qpos_inferred=dense,
                        robot_pose_is_inferred=np.ones(dense.shape[:2], dtype=bool),
                        robot_motion_target_validated=np.zeros(dense.shape[:2], dtype=bool))
    changed = np.any(abs(q - before) > 1e-12, axis=2)
    report = dict(motion.base_release_report)
    report.update(source_sha256=sha(Path(__file__)), motion_module_sha256=sha(Path(__file__)),
                  base_release_proposal=a.base_release.name, base_release_report_sha256=sha(a.base_release / "report.json"),
                  release_alignment_calibration=a.calibration.name,
                  release_alignment_calibration_report_sha256=sha(a.calibration / "report.json"),
                  payload_sha256=sha(payload), generated_waypoint_payload_sha256=sha(dense_path),
                  changed_inferred_source_states=int(changed.sum()),
                  changed_source_frames_by_side={s: motion.source["frame_indices"][changed[:, si]].tolist()
                                                for si, s in enumerate(("left", "right"))},
                  all_original_observation_and_intent_arrays_preserved=True,
                  all_inferred_grasp_anchors_bit_exact=True, parent_opening_finger_arrays_bit_exact=True,
                  calibrated_retention_by_grasp={v["prefix"]: v["selected_retention"] for v in motion.calibration_report["grasps"]},
                  all_release_finite_screens_feasible=motion.calibration_report["all_finite_screens_found_feasible_retention"],
                  morphology_offsets={prefix: {key: v.tolist() for key, v in fields.items()}
                                      for prefix, fields in motion.morphology_offsets.items()},
                  source_hand_pose_accuracy_accepted=False, original_triangle_surfaces_certified=False,
                  continuous_scene_clearance_certified=False, new_simulator_run=False, physical_task_accepted=False)
    (a.out / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({k: report[k] for k in ("changed_inferred_source_states", "calibrated_retention_by_grasp",
                                           "all_release_finite_screens_feasible", "physical_task_accepted")}))


if __name__ == "__main__":
    main()
