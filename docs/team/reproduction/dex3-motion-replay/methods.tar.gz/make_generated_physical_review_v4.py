"""Create a source/reconstructed-observation/actual-Sim review with pinned inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import imageio.v2 as imageio
from PIL import Image, ImageDraw
from scipy.spatial.transform import Rotation

p = argparse.ArgumentParser(description=__doc__)
for key in ('bundle','retarget','proposal','replay','color-dir','independent-audit','out'):
    p.add_argument('--'+key,type=Path,required=True)
args = p.parse_args()
sha = lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
if args.out.exists():
    raise FileExistsError(args.out)
bm = json.loads((args.bundle/'manifest.json').read_text())
rm = json.loads((args.retarget/'manifest.json').read_text())
replay = json.loads((args.replay/'complete.json').read_text())
independent = json.loads(args.independent_audit.read_text())
assert independent['status'] == 'passed declared input/state/camera/video audit; visual and physical acceptance pending' and not (args.replay/'failure.json').exists()
assert replay['physical_task_accepted'] is False and replay['display_holds_used'] is False
assert rm['episode_bundle_manifest_sha256'] == replay['bundle_manifest_sha256'] == sha(args.bundle/'manifest.json')
assert rm['payload']['sha256'] == replay['retarget_payload_sha256'] == sha(args.retarget/'retarget.npz')
assert replay['video_sha256'] == sha(args.replay/'replay.mp4')
assert replay['readback_sha256'] == sha(args.replay/'simulator-readback.npz')
d = np.load(args.bundle/'episode.npz',allow_pickle=False)
actual = np.load(args.replay/'simulator-readback.npz',allow_pickle=False)
assert np.array_equal(actual['frame_indices'],d['frame_indices'])
assert np.array_equal(actual['robot_valid'],d['hand_valid'])
position_error = float(np.linalg.norm(actual['camera_c2w_readback'][:,:3,3]-d['camera_c2w'][:,:3,3],axis=1).max())
rotation_error = float((Rotation.from_matrix(actual['camera_c2w_readback'][:,:3,:3]).inv()*Rotation.from_matrix(d['camera_c2w'][:,:3,:3])).magnitude().max())
intrinsic_error = float(np.max(np.abs(actual['camera_intrinsics_readback']-d['intrinsics'])))
assert position_error <= 1e-4 and rotation_error <= 1e-4 and intrinsic_error <= 1e-3
lock = json.loads((args.bundle/'source/provenance/inputs-lock.json').read_text())
colors = {Path(record['path']).name:record['sha256'] for record in lock['source_files'] if '/color/' in record['path']}
assert len(colors) == len(d['frame_indices'])
for frame in d['frame_indices']:
    name = f'{int(frame):06d}.png'
    assert sha(args.color_dir/name) == colors[name],name
proposal = json.loads((args.proposal/'report.json').read_text())
assert proposal['payload_sha256'] == replay['generated_motion_payload_sha256'] == sha(args.proposal/'robot-motion-proposal.npz')
assert proposal['bundle_manifest_sha256'] == sha(args.bundle/'manifest.json')
with np.load(args.proposal/'robot-motion-proposal.npz',allow_pickle=False) as z:
    intent=z['robot_contact_intent_inferred'].any(axis=2)
events={int(d['frame_indices'][0]),int(d['frame_indices'][-1])}
for si in range(2):
    events.update(int(d['frame_indices'][row]) for row in np.flatnonzero(np.diff(intent[:,si].astype(int)))+1)
for record in independent['visibility_color_indicators']:
    events.update(record['below20_color_pixel_source_frames'])
events=sorted(events)
args.out.mkdir(parents=True)
(args.out/'frames').mkdir()
w,h = map(int,d['image_size'])
header = 36
video = args.out/'source-observations-dex3.mp4'
writer = imageio.get_writer(video,fps=float(bm['fps']),codec='libx264',quality=8,macro_block_size=1)
pages = []
sheet = []
for row,frame in enumerate(d['frame_indices']):
    source = Image.open(args.color_dir/f'{int(frame):06d}.png').convert('RGB')
    assert source.size == (w,h)
    reconstructed = source.copy()
    overlay = Image.new('RGBA',(w,h))
    draw = ImageDraw.Draw(overlay)
    inverse = np.linalg.inv(d['camera_c2w'][row])
    for si,side in enumerate(('left','right')):
        if not d['hand_valid'][row,si]:
            continue
        vertices = d['hand_vertices_world'][row,si] @ inverse[:3,:3].T + inverse[:3,3]
        uv = vertices @ d['intrinsics'].T
        uv = uv[:,:2]/uv[:,2,None]
        color = (30,110,255,90) if si == 0 else (255,100,30,90)
        for face in d[f'hand_{side}_faces']:
            if (vertices[face,2]>.01).all():
                points = [tuple(x) for x in uv[face]]
                draw.line([*points,points[0]],fill=color,width=1)
        joints = d['hand_joints_world'][row,si] @ inverse[:3,:3].T + inverse[:3,3]
        pix = joints @ d['intrinsics'].T
        pix = pix[:,:2]/pix[:,2,None]
        for tip in (4,8,12,16,20):
            x,y = pix[tip]
            if joints[tip,2]>.01:
                draw.ellipse((x-4,y-4,x+4,y+4),fill=(*color[:3],255))
    reconstructed = Image.alpha_composite(reconstructed.convert('RGBA'),overlay).convert('RGB')
    sim = Image.open(args.replay/'frames'/f'{int(frame):06d}.png').convert('RGB')
    assert sim.size == (w,h)
    panels = Image.new('RGB',(w*3,h+header),(20,20,20))
    labels = [f'Source rectified video | frame {frame}',f'Recovered hand observations | L {bool(d["hand_valid"][row,0])} R {bool(d["hand_valid"][row,1])}',f'Actual Isaac Sim Dex3 | physical accuracy UNACCEPTED']
    for i,(panel,label) in enumerate(zip((source,reconstructed,sim),labels)):
        panels.paste(panel,(i*w,header))
        ImageDraw.Draw(panels).text((i*w+8,10),label,fill='white')
    writer.append_data(np.asarray(panels))
    if int(frame) in events:
        panels.save(args.out/'frames'/f'{int(frame):06d}.jpg',quality=95)
    sheet.append(panels.resize((1536,335)))
    if len(sheet)==6 or row+1==len(d['frame_indices']):
        page = Image.new('RGB',(1536,335*len(sheet)))
        for i,panel in enumerate(sheet):
            page.paste(panel,(0,335*i))
        filename = f'all-frames-{len(pages):02d}.jpg'
        page.save(args.out/filename,quality=90)
        pages.append({'path':filename,'frames':[int(f) for f in d['frame_indices'][row-len(sheet)+1:row+1]],'sha256':sha(args.out/filename)})
        sheet=[]
writer.close()
reader = imageio.get_reader(video)
decoded = sum(1 for _ in reader)
reader.close()
assert decoded == len(d['frame_indices'])
report = {'episode':bm['episode'],'source_frames':decoded,'source_color_files_verified':len(colors),'source_bundle_sha256':sha(args.bundle/'manifest.json'),'retarget_manifest_sha256':sha(args.retarget/'manifest.json'),'generated_motion_report_sha256':sha(args.proposal/'report.json'),'replay_complete_sha256':sha(args.replay/'complete.json'),'independent_replay_audit_sha256':sha(args.independent_audit),'source_sha256':sha(Path(__file__)),'video_sha256':sha(video),'maximum_camera_position_error_m':position_error,'maximum_camera_rotation_error_rad':rotation_error,'maximum_camera_intrinsics_error_px':intrinsic_error,'pages':pages,'display_holds_used':False,'occlusion_in_observation_wireframe':'wireframe intentionally draws through the source image; it is an alignment overlay, not a visible-surface renderer','physical_task_accepted':False,'hand_pose_accuracy_accepted':False,'event_selection':'automatic inferred contact-intent boundaries and low-color visibility indicators; not source ground truth','visual_review_complete':False}
(args.out/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='pages'},indent=2))
