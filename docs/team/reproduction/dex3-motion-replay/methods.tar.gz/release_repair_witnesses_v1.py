"""Combine locked vertex and complete original-surface repair witnesses.

Triangle interiors can fail while every vertex screen passes. Failed original
surface checks must therefore participate in the same automatic repair-window
construction. Unresolved checks without a geometric witness are refused.
"""
import json
from pathlib import Path

import numpy as np

from corrected_per_grasp_motion_v1 import sha


def collect_witnesses(base, probe, surface_directory, proposal, bundle, material):
    surface_directory = Path(surface_directory)
    surface = json.loads((surface_directory / "report.json").read_text())
    for record in (probe, surface):
        assert record["proposal_report_sha256"] == sha(proposal / "report.json")
        assert record["bundle_manifest_sha256"] == sha(bundle / "manifest.json")
        assert record["material_manifest_sha256"] == sha(material / "manifest.json")
        assert record["physical_task_accepted"] is False
    assert surface["source_sha256"] == sha(Path(__file__).with_name("audit_corrected_motion_source_surfaces_v2.py"))
    for key, filename in (
        ("triangle_certificate_sha256", "audit_static_hold_scene_triangles_v3.py"),
        ("uniform_metric_certificate_sha256", "certify_uniform_metric_triangles_v1.py"),
        ("boundary_module_sha256", "exact_voxel_boundary_v1.py"),
    ):
        assert surface[key] == sha(Path(__file__).with_name(filename))
    frames = np.asarray(base.source["frame_indices"])
    frame_to_row = {int(frame): row for row, frame in enumerate(frames)}
    assert len(frame_to_row) == surface["source_frames_checked"] == len(frames)
    object_ids = tuple(entry["object"] for entry in json.loads((material / "manifest.json").read_text())["objects"])
    expected = {(int(f), s, oi) for f in frames for s in ("left", "right") for oi in object_ids}
    actual = [(v["source_frame"], v["side"], v["against_object"]) for v in surface["checks"]]
    assert len(actual) == len(set(actual)) == surface["complete_surface_checks"] == len(expected)
    assert set(actual) == expected
    bad = [v for v in surface["checks"] if not v["triangle_material_limit_certified"]]
    assert bad == surface["failed_or_unresolved_checks"]
    assert bool(not bad) == surface["all_source_state_original_surfaces_within_declared_2mm_material_limit"]
    failed = set()
    for record in probe["explicit_material_failure_pairs"]:
        assert record["vertex_limit_explicitly_violated"]
        assert record["depth_lower_m"] > .002
        failed.add((float(record["generated_timestamp_s"]), ("left", "right").index(record["side"])))
    for record in bad:
        witness = record["witness"]
        assert witness is not None, "A witness-free unresolved surface check requires stronger geometry evidence before automatic repair"
        assert np.isfinite(witness["point_object_local_m"]).all()
        row = frame_to_row[record["source_frame"]]
        failed.add((float(base.times[row]), ("left", "right").index(record["side"])))
    assert failed and all(base.times[0] <= t <= base.times[-1] for t, _ in failed)
    return sorted(failed), {
        "original_source_surface_audit_report_sha256": sha(surface_directory / "report.json"),
        "original_source_surface_failed_checks_included": len(bad),
        "finite_vertex_failure_pairs_included": len(probe["explicit_material_failure_pairs"]),
        "unique_automatic_side_timestamp_witnesses": len(failed),
        "triangle_interior_failures_participate_in_repair": True,
        "witness_collection_source_sha256": sha(Path(__file__)),
    }
