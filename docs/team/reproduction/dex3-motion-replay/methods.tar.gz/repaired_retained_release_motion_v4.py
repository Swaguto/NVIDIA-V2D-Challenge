"""Evaluate bounded geometry corrections over the locked retained release."""
import json
from pathlib import Path

import numpy as np

from retained_source_following_release_motion_v7 import RetainedReleaseMotion
from corrected_per_grasp_motion_v5 import window_weight
from corrected_per_grasp_motion_v1 import load, sha


class RepairedReleaseMotion(RetainedReleaseMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas, proposal):
        self.extra_profiles_enabled = False
        saved = json.loads((proposal / "report.json").read_text())
        base_path = proposal.parent / saved["base_retained_release_proposal"]
        assert sha(base_path / "report.json") == saved["base_retained_release_report_sha256"]
        assert saved["motion_module_sha256"] == sha(Path(__file__))
        assert saved["payload_sha256"] == sha(proposal / "robot-motion-proposal.npz")
        assert saved["coupled_solver_sha256"] == sha(Path(__file__).with_name("solve_depth_consistent_translation_v7.py"))
        assert not saved["failed_or_unresolved_translation_profiles"]
        assert saved["physical_task_accepted"] is False
        super().__init__(bundle, baseline, parent_proposal, interval_inputs, atlas, base_path)
        self.retained_parent_data = load(base_path / "robot-motion-proposal.npz")
        path = proposal / saved["translation_profiles"]
        assert sha(path) == saved["translation_profiles_sha256"]
        self.extra_profiles = json.loads(path.read_text())["profiles"]
        for profile in self.extra_profiles:
            side = ("left", "right").index(profile["side"])
            start, end = profile["time_start_s"], profile["time_end_s"]
            vector = np.asarray(profile["translation_amplitude_m"])
            assert self.times[0] <= start < end <= self.times[-1]
            assert start in self.times and end in self.times
            assert vector.shape == (3,) and np.isfinite(vector).all()
            assert np.linalg.norm(vector) <= .010 + 1e-10
            for phase in self.sides[side]["phases"]:
                first, last = phase["interval"]
                assert end <= first or start >= last
        self.breakpoints = np.unique(np.r_[self.breakpoints,
            [profile[key] for profile in self.extra_profiles for key in ("time_start_s", "time_end_s")]])
        self.extra_profiles_enabled = True
        data = load(proposal / "robot-motion-proposal.npz")
        for key in ("frame_indices", "timestamps_s", "source_hand_valid", "source_hand_directly_observed",
                    "source_object_observed", "source_inferred_hold_state", "robot_contact_intent_inferred",
                    "robot_contact_intent_bridge", "robot_contact_intent_trailing_extension"):
            np.testing.assert_array_equal(data[key], self.retained_parent_data[key])
        assert data["robot_pose_is_inferred"].all() and not data["robot_motion_target_validated"].any()
        anchors = data["robot_contact_intent_inferred"].any(axis=2)
        np.testing.assert_array_equal(data["robot_qpos_inferred"][anchors],
                                      self.retained_parent_data["robot_qpos_inferred"][anchors])
        np.testing.assert_array_equal(data["robot_qpos_inferred"][:, :, 3:],
                                      self.retained_parent_data["robot_qpos_inferred"][:, :, 3:])
        q = np.array([self.evaluate(float(t))[0] for t in self.times])
        np.testing.assert_allclose(q, data["robot_qpos_inferred"], rtol=0, atol=1e-12)
        self.source_sample_maximum_error = float(abs(q - data["robot_qpos_inferred"]).max())
        self.repair_report = saved

    def evaluate(self, timestamp):
        q, kinds, details = super().evaluate(timestamp)
        if self.extra_profiles_enabled:
            for profile in self.extra_profiles:
                si = ("left", "right").index(profile["side"])
                displacement = window_weight(timestamp, profile["time_start_s"], profile["time_end_s"]) * np.asarray(profile["translation_amplitude_m"])
                q[si, :3] += displacement
                if np.any(displacement != 0.):
                    kinds[si] = 14
        return q, kinds, details
