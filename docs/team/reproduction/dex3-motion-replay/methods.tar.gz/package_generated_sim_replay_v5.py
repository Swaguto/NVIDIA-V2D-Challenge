"""Package locked inputs for a generated Dex3 kinematic simulator diagnostic.

This replays a frozen proposed trajectory. It does not reconstruct the source
video, rerun optimization, accept contact targets, or certify physical dynamics.
"""
import argparse
import gzip
import hashlib
import json
import shutil
import tarfile
import numpy as np
from pathlib import Path


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'bundle', 'baseline', 'proposal', 'scene-audit', 'methods', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists(), 'Use a fresh package directory'
    a.out.mkdir(parents=True)
    bm = json.loads((a.bundle / 'manifest.json').read_text())
    baseline = json.loads((a.baseline / 'manifest.json').read_text())
    motion = json.loads((a.proposal / 'report.json').read_text())
    scene = json.loads((a.scene_audit / 'report.json').read_text())
    assert bm['payload']['sha256'] == sha(a.bundle / 'episode.npz')
    assert baseline['payload']['sha256'] == sha(a.baseline / 'retarget.npz')
    assert baseline['episode_bundle_manifest_sha256'] == sha(a.bundle / 'manifest.json')
    assert motion['bundle_manifest_sha256'] == scene['bundle_manifest_sha256'] == sha(a.bundle / 'manifest.json')
    assert motion['baseline_manifest_sha256'] == sha(a.baseline / 'manifest.json')
    assert motion['payload_sha256'] == sha(a.proposal / 'robot-motion-proposal.npz')
    assert scene['proposal_report_sha256'] == sha(a.proposal / 'report.json')
    assert scene['payload_sha256'] == sha(a.scene_audit / 'robot-motion-scene-audit.npz')
    assert motion['robot_assets'] == baseline['robot_assets']
    with np.load(a.proposal / 'robot-motion-proposal.npz', allow_pickle=False) as z:
        assert z['robot_pose_is_inferred'].all() and not z['robot_motion_target_validated'].any()
    assert not motion['physical_task_accepted']
    files = {}
    for label, folder in (('bundle', a.bundle), ('retarget', a.baseline), ('proposal', a.proposal), ('scene-audit', a.scene_audit)):
        for path in sorted(folder.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                files[label + '/' + path.relative_to(folder).as_posix()] = path
    package_source = a.source / 'source/robotic_grounding/robotic_grounding'
    for path in sorted((package_source / 'retarget').glob('*.py')):
        files['source/robotic_grounding/' + path.relative_to(a.source).as_posix()] = path
    path = package_source / '__init__.py'
    files['source/robotic_grounding/' + path.relative_to(a.source).as_posix()] = path
    assets = package_source / 'assets'
    for relative, expected in baseline['robot_assets']['files_sha256'].items():
        path = assets / relative
        assert sha(path) == expected, relative
        files['source/robotic_grounding/' + path.relative_to(a.source).as_posix()] = path
    for name in ('replay_generated_dex3_source_camera_sim6_v1.py', 'generated-sim-replay-v1-generation.json'):
        files['scripts/' + name] = a.methods / name
    renderer = files['scripts/replay_generated_dex3_source_camera_sim6_v1.py']
    renderer_receipt = json.loads(files['scripts/generated-sim-replay-v1-generation.json'].read_text())
    assert sha(renderer) in renderer_receipt.values(), 'Generated renderer is not in its generation receipt'
    readme = a.out / 'README.txt'
    readme.write_text('''Frozen e002 generated Dex3 motion: simulator diagnostic only.
All 343 source frames and original observation masks are retained. Every robot
pose is inferred; a displayed hand is not a new observed hand or accepted target.
Gravity/collisions are disabled. This package does not reconstruct the video,
rerun the fitting/motion method, verify continuous motion, or accept a grasp.
This proposal keeps all original inferred closed-grasp anchors and finger arrays.
Complete original triangle surfaces pass the declared 2 mm voxel-material limit
at all 343 source times (1,372 checks). A 3,566-time geometry screen has zero
object or cross-hand failures. These are separate measured receipts; neither
proves continuous clearance, true object geometry, table clearance or dynamics.
The automatic whole-edge screen rejected recovered entry robot priors and kept
the existing checked approaches; it retained both improved recovered exits.
Recovered human observations remain separate and unaccepted as robot targets.
Contact proxy coverage is 375/381 labeled core hand-frames with six boundary
gaps. Source wrist accuracy, inferred object tails and the 8-10 mm support-plane
discrepancy remain limitations. No hidden evaluation episodes were used.
This is private development evidence, not submission evidence.

1. Verify file-manifest.json against every file before running.
2. Use pinned Linux Python 3.12, Isaac Sim 6.0.0.1 and Isaac Lab commit
   28a37cecdd433c22d9eabd6a5954add9f13a8951 (3.0.0 beta2).
3. From the pinned Isaac Lab directory, with OMNI_KIT_ACCEPT_EULA=YES and
   OMNI_KIT_ALLOW_ROOT=1, substitute absolute package/runtime/output paths:

   "$PY" "$CASE/scripts/replay_generated_dex3_source_camera_sim6_v1.py" \\
     --source "$CASE/source/robotic_grounding" --bundle "$CASE/bundle" \\
     --retarget "$CASE/retarget" --proposal "$CASE/proposal" \\
     --scene-audit "$CASE/scene-audit" --out "$OUTPUT" \\
     --width 1280 --height 800 --headless --enable_cameras --device cpu \\
     --rendering_mode performance

4. Require complete.json, no failure.json, 343 decoded video frames, and the
   declared joint/root/FK readback tolerances. Inspect the video separately for
   flicker/occlusion; video decoding alone does not verify visual continuity.
5. Download and hash the evidence, then stop the GPU worker when unused.
''')
    files['README.txt'] = readme
    manifest = {
        'schema': 'v2d.dex3.generated-simulator-diagnostic.v5', 'episode': bm['episode'],
        'files_sha256': {name: sha(path) for name, path in sorted(files.items())},
        'bundle_manifest_sha256': sha(a.bundle / 'manifest.json'),
        'baseline_manifest_sha256': sha(a.baseline / 'manifest.json'),
        'proposal_report_sha256': sha(a.proposal / 'report.json'),
        'scene_audit_report_sha256': sha(a.scene_audit / 'report.json'),
        'all_robot_poses_inferred': True, 'source_observation_mask_preserved': True,
        'source_to_motion_method_reproduced': False,
        'continuous_scene_motion_certified': False, 'new_simulator_run': False,
        'flicker_free_visual_result_verified': False, 'physical_task_accepted': False,
    }
    manifest_path = a.out / 'file-manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    files['file-manifest.json'] = manifest_path
    archive = a.out / 'generated-dex3-simulator-inputs-v5.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=2, mtime=0, filename='') as compressed, tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, path in sorted(files.items()):
            info = tar.gettarinfo(str(path), arcname=name)
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mode = 0o644
            with path.open('rb') as stream:
                tar.addfile(info, stream)
    receipt = {
        'archive': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'files': len(files), 'robot_asset_files': len(baseline['robot_assets']['files_sha256']),
        'manifest_sha256': sha(manifest_path), 'packager_sha256': sha(Path(__file__)),
        'scope': 'Frozen private simulator inputs, not full-method reproduction',
        'new_simulator_run': False, 'physical_task_accepted': False,
    }
    (a.out / 'package-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
