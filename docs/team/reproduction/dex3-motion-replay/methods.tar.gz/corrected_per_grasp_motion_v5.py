"""Evaluate coherent smooth translations over automatic missing-hand spans.

Source observations remain untouched; inferred robot priors may change in
wider automatically identified noncontact windows, including valid human frames.
"""
import json
import numpy as np

from corrected_per_grasp_motion_v1 import CorrectedPerGraspMotion as ParentMotion, load, sha


def window_weight(timestamp, start, end):
    if timestamp <= start or timestamp >= end:
        return 0.
    return float(np.sin(np.pi*(timestamp-start)/(end-start))**2)


class CorrectedPerGraspMotion(ParentMotion):
    def __init__(self, bundle, baseline, parent_proposal, interval_inputs, atlas, proposal):
        super().__init__(bundle, baseline, parent_proposal, interval_inputs, atlas, proposal)
        report = self.repair_report
        assert report['gap_translation_profiles'] == 'gap-translation-profiles.json'
        path = proposal / report['gap_translation_profiles']
        assert sha(path) == report['gap_translation_profiles_sha256']
        self.profiles = json.loads(path.read_text())['profiles']
        assert not report['failed_or_unresolved_gap_profiles']
        assert report['base_source_translation_payload'] == 'base-source-translation.npz'
        path = proposal / report['base_source_translation_payload']
        assert sha(path) == report['base_source_translation_payload_sha256']
        base = load(path)
        np.testing.assert_array_equal(base['timestamps_s'], self.times)
        self.translation_delta = base['root_translation_delta_m']
        assert self.translation_delta.shape == (len(self.times), 2, 3)
        assert np.isfinite(self.translation_delta).all()
        for profile in self.profiles:
            si = ('left', 'right').index(profile['side'])
            start, end = profile['time_start_s'], profile['time_end_s']
            amplitude = np.asarray(profile['translation_amplitude_m'])
            assert self.times[0] <= start < end <= self.times[-1]
            assert start in self.times and end in self.times
            assert amplitude.shape == (3,) and np.isfinite(amplitude).all()
            assert abs(amplitude).max() <= .08 + 1e-12
            inside = (self.times > start) & (self.times < end)
            assert report['repair_shoulder_seconds'] > 0
            assert report['all_original_source_observation_arrays_unchanged']
            for phase in self.sides[si]['phases']:
                first, last = phase['interval']
                assert end <= first or start >= last
        self.breakpoints = np.unique(np.r_[self.breakpoints,
                                          [p[k] for p in self.profiles for k in ('time_start_s', 'time_end_s')]])
        q = np.array([self.evaluate(float(t))[0] for t in self.times])
        stored = load(proposal / 'robot-motion-proposal.npz')['robot_qpos_inferred']
        np.testing.assert_allclose(q, stored, rtol=0, atol=1e-12)
        self.source_sample_maximum_error = float(abs(q-stored).max())

    def evaluate(self, timestamp):
        q, kinds, details = super().evaluate(timestamp)
        for profile in self.profiles:
            si = ('left', 'right').index(profile['side'])
            displacement = window_weight(timestamp, profile['time_start_s'], profile['time_end_s']) * np.asarray(profile['translation_amplitude_m'])
            q[si, :3] += displacement
            if np.any(displacement != 0.):
                kinds[si] = 12
        return q, kinds, details

    def profile_velocity_bound(self, side, start, end):
        result = 0.
        for profile in self.profiles:
            if ('left', 'right').index(profile['side']) != side:
                continue
            a, b = profile['time_start_s'], profile['time_end_s']
            if end > a and start < b:
                result += np.pi*np.linalg.norm(profile['translation_amplitude_m'])/(b-a)
        return float(result)
