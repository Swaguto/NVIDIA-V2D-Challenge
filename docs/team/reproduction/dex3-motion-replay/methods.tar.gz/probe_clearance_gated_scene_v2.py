"""Find interpolation failures; midpoint passes are not continuous certificates."""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import coal
import numpy as np
import pinocchio as pin
import trimesh
from scipy.spatial.transform import Rotation, Slerp

from propose_robot_contact_motion_v1 import blend
from clearance_gated_edge_motion_v2 import ClearanceGatedEdgeMotion as CorrectedPerGraspMotion
from audit_static_hold_scene_vertices_v1 import model, controls
from audit_robot_motion_scene_v2 import collision


def sha(path):
    with path.open('rb') as h:
        return hashlib.file_digest(h, 'sha256').hexdigest()


def object_interpolation(first, last, first_scale, last_scale, alpha):
    result = np.eye(4)
    result[:3, 3] = first[:3, 3] * (1 - alpha) + last[:3, 3] * alpha
    result[:3, :3] = Slerp([0., 1.], Rotation.from_matrix(np.array([first[:3, :3], last[:3, :3]])))([alpha]).as_matrix()[0]
    return result, float(first_scale * (1 - alpha) + last_scale * alpha)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'bundle', 'proposal', 'material', 'out', 'parent-proposal', 'interval-inputs', 'atlas', 'baseline'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists()
    started = time.monotonic()
    tested = controls()
    bm = json.loads((a.bundle / 'manifest.json').read_text())
    pr = json.loads((a.proposal / 'report.json').read_text())
    mm = json.loads((a.material / 'manifest.json').read_text())
    assert pr['bundle_manifest_sha256'] == sha(a.bundle / 'manifest.json')
    assert bm['payload']['sha256'] == mm['source_bundle_payload_sha256'] == sha(a.bundle / 'episode.npz')
    assert pr['payload_sha256'] == sha(a.proposal / 'robot-motion-proposal.npz')
    with np.load(a.bundle / 'episode.npz', allow_pickle=False) as z:
        d = {k: z[k] for k in z.files}
    with np.load(a.proposal / 'robot-motion-proposal.npz', allow_pickle=False) as z:
        m = {k: z[k] for k in z.files}
    np.testing.assert_array_equal(m['frame_indices'], d['frame_indices'])
    assert (np.diff(d['frame_indices']) == 1).all()
    sys.path.insert(0, str(a.source / 'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    from robotic_grounding.retarget.track3_collision_voxels import solid_depth_bounds
    verify_robot_assets(pr, a.source / 'source/robotic_grounding/robotic_grounding/assets')
    hands = []
    for side in ('left', 'right'):
        kin = setup_dex3_kinematics(side=side, max_iter=1)
        geom, gd = kin.robot.collision_model, kin.robot.collision_model.createData()
        points, originals, names = [], [], []
        for obj in geom.geometryObjects:
            mesh = trimesh.load(Path(obj.meshPath), force='mesh', process=False)
            v, inverse = np.unique(np.asarray(mesh.vertices, dtype=float), axis=0, return_inverse=True)
            v *= np.asarray(obj.meshScale)
            points.append(v)
            originals.append(model(v, inverse[mesh.faces]))
            names.append(kin.robot.model.frames[obj.parentFrame].name)
        hands.append((kin, geom, gd, points, originals, names))
    grids = {}
    for entry in mm['objects']:
        path = a.material / f"object_{entry['object']}.npz"
        assert sha(path) == entry['payload_sha256']
        with np.load(path, allow_pickle=False) as z:
            grids[entry['object']] = {k: z[k] for k in z.files}
    records, cross_records = [], []
    evaluator = CorrectedPerGraspMotion(a.bundle, a.baseline, a.parent_proposal, a.interval_inputs, a.atlas, a.proposal, source=a.source)
    dense_times = np.unique(np.r_[evaluator.breakpoints, (evaluator.breakpoints[:-1] + evaluator.breakpoints[1:]) / 2])
    probe_times = np.unique(np.r_[dense_times, (dense_times[:-1] + dense_times[1:]) / 2])
    nq = len(probe_times)
    source_pairs = []
    qmid = np.full((nq, 2, 14), np.nan)
    lower = np.full((nq, 2, len(grids)), np.nan)
    upper = np.full_like(lower, np.nan)
    for row in range(nq):
        transforms = {}
        timestamp = float(probe_times[row])
        source_row, fraction = evaluator.bracket(timestamp)
        pair = [int(d['frame_indices'][source_row]), int(d['frame_indices'][source_row + 1])]
        source_pairs.append(pair)
        evaluated = evaluator.evaluate(timestamp)[0]
        for si, side in enumerate(('left', 'right')):
            qmid[row, si] = evaluated[si]
            kin, geom, gd, points, originals, names = hands[si]
            kin.configuration.update(qmid[row, si])
            pin.updateGeometryPlacements(kin.robot.model, kin.configuration.data, geom, gd, qmid[row, si])
            transforms[si] = [coal.Transform3s(tf.rotation, tf.translation) for tf in gd.oMg]
            world = np.concatenate([v @ tf.rotation.T + tf.translation for v, tf in zip(points, gd.oMg)])
            for oi, grid in grids.items():
                rotation, translation, scale = evaluator.object_pose(oi, timestamp)
                matrix = rotation * scale
                local = (world - translation) @ np.linalg.inv(matrix).T
                lb, ub, inside = solid_depth_bounds(local, grid['solid_cells'], grid['empty_center_distance_m'], grid['origin_m'], float(grid['pitch_m']))
                lower[row, si, oi] = max(0., float(lb.max()) * float(np.linalg.svd(matrix, compute_uv=False).min()))
                upper[row, si, oi] = float(ub.max()) * float(np.linalg.svd(matrix, compute_uv=False).max())
                k = int(lb.argmax())
                records.append({'source_frame_pair': pair, 'source_interval_fraction': fraction, 'generated_timestamp_s': timestamp, 'side': side, 'against_object': oi,
                                'depth_lower_m': float(lower[row, si, oi]), 'depth_upper_m': float(upper[row, si, oi]),
                                'vertex_limit_explicitly_violated': bool(lower[row, si, oi] > .002),
                                'witness_original_vertex': k, 'witness_world_m': world[k].tolist(),
                                'source_hand_valid_at_endpoints': d['hand_valid'][source_row:source_row + 2, si].tolist()})
        crossed = []
        for i, first in enumerate(hands[0][4]):
            for j, second in enumerate(hands[1][4]):
                if collision(first, transforms[0][i], second, transforms[1][j]):
                    crossed.append([hands[0][5][i], hands[1][5][j]])
        cross_records.append({'source_frame_pair': pair, 'source_interval_fraction': fraction, 'generated_timestamp_s': timestamp, 'intersecting_cross_hand_original_surface_pairs': crossed})
    assert len(records) == nq * 2 * len(grids)
    a.out.mkdir(parents=True)
    payload = a.out / 'midpoint-probe.npz'
    np.savez_compressed(payload, source_frame_pairs=np.array(source_pairs), generated_timestamps_s=probe_times,
                        robot_qpos_inferred=qmid, maximum_vertex_depth_lower_m=lower, maximum_vertex_depth_upper_m=upper,
                        original_source_hand_valid=d['hand_valid'])
    final = {'source_sha256': sha(Path(__file__)), 'bundle_manifest_sha256': sha(a.bundle / 'manifest.json'),
             'proposal_report_sha256': sha(a.proposal / 'report.json'), 'material_manifest_sha256': sha(a.material / 'manifest.json'),
             'payload_sha256': sha(payload), 'controls': tested, 'interval_midpoints_checked': nq, 'all_per_grasp_analytic_knots_and_every_intermediate_midpoint_probed': True, 'source_sample_evaluator_maximum_error': evaluator.source_sample_maximum_error, 'corrected_motion_module_sha256': sha(Path(__file__).with_name('clearance_gated_edge_motion_v2.py')),
             'material_frames': records, 'cross_hand_frames': cross_records,
             'explicit_material_failure_pairs': [v for v in records if v['vertex_limit_explicitly_violated']],
             'cross_hand_failure_pairs': [v for v in cross_records if v['intersecting_cross_hand_original_surface_pairs']],
             'interpolation': 'PerGraspMotion plus base source translation and coherent sin-squared missing-span profiles; all new recorded robot source-time poses matched; source observations untouched; generated knots/midpoints and source affine residuals retained',
             'source_observations_modified': False, 'continuous_scene_clearance_certified': False,
             'new_simulator_run': False, 'physical_task_accepted': False, 'elapsed_seconds': time.monotonic() - started}
    (a.out / 'report.json').write_text(json.dumps(final, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'probed_times': nq, 'explicit_material_failure_pairs': len(final['explicit_material_failure_pairs']), 'cross_hand_failure_pairs': len(final['cross_hand_failure_pairs']), 'elapsed_seconds': final['elapsed_seconds'], 'physical_task_accepted': False}))


if __name__ == '__main__':
    main()
