"""Development robot motion proposal; never fill or relabel source hand poses.

Source-supported wrist priors use a separately inferred robot morphology offset.
Existing contact hypotheses anchor the robot to observed object motion. Bounded
robot-intent continuity, interpolated priors and entry/exit waypoints remain
explicitly inferred. No proposed pose is a validated motion target yet.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation, Slerp


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def smooth(value):
    value = np.clip(value, 0., 1.)
    return value * value * (3. - 2. * value)


def blend(first, second, weight):
    result = first * (1. - weight) + second * weight
    result[3:7] = Slerp([0., 1.], Rotation.from_quat(np.array([first[3:7], second[3:7]])))([weight]).as_quat()[0]
    return result


def interpolate_priors(times, values, reliable):
    rows = np.flatnonzero(reliable)
    assert len(rows) >= 2 and np.isfinite(values[rows]).all()
    inside = (times >= times[rows[0]]) & (times <= times[rows[-1]])
    result = np.full_like(values, np.nan)
    for axis in list(range(3)) + list(range(7, values.shape[1])):
        result[inside, axis] = np.interp(times[inside], times[rows], values[rows, axis])
    result[inside, 3:7] = Slerp(times[rows], Rotation.from_quat(values[rows, 3:7]))(times[inside]).as_quat()
    return result, rows, inside


def bridge_robot_intent(frames, times, source_holds, object_observed, direct_hand, near_tip, maximum_gap_s=.35):
    # This function returns a distinct robot-intent hypothesis. It does not
    # change the source contact states or observation masks.
    result = source_holds.copy()
    bridged = np.zeros_like(result)
    for oi in range(source_holds.shape[1]):
        rows = np.flatnonzero(source_holds[:, oi])
        for first, last in zip(rows[:-1], rows[1:]):
            gap = np.arange(first + 1, last)
            if not len(gap) or times[last] - times[first] > maximum_gap_s + 1e-10:
                continue
            if not np.all(np.diff(frames[first:last + 1]) == 1):
                continue
            if source_holds[gap].any() or not object_observed[gap, oi].all():
                continue
            known = gap[direct_hand[gap]]
            if len(known) and not np.all(near_tip[known, oi] <= .02):
                continue
            result[gap, oi] = True
            bridged[gap, oi] = True
    assert np.all(result.sum(axis=1) <= 1)
    return result, bridged


def controls():
    frames = np.arange(9)
    times = frames * .05
    holds = np.zeros((9, 2), dtype=bool)
    holds[[1, 4], 0] = True
    original = holds.copy()
    observed = np.ones_like(holds)
    direct = np.ones(9, dtype=bool)
    near = np.full((9, 2), .005)
    inferred, bridged = bridge_robot_intent(frames, times, holds, observed, direct, near)
    assert inferred[1:5, 0].all() and bridged[2:4, 0].all()
    np.testing.assert_array_equal(holds, original)
    observed[2, 0] = False
    assert not bridge_robot_intent(frames, times, holds, observed, direct, near)[1].any()
    observed[:] = True
    near[2, 0] = .03
    assert not bridge_robot_intent(frames, times, holds, observed, direct, near)[1].any()
    near[:] = .005
    holds[3, 1] = True
    assert not bridge_robot_intent(frames, times, holds, observed, direct, near)[1].any()
    holds[:] = original
    assert not bridge_robot_intent(frames, times * 5, holds, observed, direct, near)[1].any()
    broken = frames.copy()
    broken[3:] += 1
    assert not bridge_robot_intent(broken, times, holds, observed, direct, near)[1].any()
    first = np.r_[np.zeros(3), Rotation.from_euler('z', 179, degrees=True).as_quat(), np.zeros(7)]
    last = first.copy()
    last[3:7] = Rotation.from_euler('z', -179, degrees=True).as_quat()
    middle = blend(first, last, .5)
    assert abs(np.linalg.norm(middle[3:7]) - 1) < 1e-12
    assert abs(Rotation.from_quat(middle[3:7]).magnitude() - np.pi) < 1e-12
    return {'original_source_states_not_mutated': True, 'unknown_object_or_far_observed_hand_refuses_robot_bridge': True,
            'competing_object_and_long_gap_refused': True, 'missing_source_frame_id_refused': True,
            'shortest_quaternion_rotation_across_pi': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('bundle', 'baseline', 'regions', 'templates', 'scenes', 'timing', 'source-motion', 'hold-surfaces', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    a = parser.parse_args()
    assert not a.out.exists()
    tested = controls()
    reports = {name: json.loads((getattr(a, name.replace('-', '_')) / ('manifest.json' if name in ('bundle', 'baseline') else 'report.json')).read_text())
               for name in ('bundle', 'baseline', 'regions', 'templates', 'scenes', 'timing', 'source-motion', 'hold-surfaces')}
    bm, rm = reports['bundle'], reports['baseline']
    bundle_hash = sha(a.bundle / 'manifest.json')
    assert rm['episode_bundle_manifest_sha256'] == bundle_hash
    for name in ('regions', 'templates', 'scenes', 'timing', 'source-motion', 'hold-surfaces'):
        assert reports[name]['bundle_manifest_sha256'] == bundle_hash
    assert reports['regions']['regions_payload_sha256'] == sha(a.regions / 'regions.npz')
    assert reports['timing']['payload_sha256'] == sha(a.timing / 'hold-hypotheses.npz')
    assert reports['source-motion']['payload_sha256'] == sha(a.source_motion / 'motion-evidence.npz')
    assert rm['payload']['sha256'] == sha(a.baseline / 'retarget.npz')
    assert bm['payload']['sha256'] == sha(a.bundle / 'episode.npz')
    assert reports['scenes']['template_report_sha256'] == sha(a.templates / 'report.json')
    assert reports['hold-surfaces']['scene_report_sha256'] == sha(a.scenes / 'report.json')
    assert reports['hold-surfaces']['timing_report_sha256'] == sha(a.timing / 'report.json')
    assert reports['hold-surfaces']['all_original_surface_limits_certified_on_inferred_holds']
    assert not reports['hold-surfaces']['cross_hand_intersection_source_frames']
    loaded = {}
    for name, path in (('d', a.bundle / 'episode.npz'), ('q', a.baseline / 'retarget.npz'), ('r', a.regions / 'regions.npz'),
                       ('h', a.timing / 'hold-hypotheses.npz'), ('m', a.source_motion / 'motion-evidence.npz')):
        with np.load(path, allow_pickle=False) as archive:
            loaded[name] = {k: archive[k] for k in archive.files}
    d, q, r, h, m = (loaded[name] for name in ('d', 'q', 'r', 'h', 'm'))
    for other in (q, r, h, m):
        np.testing.assert_array_equal(other['frame_indices'], d['frame_indices'])
        np.testing.assert_array_equal(other['source_hand_valid'], d['hand_valid'])
        np.testing.assert_array_equal(other['source_hand_directly_observed'], d['hand_directly_observed'])
    np.testing.assert_array_equal(q['robot_valid'], d['hand_valid'])
    n, hands, objects = h['inferred_hold_state'].shape
    times = d['timestamps_s']
    assert np.all(np.diff(times) > 0) and np.all(np.diff(d['frame_indices']) > 0)
    proposal = np.full((n, hands, q['robot_qpos'].shape[-1]), np.nan)
    intent = np.zeros((n, hands, objects), dtype=bool)
    bridge = np.zeros_like(intent)
    contact_weight = np.zeros((n, hands))
    selected_object = np.full((n, hands), -1, dtype=np.int16)
    kind = np.zeros((n, hands), dtype=np.int8)
    source_prior = q['robot_valid'] & d['hand_directly_observed']
    records = []
    for si, side in enumerate(('left', 'right')):
        selected = [v for v in reports['scenes']['scenes'] if v['side'] == side]
        assert len(selected) == 1, 'Multiple robot morphology/contact layouts need separate continuity proposals'
        scene = selected[0]
        oi = scene['object']
        candidate = next(v for v in reports['templates']['templates'] if v['side'] == side and v['object'] == oi and v.get('seed') == scene['seed'])
        assert candidate['success']
        source_rows = np.unique(r['candidate_rows_hand_object'][(r['candidate_rows_hand_object'][:, 1] == si) & (r['candidate_rows_hand_object'][:, 2] == oi), 0])
        source_rotations = d[f'object_{oi}_world'][source_rows, :3, :3].transpose(0, 2, 1) @ Rotation.from_quat(q['robot_qpos'][source_rows, si, 3:7]).as_matrix()
        source_rotation = Rotation.from_matrix(source_rotations).mean().as_matrix()
        template = np.array(candidate['qpos_object_frame'])
        source_root = np.array(candidate['source_root_object_scaled_m'])
        local_offset = source_rotation.T @ (template[:3] - source_root)
        rotation_offset = source_rotation.T @ Rotation.from_quat(template[3:7]).as_matrix()
        transformed = np.full((n, 14), np.nan)
        rows = np.flatnonzero(source_prior[:, si])
        baseline_rotation = Rotation.from_quat(q['robot_qpos'][rows, si, 3:7]).as_matrix()
        transformed[rows] = q['robot_qpos'][rows, si]
        transformed[rows, :3] += np.einsum('bij,j->bi', baseline_rotation, local_offset)
        transformed[rows, 3:7] = Rotation.from_matrix(baseline_rotation @ rotation_offset).as_quat()
        prior, rows, inside = interpolate_priors(times, transformed, source_prior[:, si])
        current_intent, bridged = bridge_robot_intent(d['frame_indices'], times, h['inferred_hold_state'][:, si] > 0,
                                                     h['source_object_observed'], source_prior[:, si], m['nearest_source_tip_CAD_sample_distance_m'][:, si])
        intent[:, si] = current_intent
        bridge[:, si] = bridged
        kind[inside, si] = np.where(source_prior[inside, si], 1, 5)
        attached = np.empty_like(prior)
        template_rotation = Rotation.from_quat(template[3:7]).as_matrix()
        object_poses = d[f'object_{oi}_world']
        attached[:, :3] = np.einsum('bij,j->bi', object_poses[:, :3, :3], template[:3]) + object_poses[:, :3, 3]
        attached[:, 3:7] = Rotation.from_matrix(object_poses[:, :3, :3] @ template_rotation).as_quat()
        attached[:, 7:] = template[7:]
        # Entry/exit waypoints use a tangent-plane retreat from the inferred
        # contact region towards the template palm. They are unobserved and
        # still require full-scene physical validation; no safety is asserted.
        contact_center = np.mean([v['point_object_scaled_m'] for v in candidate['pads']], axis=0)
        retreat = template[:3] - contact_center
        retreat[candidate['source_region_normal_axis']] = 0.
        assert np.linalg.norm(retreat) > 1e-6
        retreat /= np.linalg.norm(retreat)
        for first_or_last, edge_rows, entering in ((rows[0], np.arange(rows[0]), True), (rows[-1], np.arange(rows[-1] + 1, n), False)):
            if not len(edge_rows):
                continue
            anchor = attached[first_or_last] if current_intent[first_or_last, oi] else prior[first_or_last]
            direction = object_poses[first_or_last, :3, :3] @ retreat
            direction /= np.linalg.norm(direction)
            progress = smooth((times[edge_rows] - (times[first_or_last] - .5)) / .5) if entering else smooth((times[edge_rows] - times[first_or_last]) / .5)
            magnitude = (1 - progress) * .2 if entering else progress * .2
            prior[edge_rows] = anchor
            prior[edge_rows, :3] += magnitude[:, None] * direction
            kind[edge_rows, si] = 6
        assert np.isfinite(prior).all()
        active_rows = np.flatnonzero(current_intent[:, oi])
        assert len(active_rows)
        for row in range(n):
            nearest = active_rows[np.argmin(np.abs(times[active_rows] - times[row]))]
            distance = abs(times[nearest] - times[row])
            weight = 1. if current_intent[row, oi] else float(smooth(1. - distance / .2))
            proposal[row, si] = blend(prior[row], attached[row], weight)
            contact_weight[row, si] = weight
            if weight > 0:
                selected_object[row, si] = oi
            if current_intent[row, oi]:
                kind[row, si] = 3 if bridged[row, oi] else 2
            elif weight > 0:
                kind[row, si] = 4
        records.append({'side': side, 'object': oi, 'seed': scene['seed'], 'source_calibration_rows': source_rows.tolist(),
                        'inferred_morphology_translation_in_source_root_frame_m': local_offset.tolist(),
                        'inferred_morphology_rotation_in_source_root_frame_matrix': rotation_offset.tolist(),
                        'source_supported_prior_frames': len(rows), 'source_hold_hypothesis_frames': int((h['inferred_hold_state'][:, si, oi] > 0).sum()),
                        'generated_robot_contact_intent_frames': int(current_intent[:, oi].sum()),
                        'additional_robot_intent_source_frames': d['frame_indices'][bridged[:, oi]].tolist(),
                        'inferred_entry_exit_waypoint_frames': int((kind[:, si] == 6).sum()),
                        'interpolated_prior_frames': int((kind[:, si] == 5).sum()),
                        'transition_frames': int((kind[:, si] == 4).sum()), 'physical_task_accepted': False})
    assert np.isfinite(proposal).all()
    np.testing.assert_allclose(np.linalg.norm(proposal[:, :, 3:7], axis=2), 1., atol=1e-10, rtol=0)
    a.out.mkdir(parents=True)
    payload = a.out / 'robot-motion-proposal.npz'
    np.savez_compressed(payload, frame_indices=d['frame_indices'], timestamps_s=times,
                        source_hand_valid=d['hand_valid'], source_hand_directly_observed=d['hand_directly_observed'],
                        source_object_observed=h['source_object_observed'], source_inferred_hold_state=h['inferred_hold_state'],
                        robot_source_prior_available=source_prior, robot_qpos_inferred=proposal,
                        robot_contact_intent_inferred=intent, robot_contact_intent_bridge=bridge,
                        robot_contact_blend_weight=contact_weight, robot_blend_object=selected_object,
                        robot_pose_inference_kind=kind, robot_pose_is_inferred=np.ones((n, hands), dtype=bool),
                        robot_motion_target_validated=np.zeros((n, hands), dtype=bool))
    report = {'source_sha256': sha(Path(__file__)), 'bundle_manifest_sha256': bundle_hash,
              'baseline_manifest_sha256': sha(a.baseline / 'manifest.json'), 'region_report_sha256': sha(a.regions / 'report.json'),
              'template_report_sha256': sha(a.templates / 'report.json'), 'scene_report_sha256': sha(a.scenes / 'report.json'),
              'timing_report_sha256': sha(a.timing / 'report.json'), 'source_motion_report_sha256': sha(a.source_motion / 'report.json'),
              'hold_surface_audit_sha256': sha(a.hold_surfaces / 'report.json'), 'payload_sha256': sha(payload),
              'robot_assets': rm['robot_assets'], 'controls': tested, 'source_frames': n, 'summaries': records,
              'robot_qpos_convention': 'XYZ metres, XYZW root quaternion, original seven robot finger joint angles radians',
              'robot_inference_kinds': {'1': 'source-wrist-informed robot morphology prior', '2': 'original source-inferred hold anchors robot to object',
                                       '3': 'bounded robot-intent continuity, not a source hold observation', '4': 'generated transition between prior and object anchor',
                                       '5': 'interpolated robot prior; original hand observation remains missing', '6': 'unobserved entry/exit waypoint'},
              'maximum_robot_intent_gap_s': .35, 'known_source_tip_distance_limit_m': .02,
              'transition_duration_s': .2, 'entry_exit_duration_s': .5, 'entry_exit_retreat_distance_m': .2,
              'entry_exit_retreat_direction': 'template root minus planned contact centre projected off declared opposition normal axis',
              'source_observations_or_source_inferred_holds_modified': False, 'human_display_holds_created': False,
              'all_robot_poses_are_inferred_not_new_observations': True, 'source_annotations_or_GT_used': False,
              'source_accuracy_accepted': False, 'full_scene_physical_audit_passed': False,
              'continuous_motion_or_joint_velocity_validated': False, 'new_simulator_run': False,
              'contact_known': False, 'physical_task_accepted': False,
              'status': 'complete-frame motion proposal only; every robot motion-target validation bit false until independent checks'}
    assert sha(a.bundle / 'manifest.json') == bundle_hash
    assert bm['payload']['sha256'] == sha(a.bundle / 'episode.npz')
    (a.out / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'summaries': records, 'all_proposal_poses_finite': True, 'robot_targets_validated': 0, 'physical_task_accepted': False}))


if __name__ == '__main__':
    main()
