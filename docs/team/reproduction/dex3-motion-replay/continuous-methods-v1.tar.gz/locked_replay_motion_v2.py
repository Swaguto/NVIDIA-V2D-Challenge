"""Declare the final replay interpolation explicitly, preserving grasp anchors.

Free motion uses linear translation/fingers and shortest quaternion SLERP at
locked procedural knots. Closed grasp intervals retain the existing rigid
object-following evaluator. This is a new between-knot candidate, not a proof
that finite probes certify its procedural parent. All robot states are inferred.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from corrected_per_grasp_motion_v1 import load,sha
from propose_robot_contact_motion_v1 import blend
from clearance_gated_edge_motion_v2 import ClearanceGatedEdgeMotion


class LockedReplayMotion:
    def __init__(self,bundle,baseline,parent_proposal,interval_inputs,atlas,proposal,*,source):
        saved=json.loads((proposal/'report.json').read_text())
        assert saved['motion_module_sha256']==sha(Path(__file__))
        assert saved['payload_sha256']==sha(proposal/'robot-motion-proposal.npz')
        assert saved['replay_knots_sha256']==sha(proposal/'replay-knots.npz')
        assert saved['physical_task_accepted'] is False
        parent=proposal.parent/saved['procedural_parent_proposal']
        assert saved['procedural_parent_report_sha256']==sha(parent/'report.json')
        self.base=ClearanceGatedEdgeMotion(bundle,baseline,parent_proposal,interval_inputs,atlas,parent,source=source)
        z=load(proposal/'replay-knots.npz')
        self.breakpoints=z['timestamps_s']
        self.knot_q=z['qpos_inferred']
        self.knot_kinds=z['inference_kind']
        self.knot_details=z['phase_details']
        assert np.all(np.diff(self.breakpoints)>0) and np.isin(self.base.times,self.breakpoints).all()
        original=load(parent/'robot-motion-proposal.npz')
        self.source_q=original['robot_qpos_inferred']
        self.hold_local={}
        for si,side in enumerate(self.base.sides):
            for phase in side['phases']:
                rows=np.asarray(phase['source_rows'])
                world=self.base.source[f"object_{phase['object']}_world"][rows]
                rotation=Rotation.from_matrix(world[:,:3,:3])
                local=self.source_q[rows,si].copy()
                local[:,:3]=rotation.inv().apply(local[:,:3]-world[:,:3,3])
                local[:,3:7]=(rotation.inv()*Rotation.from_quat(local[:,3:7])).as_quat()
                self.hold_local[phase['prefix']]={'rows':rows,'qpos':local}
        data=load(proposal/'robot-motion-proposal.npz')
        for key in original:np.testing.assert_array_equal(data[key],original[key])
        indices=np.searchsorted(self.breakpoints,self.base.times)
        np.testing.assert_array_equal(self.knot_q[indices],data['robot_qpos_inferred'])
        self.repair_report=saved
        self.source_sample_maximum_error=0.

    def __getattr__(self,name):return getattr(self.base,name)

    def evaluate(self,timestamp):
        row=int(np.clip(np.searchsorted(self.breakpoints,timestamp,side='right')-1,0,len(self.breakpoints)-2))
        fraction=float(np.clip((timestamp-self.breakpoints[row])/(self.breakpoints[row+1]-self.breakpoints[row]),0,1))
        q=np.array([blend(self.knot_q[row,si],self.knot_q[row+1,si],fraction) for si in range(2)])
        kinds=self.knot_kinds[row].copy()
        details=self.knot_details[row].copy()
        if fraction==0:q=self.knot_q[row].copy()
        elif fraction==1:q=self.knot_q[row+1].copy()
        for si,side in enumerate(self.base.sides):
            for phase in side['phases']:
                if phase['interval'][0]<=timestamp<=phase['interval'][1]:
                    source_row,f=self.base.bracket(timestamp)
                    support=self.hold_local[phase['prefix']]
                    i=int(np.searchsorted(support['rows'],source_row))
                    i=min(i,len(support['rows'])-2)
                    local=blend(support['qpos'][i],support['qpos'][i+1],f)
                    raw=self.base.source[f"object_{phase['object']}_world"][source_row:source_row+2]
                    rotation=Slerp([0.,1.],Rotation.from_matrix(raw[:,:3,:3]))([f])[0]
                    translation=raw[0,:3,3]*(1-f)+raw[1,:3,3]*f
                    q[si]=local
                    q[si,:3]=rotation.apply(local[:3])+translation
                    q[si,3:7]=(rotation*Rotation.from_quat(local[3:7])).as_quat()
                    kinds[si]=2
                    if timestamp in self.base.times:
                        q[si]=self.source_q[np.searchsorted(self.base.times,timestamp),si]
                    break
        return q,kinds,details


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','parent-proposal','interval-inputs','atlas','procedural','out'):
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args()
    assert not a.out.exists() and a.procedural.parent.resolve()==a.out.parent.resolve()
    motion=ClearanceGatedEdgeMotion(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,a.procedural,source=a.source)
    dense=np.unique(np.r_[motion.breakpoints,(motion.breakpoints[:-1]+motion.breakpoints[1:])/2])
    times=np.unique(np.r_[dense,(dense[:-1]+dense[1:])/2,motion.times])
    q,kinds,details=(np.asarray(v) for v in zip(*(motion.evaluate(float(t)) for t in times)))
    original=load(a.procedural/'robot-motion-proposal.npz')
    np.testing.assert_array_equal(q[np.searchsorted(times,motion.times)],original['robot_qpos_inferred'])
    a.out.mkdir(parents=True)
    np.savez_compressed(a.out/'robot-motion-proposal.npz',**original)
    knots=a.out/'replay-knots.npz'
    np.savez_compressed(knots,timestamps_s=times,qpos_inferred=q,inference_kind=kinds,phase_details=details)
    report={**motion.repair_report,'motion_module_sha256':sha(Path(__file__)),
        'payload_sha256':sha(a.out/'robot-motion-proposal.npz'),'replay_knots_sha256':sha(knots),
        'procedural_parent_proposal':a.procedural.name,'procedural_parent_report_sha256':sha(a.procedural/'report.json'),
        'explicit_replay_knot_count':len(times),'source_samples_and_grasp_anchors_unchanged':True,
        'free_between_knot_interpolation':'linear XYZ/fingers; shortest quaternion SLERP',
        'closed_grasp_interpolation':'rigid object motion with linear local XYZ and local shortest SLERP between unchanged source anchors',
        'new_between_knot_candidate':True,'physical_task_accepted':False,'new_simulator_run':False}
    (a.out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'replay_knots':len(times),'source_frames':len(motion.times),'physical_task_accepted':False}))

if __name__=='__main__':main()
