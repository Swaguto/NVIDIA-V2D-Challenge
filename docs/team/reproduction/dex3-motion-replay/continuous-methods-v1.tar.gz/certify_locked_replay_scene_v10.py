"""Continuous surface bounds for an explicitly declared inferred replay.

Free intervals are linear XYZ/fingers and shortest quaternion SLERP. Grasp
intervals are rigid object attachments. URDF lever bounds enclose every original
mesh point at unsampled times. Source scale and affine residuals are bounded.
Refuse actual collisions and unresolved intervals; finite samples never certify.
"""
import argparse
import json
from pathlib import Path
import sys
import time

import coal
import numpy as np
import pinocchio as pin
import trimesh
from scipy.spatial.transform import Rotation

from locked_replay_motion_v3 import LockedReplayMotion
from corrected_per_grasp_motion_v1 import load,sha
from exact_voxel_boundary_batched_v1 import Boundary
from audit_static_hold_scene_triangles_v7 import material_box,mesh_certificate
from audit_static_hold_scene_triangles_v7 import controls
from dex3_self_distance_v5 import SelfDistances,primitive_controls
from certify_uniform_metric_triangles_v5 import certify


def angle(a,b):return float((Rotation.from_quat(a).inv()*Rotation.from_quat(b)).magnitude())

def distance(a,ta,b,tb):
    request=coal.DistanceRequest()
    request.enable_signed_distance=True
    request.gjk_tolerance=1e-10
    result=coal.DistanceResult()
    coal.distance(a,ta,b,tb,request,result)
    return float(result.min_distance)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','bundle','baseline','parent-proposal','interval-inputs','atlas','proposal','material','out'):
        p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--resume-from',type=Path)
    a=p.parse_args()
    assert not a.out.exists()
    started=time.monotonic()
    motion=LockedReplayMotion(a.bundle,a.baseline,a.parent_proposal,a.interval_inputs,a.atlas,a.proposal,source=a.source)
    tested={**controls(),'primitive_signed_distance_controls':primitive_controls()}
    pr=motion.repair_report
    mm=json.loads((a.material/'manifest.json').read_text())
    assert pr['material_manifest_sha256']==sha(a.material/'manifest.json')
    assert mm['source_bundle_payload_sha256']==sha(a.bundle/'episode.npz')
    sys.path.insert(0,str(a.source/'source/robotic_grounding'))
    from robotic_grounding.retarget.retarget_utils import setup_dex3_kinematics
    from robotic_grounding.retarget.track3_model_lock import verify_robot_assets
    assets=a.source/'source/robotic_grounding/robotic_grounding/assets'
    verify_robot_assets(pr,assets)
    materials={}
    for entry in mm['objects']:
        path=a.material/f"object_{entry['object']}.npz"
        assert sha(path)==entry['payload_sha256']
        z=load(path)
        boundary=Boundary(z['solid_cells'],z['origin_m'],float(z['pitch_m']))
        raw=motion.source[f"object_{entry['object']}_world"][:,:3,:3]
        residual=raw-Rotation.from_matrix(raw).as_matrix()
        epsilon=float(np.linalg.norm(residual,ord=2,axis=(1,2)).max())+1e-12
        scale=motion.source[f"object_{entry['object']}_scale"]
        assert epsilon<1e-5 and scale.min()>0
        materials[entry['object']]={'boundary':boundary,'box':material_box(boundary),
            'epsilon':epsilon,'scale_min':float(scale.min()),'scale_max':float(scale.max()),
            'scale_reference':float(np.median(scale))}
    hands=[]
    geometry=[]
    for side in ('left','right'):
        kin=setup_dex3_kinematics(side=side,max_iter=1)
        robot,geom=kin.robot.model,kin.robot.collision_model
        checker=SelfDistances(kin,assets/f'urdfs/g1/dex3_{side}.urdf')
        tris,vertices,levers,radii,names=[],[],[],[],[]
        faces=[]
        for obj in geom.geometryObjects:
            mesh=trimesh.load(Path(obj.meshPath),force='mesh',process=False)
            v=np.asarray(mesh.vertices,dtype=float)*np.asarray(obj.meshScale)
            unique,inverse=np.unique(v,axis=0,return_inverse=True)
            np.testing.assert_array_equal(unique[inverse],v)
            vertices.append(unique)
            faces.append(inverse[mesh.faces])
            tris.append(v[mesh.faces])
            radius=float(np.linalg.norm(v,axis=1).max())+float(np.linalg.norm(obj.placement.translation))
            lever=np.zeros(7)
            joint=int(obj.parentJoint)
            while joint>1:
                assert robot.idx_qs[joint]==joint+5
                lever[joint-2]=radius
                radius+=float(np.linalg.norm(robot.jointPlacements[joint].translation))
                joint=int(robot.parents[joint])
            radii.append(radius);levers.append(lever)
            names.append(robot.frames[obj.parentFrame].name)
            geometry.append({'side':side,'link':names[-1],'mesh_sha256':sha(Path(obj.meshPath)),
                'original_triangles':len(mesh.faces),'root_radius_m':radius,'joint_levers_m':lever.tolist(),
                'original_vertices':len(v),'unique_vertices':len(unique),'all_original_points_reconstructed':True})
        hands.append({'kin':kin,'geom':geom,'gd':geom.createData(),'triangles':tris,'vertices':vertices,
            'radii':np.asarray(radii),'levers':np.asarray(levers),'names':names,'checker':checker,'faces':faces})
    def geometry_at(q):
        worlds,triangles,transforms=[],[],[]
        for si,h in enumerate(hands):
            h['kin'].configuration.update(q[si])
            pin.updateGeometryPlacements(h['kin'].robot.model,h['kin'].configuration.data,h['geom'],h['gd'],q[si])
            transforms.append([coal.Transform3s(tf.rotation,tf.translation) for tf in h['gd'].oMg])
            worlds.append([v@tf.rotation.T+tf.translation for v,tf in zip(h['vertices'],h['gd'].oMg)])
            triangles.append([v[f] for v,f in zip(worlds[-1],h['faces'])])
        return worlds,triangles,transforms
    def held_phase(si,t):
        return next((v for v in motion.sides[si]['phases'] if v['interval'][0]<=t<=v['interval'][1]),None)
    def world_displacement(si,low,high,qa,qb,phase):
        h=hands[si]
        finger=h['levers']@abs(qb[si,7:]-qa[si,7:])/2
        if phase is None:
            bound=np.linalg.norm(qb[si,:3]-qa[si,:3])/2+h['radii']*angle(qa[si,3:7],qb[si,3:7])/2+finger
        else:
            oi=phase['object']
            ra,pa,_=motion.object_pose(oi,low)
            rb,pb,_=motion.object_pose(oi,high)
            rotation_angle=float((Rotation.from_matrix(ra).inv()*Rotation.from_matrix(rb)).magnitude())
            # Use source SO3 separately: Rotation.from_matrix(R+residual) is not
            # the exact source SLERP and cannot define its angular-speed bound.
            source_row,_=motion.bracket((low+high)/2)
            raw=motion.source[f'object_{oi}_world'][source_row:source_row+2,:3,:3]
            source_angle=float((Rotation.from_matrix(raw[0]).inv()*Rotation.from_matrix(raw[1])).magnitude())
            rotation_angle=source_angle*(high-low)/(motion.times[source_row+1]-motion.times[source_row])
            stored=motion.hold_local[phase['prefix']]
            index=min(int(np.searchsorted(stored['rows'],source_row)),len(stored['rows'])-2)
            local=stored['qpos'][index:index+2]
            ratio=(high-low)/(motion.times[source_row+1]-motion.times[source_row])
            local_move=np.linalg.norm(local[1,:3]-local[0,:3])*ratio/2
            local_angle=angle(local[0,3:7],local[1,3:7])*ratio/2
            radius=max(np.linalg.norm(local[0,:3]),np.linalg.norm(local[1,:3]))+h['radii']
            bound=np.linalg.norm(pb-pa)/2+radius*rotation_angle/2+local_move+h['radii']*local_angle+finger
        return bound+2e-10,finger+1e-10
    own_cache={}
    surface_cache={}
    surface_cache_attempts={}
    surface_cache_hits=0
    def own_hold_certificate(si,phase,oi,gi):
        key=(si,phase['prefix'],oi,gi)
        if key not in own_cache:
            h=hands[si];m=materials[oi]
            local=motion.hold_local[phase['prefix']]['qpos']
            reference=local[0]
            np.testing.assert_array_equal(local[:,7:],np.broadcast_to(reference[7:],local[:,7:].shape))
            h['kin'].configuration.update(reference)
            pin.updateGeometryPlacements(h['kin'].robot.model,h['kin'].configuration.data,h['geom'],h['gd'],reference)
            tf=h['gd'].oMg[gi]
            original=h['triangles'][gi]@tf.rotation.T+tf.translation
            radius=float(np.linalg.norm(original.reshape(-1,3),axis=1).max())
            local_move=float(np.linalg.norm(local[:,:3]-reference[:3],axis=1).max())
            local_angle=float((Rotation.from_quat(reference[3:7]).inv()*Rotation.from_quat(local[:,3:7])).magnitude().max())
            # Local translation interpolation stays in its endpoint convex hull;
            # these tiny local rotations lie inside a convex SO3 ball (<pi/2).
            assert local_angle<.01
            deviation=local_move+h['radii'][gi]*local_angle+2e-10
            smin,smax,sref=m['scale_min'],m['scale_max'],m['scale_reference']
            eps=m['epsilon']
            padding=radius*max(abs(1/smin-1/sref),abs(1/smax-1/sref))
            padding+=(deviation+eps/(1-eps)*(radius+deviation))/smin
            metric=(smin*(1-eps),smax*(1+eps))
            world_padding=metric[1]*padding
            if world_padding>=.0005:
                result={'triangle_material_limit_certified':False,'status':'global hold family requires local subdivision'}
            else:
                result=mesh_certificate(m['boundary'],m['box'],original/sref,np.eye(3),metric,padding,world_padding)
            own_cache[key]=result
        return own_cache[key]
    self_cache={}
    intervals=[]
    failures=[]
    queries=0
    max_excess=-np.inf
    resume_segment=-1
    resume_binding=None
    if a.resume_from is not None:
        rp=a.resume_from/'progress.json'
        cp=a.resume_from/'certified-intervals-partial.json'
        binding=json.loads((a.resume_from/'resume-binding.json').read_text())
        assert binding['motion_proposal_report_sha256']==sha(a.proposal/'report.json')
        assert binding['bundle_manifest_sha256']==sha(a.bundle/'manifest.json')
        assert binding['material_manifest_sha256']==sha(a.material/'manifest.json')
        assert binding['progress_sha256']==sha(rp) and binding['certified_intervals_sha256']==sha(cp)
        assert binding['parent_checker_sha256']==sha(Path(__file__).with_name('certify_locked_replay_scene_v9.py'))
        progress=json.loads(rp.read_text())
        intervals=json.loads(cp.read_text())
        resume_segment=int(progress['last_complete_segment'])
        assert len(intervals)==progress['certified_intervals']
        assert set(v['segment'] for v in intervals)==set(range(resume_segment+1))
        for seg in range(resume_segment+1):
            records=sorted((v for v in intervals if v['segment']==seg),key=lambda v:v['time_low_s'])
            assert records[0]['time_low_s']==motion.breakpoints[seg]
            assert records[-1]['time_high_s']==motion.breakpoints[seg+1]
            assert all(x['time_high_s']==y['time_low_s'] for x,y in zip(records[:-1],records[1:]))
            assert all(all(c['pass'] for c in v['material_checks']) and v['self_separation_bound_m']>0 and v['cross_hand_separation_bound_m']>0 for v in records)
        queries=int(progress['queries'])
        # Every completed prior interval executed an assertion below 2e-9.
        # The exact prior maximum was not saved; report this conservative bound.
        max_excess=2e-9
        resume_binding=binding
    a.out.mkdir(parents=True)
    for segment,(ta,tb) in enumerate(zip(motion.breakpoints[:-1],motion.breakpoints[1:])):
        if segment<=resume_segment:continue
        assert tb>ta
        # Every knot interval remains inside one source-object SLERP segment.
        sr,_=motion.bracket((ta+tb)/2)
        assert ta>=motion.times[sr]-1e-12 and tb<=motion.times[sr+1]+1e-12
        phases=[held_phase(si,(ta+tb)/2) for si in range(2)]
        queue=[(float(ta),float(tb),0)]
        while queue:
            low,high,depth=queue.pop()
            mid=(low+high)/2
            qa=motion.evaluate(low)[0];qb=motion.evaluate(high)[0];qm=motion.evaluate(mid)[0]
            worlds,tris,tfs=geometry_at(qm)
            movement=[world_displacement(si,low,high,qa,qb,phases[si]) for si in range(2)]
            # Numerical controls support the analytical model; they do not
            # substitute for the lever/SO3 bounds at unsampled times.
            wa=geometry_at(qa)[0];wb=geometry_at(qb)[0]
            for si in range(2):
                for gi in range(len(hands[si]['names'])):
                    actual=max(float(np.linalg.norm(wa[si][gi]-worlds[si][gi],axis=1).max()),float(np.linalg.norm(wb[si][gi]-worlds[si][gi],axis=1).max()))
                    max_excess=max(max_excess,actual-movement[si][0][gi])
                    assert actual-movement[si][0][gi]<2e-9
            certified=True
            explicit=False
            material_records=[]
            for oi,m in materials.items():
                raw=motion.source[f'object_{oi}_world'][sr:sr+2,:3,:3]
                rotations=Rotation.from_matrix(raw)
                residual=raw-rotations.as_matrix()
                ratio=(high-low)/(motion.times[sr+1]-motion.times[sr])/2
                theta=float((rotations[0].inv()*rotations[1]).magnitude())*ratio
                residual_move=float(np.linalg.norm(residual[1]-residual[0],ord=2))*ratio
                matrix,translation,smid=motion.object_pose(oi,mid)
                matrix=matrix*smid
                inverse=np.linalg.inv(matrix)
                _,pa,sa=motion.object_pose(oi,low)
                _,pb,sb=motion.object_pose(oi,high)
                smin,smax=min(sa,sb),max(sa,sb)
                sigma_min=smin*(1-m['epsilon']);sigma_max=smax*(1+m['epsilon'])
                matrix_move=smax*(theta+residual_move)+abs(sb-sa)/2*(1+m['epsilon'])
                for si,h in enumerate(hands):
                    for gi,tri in enumerate(tris[si]):
                        phase=phases[si]
                        own_result=own_hold_certificate(si,phase,oi,gi) if phase is not None and phase['object']==oi else None
                        if own_result is not None and own_result['triangle_material_limit_certified']:
                            material_records.append({'side':('left','right')[si],'object':oi,'link':h['names'][gi],'pass':True,'status':'cached complete rigid hold scale/affine/local-anchor family','world_padding_m':own_result.get('world_displacement_padding_m',0.)})
                            continue
                        canonical=(tri-translation)@inverse.T
                        radius=float(np.linalg.norm(canonical.reshape(-1,3),axis=1).max())
                        padding=(movement[si][0][gi]+np.linalg.norm(pb-pa)/2+matrix_move*radius)/sigma_min
                        world_padding=m['scale_max']*(1+m['epsilon'])*padding
                        lowbox,highbox=m['box']
                        # The original triangle vertices retain fixed identities.
                        # Their maximum displacement bounds every barycentric
                        # point of every corresponding original triangle.
                        vertices_local=(worlds[si][gi]-translation)@inverse.T
                        key=(si,oi,gi)
                        global_metric=(m['scale_min']*(1-m['epsilon']),m['scale_max']*(1+m['epsilon']))
                        previous=surface_cache.get(key)
                        reference_move=None
                        if previous is not None:
                            reference_move=float(np.linalg.norm(vertices_local-previous['vertices'],axis=1).max())
                            upper=previous['depth_upper_m']+global_metric[1]*(reference_move+padding)+1e-10
                            if upper<=.002:
                                surface_cache_hits+=1
                                material_records.append({'side':('left','right')[si],'object':oi,'link':h['names'][gi],
                                    'pass':True,'status':'cached original whole-surface proof plus vertex and swept displacement bound',
                                    'maximum_depth_upper_m':upper,'reference_depth_upper_m':previous['depth_upper_m'],
                                    'canonical_reference_displacement_m':reference_move,'world_padding_m':world_padding})
                                continue
                        # A tighter reference certificate creates a reusable
                        # margin; a failed tighter check never refutes this path.
                        last_attempt=surface_cache_attempts.get(key)
                        new_attempt=(last_attempt is None or float(np.linalg.norm(vertices_local-last_attempt,axis=1).max())>.001)
                        if world_padding<.0004 and new_attempt:
                            surface_cache_attempts[key]=vertices_local.copy()
                            possible_reference=(canonical.max(axis=1)>=lowbox-1e-10).all(axis=1)&(canonical.min(axis=1)<=highbox+1e-10).all(axis=1)
                            if possible_reference.any():
                                tight=certify(m['boundary'],canonical[possible_reference],np.eye(3),limit=.0015,metric_singular_bounds=global_metric)
                                success=tight['triangle_material_limit_certified']
                                depth_upper=max(0.,tight.get('maximum_certified_subtriangle_depth_upper_m') or 0.)
                            else:
                                success=True;depth_upper=0.
                            if success:
                                assert depth_upper<=.0015
                                surface_cache[key]={'vertices':vertices_local.copy(),'depth_upper_m':depth_upper}
                                upper=depth_upper+global_metric[1]*padding+1e-10
                                if upper<=.002:
                                    material_records.append({'side':('left','right')[si],'object':oi,'link':h['names'][gi],
                                        'pass':True,'status':'new complete original-surface margin certificate',
                                        'maximum_depth_upper_m':upper,'reference_depth_upper_m':depth_upper,
                                        'canonical_reference_displacement_m':0.,'world_padding_m':world_padding})
                                    continue
                        possible=(canonical.max(axis=1)>=lowbox-padding-1e-10).all(axis=1)&(canonical.min(axis=1)<=highbox+padding+1e-10).all(axis=1)
                        if not possible.any():
                            passed=True;status='complete swept AABB separated'
                        elif world_padding>=.0005:
                            passed=False;status='motion padding requires subdivision'
                        else:
                            result=mesh_certificate(m['boundary'],m['box'],canonical,np.eye(3),global_metric,padding,world_padding)
                            passed=bool(result['triangle_material_limit_certified']);status=result['status']
                            if passed:
                                # Every certified subtriangle is covered, not just
                                # sampled vertices. The global metric bounds make
                                # this reference valid for every source affine/scale.
                                # Original triangles outside the expanded AABB have
                                # depth <= 0 and are included conservatively here.
                                complete_upper=max(0.,float(result.get('maximum_certified_subtriangle_depth_upper_m') or 0.))
                                assert complete_upper<=.002-world_padding+1e-12
                                surface_cache[key]={'vertices':vertices_local.copy(),'depth_upper_m':complete_upper}
                            explicit=explicit or bool(result.get('explicit_actual_family_intrusion_proven',False))
                        certified=certified and passed
                        material_records.append({'side':('left','right')[si],'object':oi,'link':h['names'][gi],'pass':passed,'status':status,'world_padding_m':world_padding})
            # Same-hand root motion cancels, so only joint lever bounds enter.
            self_margin=np.inf
            for si,h in enumerate(hands):
                key=(si,qm[si,7:].tobytes())
                if key not in self_cache:
                    neutral=qm[si].copy();neutral[:3]=0;neutral[3:7]=[0,0,0,1]
                    self_cache[key]=h['checker'].evaluate(neutral,False)[0]
                distances=self_cache[key]
                for k,(i,j) in enumerate(h['checker'].pairs):
                    margin=distances[k]-movement[si][1][i]-movement[si][1][j]-1e-10
                    self_margin=min(self_margin,float(margin))
                    certified=certified and margin>0
                    explicit=explicit or distances[k]<=0
            cross_margin=np.inf
            for i,first in enumerate(hands[0]['checker'].convex):
                for j,second in enumerate(hands[1]['checker'].convex):
                    d=distance(first,tfs[0][i],second,tfs[1][j])
                    margin=d-movement[0][0][i]-movement[1][0][j]-1e-10
                    cross_margin=min(cross_margin,margin)
                    certified=certified and margin>0
                    explicit=explicit or d<=0
            queries+=1
            record={'segment':segment,'time_low_s':low,'time_high_s':high,'depth':depth,
                'material_checks':material_records,'self_separation_bound_m':self_margin,'cross_hand_separation_bound_m':cross_margin}
            if certified:intervals.append(record)
            elif explicit or depth>=20:
                record['status']='explicit failure' if explicit else 'unresolved; refused'
                failures.append(record)
                break
            else:
                queue.extend(((mid,high,depth+1),(low,mid,depth+1)))
        if failures:break
        if segment%25==0:
            checkpoint={'last_complete_segment':segment,'total_segments':len(motion.breakpoints)-1,'certified_intervals':len(intervals),'queries':queries,'full_run_terminal':False,'physical_task_accepted':False,'elapsed_seconds':time.monotonic()-started}
            (a.out/'progress.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
            (a.out/'certified-intervals-partial.json').write_text(json.dumps(intervals,separators=(',',':'))+'\n')
            print(json.dumps(checkpoint),flush=True)
    result={'source_sha256':sha(Path(__file__)),'motion_module_sha256':sha(Path(__file__).with_name('locked_replay_motion_v3.py')),
        'proposal_report_sha256':sha(a.proposal/'report.json'),'bundle_manifest_sha256':sha(a.bundle/'manifest.json'),
        'material_manifest_sha256':sha(a.material/'manifest.json'),'controls':tested,'original_geometry':geometry,
        'hull_containment_controls':[h['checker'].hull_controls for h in hands],
        'certified_intervals':intervals,'failed_or_unresolved_intervals':failures,
        'complete_replay_object_self_and_cross_hand_surfaces_certified':not failures and segment==len(motion.breakpoints)-2,
        'object_material_world_depth_limit_m':.002,'spatial_certificate_query_budget':50000,'maximum_spatial_subdivision_depth':18,'maximum_temporal_subdivision_depth':20,'unresolved_spatial_proofs_trigger_temporal_subdivision':True,'affine_residual_and_scale_bounded':True,
        'original_vertex_control_maximum_bound_excess_upper_m':float(max_excess),'queries':queries,
        'resumed_certified_segments':resume_segment+1,'resume_binding':resume_binding,
        'cached_complete_hold_families':len(own_cache),'whole_surface_cache_hits':surface_cache_hits,'whole_surface_cache_reference_count':len(surface_cache),'passed_complete_surface_certificates_reused_with_global_metric':True,
        'table_environment_checked':False,'source_accuracy_accepted':False,
        'batched_boundary_verification_sha256':sha(Path(__file__).with_name('batched-boundary-verification-v1.json')),
        'original_mesh_vertices_reconstructed_before_transform':True,
        'physical_material_geometry_ground_truth':False,'physical_task_accepted':False,'new_simulator_run':False,
        'elapsed_seconds':time.monotonic()-started}
    (a.out/'report.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('complete_replay_object_self_and_cross_hand_surfaces_certified','queries','elapsed_seconds')}))

if __name__=='__main__':main()
