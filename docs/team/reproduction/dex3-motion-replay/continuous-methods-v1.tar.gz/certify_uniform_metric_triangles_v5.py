"""Conservative whole-triangle material-depth checks at original source scenes.

Signed distance is 1-Lipschitz. A centre depth upper bound plus its enclosing
radius certifies the whole triangle. Ambiguous cells subdivide; unresolved
queries fail certification rather than becoming a passed mesh check.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from exact_voxel_boundary_v1 import Boundary

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def centre_bounds(boundary,points):
    centre_distance,nearest=boundary.tree.query(points,k=1,workers=1)
    lower=np.maximum(0.,centre_distance-np.sqrt(2)*boundary.pitch/2)
    delta=np.maximum(np.abs(points-boundary.centers[nearest])-boundary.half[nearest],0)
    upper=np.linalg.norm(delta,axis=-1)
    inside=boundary.inside(points)
    return np.where(inside,lower,-upper),np.where(inside,upper,-lower)

def subdivide(triangles):
    a,b,c=triangles[:,0],triangles[:,1],triangles[:,2]
    ab,bc,ca=(a+b)/2,(b+c)/2,(c+a)/2
    return np.stack((np.stack((a,ab,ca),axis=1),np.stack((ab,b,bc),axis=1),
                     np.stack((ca,bc,c),axis=1),np.stack((ab,bc,ca),axis=1)),axis=1).reshape(-1,3,3)

def certify(boundary,triangles,scale,limit=.002,max_depth=18,metric_singular_bounds=None):
    matrix=np.eye(3)*scale if np.ndim(scale)==0 else np.asarray(scale,dtype=float)
    singular=np.linalg.svd(matrix,compute_uv=False);small=float(singular.min());large=float(singular.max())
    assert small>0 and np.isfinite(matrix).all()
    if metric_singular_bounds is not None:
        small,large=map(float,metric_singular_bounds)
        assert 0<small<=large and np.isfinite([small,large]).all()
    work=np.asarray(triangles);ids=np.arange(len(work),dtype=np.int64)
    history=[];certified=0;queries=0;maximum_witness=-np.inf;worst=None
    safe_upper=-np.inf
    for depth in range(max_depth+1):
        if not len(work):break
        centres=work.mean(axis=1)
        radius=(np.linalg.norm((work-centres[:,None])@matrix.T,axis=-1).max(axis=1) if metric_singular_bounds is None else large*np.linalg.norm(work-centres[:,None],axis=-1).max(axis=1))
        lower,upper=centre_bounds(boundary,centres)
        lower=np.where(lower>=0,lower*small,lower*large)
        upper=np.where(upper>=0,upper*large,upper*small)
        safe=upper+radius<=limit
        uncertain=np.flatnonzero((~safe)&(boundary.inside(centres)|(lower+radius<=limit)))
        exact_count=0
        if len(uncertain):
            distance,_,_=boundary.unsigned(centres[uncertain]);exact_count=len(uncertain)
            exact=distance*np.where(boundary.inside(centres[uncertain]),1.,-1.)
            lower[uncertain]=np.where(exact>=0,exact*small,exact*large)
            upper[uncertain]=np.where(exact>=0,exact*large,exact*small)
            safe=upper+radius<=limit
        queries+=len(centres)+exact_count;certified+=int(safe.sum())
        if safe.any():safe_upper=max(safe_upper,float((upper+radius)[safe].max()))
        index=int(np.argmax(lower));value=float(lower[index])
        if value>maximum_witness:
            maximum_witness=value;worst={'original_triangle_index':int(ids[index]),'subdivision_depth':depth,
                                         'point_object_local_m':centres[index].tolist(),'signed_material_depth_lower_m':value,'signed_material_depth_upper_m':float(upper[index])}
        unresolved=np.flatnonzero(~safe)
        history.append({'depth':depth,'subtriangles':len(work),'certified_subtriangles':int(safe.sum()),
                        'exact_boundary_queries':exact_count,'remaining_subtriangles':len(unresolved),
                        'maximum_depth_upper_plus_radius_m':float(np.max(upper+radius)),
                        'maximum_centre_depth_m':float(lower.max())})
        if maximum_witness>limit:
            return {'status':'failed: explicit material-depth witness','triangle_material_limit_certified':False,
                    'original_triangles':len(triangles),'maximum_signed_depth_witness_m':maximum_witness,'witness':worst,
                    'remaining_subtriangles':len(unresolved),'queries':queries,'history':history}
        if depth==max_depth or queries>50000:
            work=work[unresolved];ids=ids[unresolved];break
        work=subdivide(work[unresolved]);ids=np.repeat(ids[unresolved],4)
    result=not len(work)
    return {'status':'certified for declared material only' if result else 'unresolved: refused certification',
            'triangle_material_limit_certified':result,'original_triangles':len(triangles),
            'maximum_signed_depth_witness_m':maximum_witness,'witness':worst,'remaining_subtriangles':len(work),
            'maximum_certified_subtriangle_depth_upper_m':float(safe_upper) if np.isfinite(safe_upper) else None,
            'queries':queries,'history':history}

def controls():
    box=Boundary(np.ones((1,1,1),dtype=bool),np.zeros(3),.02)
    crosses=np.array([[[-.025,-.025,0],[.025,-.025,0],[0,.05,0]]])
    assert not box.inside(crosses.reshape(-1,3)).any()
    failed=certify(box,crosses,1.)
    assert not failed['triangle_material_limit_certified'] and failed['maximum_signed_depth_witness_m']>.0099
    np.testing.assert_allclose(failed['maximum_signed_depth_witness_m'],.01,atol=1e-12)
    outside=np.array([[[1.,0,0],[1.001,0,0],[1.,.001,0]]])
    passed=certify(box,outside,1.)
    assert passed['triangle_material_limit_certified']
    face=np.array([[[.0105,0,0],[.0105,.003,0],[.0105,0,.003]]])
    passed=certify(box,face,1.)
    assert passed['triangle_material_limit_certified']
    np.testing.assert_allclose(subdivide(crosses).mean(axis=(0,1)),crosses.mean(axis=(0,1)),atol=1e-12)
    affine=np.diag([.8,.9,1.3]);affine_result=certify(box,crosses,affine)
    assert not affine_result['triangle_material_limit_certified']
    np.testing.assert_allclose(affine_result['maximum_signed_depth_witness_m'],.008,atol=1e-12)
    assert certify(box,outside,affine)['triangle_material_limit_certified']
    return {'affine_minimum_singular_value_lower_depth_control':True,'affine_exterior_radius_control':True,'outside_vertices_do_not_certify_crossing_triangle':True,'analytic_centre_depth':True,
            'separated_and_near_exterior_faces_certified':True,'subdivision_centre_preserved':True}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('bundle','scenes','material','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();assert not a.out.exists();started=time.monotonic()
    sm=json.loads((a.scenes/'report.json').read_text());bm=json.loads((a.bundle/'manifest.json').read_text())
    mm=json.loads((a.material/'manifest.json').read_text());assert sm['bundle_manifest_sha256']==sha(a.bundle/'manifest.json')
    assert bm['payload']['sha256']==mm['source_bundle_payload_sha256']==sha(a.bundle/'episode.npz')
    with np.load(a.bundle/'episode.npz',allow_pickle=False) as arc:d={k:arc[k] for k in arc.files}
    tested=controls();boundaries=[];records=[]
    for entry in mm['objects']:
        path=a.material/f"object_{entry['object']}.npz";assert sha(path)==entry['payload_sha256']
        with np.load(path,allow_pickle=False) as arc:g={k:arc[k] for k in arc.files}
        boundaries.append(Boundary(g['solid_cells'],g['origin_m'],g['pitch_m']))
    for scene in sm['scenes']:
        path=a.scenes/scene['payload_name'];assert sha(path)==scene['payload_sha256']
        with np.load(path,allow_pickle=False) as arc:triangles=arc['robot_vertices_world'][arc['robot_faces']]
        row=scene['source_row'];assert int(d['frame_indices'][row])==scene['source_frame']
        for oi,obj in enumerate(bm['objects']):
            pose=d[f'object_{oi}_world'][row];scale=float(d[f'object_{oi}_scale'][row])
            assert scale>0 and np.isfinite(pose).all()
            matrix=pose[:3,:3]*scale
            singular=np.linalg.svd(matrix,compute_uv=False);assert singular.min()>0
            local=np.einsum('ij,pkj->pki',np.linalg.inv(matrix),triangles-pose[:3,3])
            result=certify(boundaries[oi],local,matrix)
            observed=bm['object_observation_provenance'][obj['name']][str(scene['source_frame'])]
            record={'side':scene['side'],'seed':scene['seed'],'source_frame':scene['source_frame'],
                    'against_object':oi,'object_pose_provenance':observed,'source_affine_singular_values':singular.tolist(),**result,'physical_task_accepted':False}
            records.append(record);print(json.dumps({k:v for k,v in record.items() if k not in ('history','witness')}),flush=True)
    a.out.mkdir(parents=True)
    report={'source_sha256':sha(Path(__file__)),'boundary_source_sha256':sha(Path(__file__).parent/'exact_voxel_boundary_v1.py'),
            'scene_report_sha256':sha(a.scenes/'report.json'),'bundle_manifest_sha256':sha(a.bundle/'manifest.json'),
            'material_manifest_sha256':sha(a.material/'manifest.json'),'limit_m':.002,'maximum_subdivision_depth':12,
            'query_budget':2000000,'every_material_triangle_certificate_requires_no_unresolved_region':True,
            'whole_scene_surface_limit_certified':all(v['triangle_material_limit_certified'] and v['object_pose_provenance']=='observed' for v in records),
            'surface_definition':'original exported robot triangles against existing closed cell material union; signed distance1-Lipschitz bound',
            'source_object_transforms_modified':False,'metric':'source affine matrix is preserved; canonical distance bounded by its min/max singular values; radius measured in original world metric',
            'solid_volume_containment_or_dynamics_checked':False,'physical_object_geometry_known':False,
            'controls':tested,'scenes':records,'physical_task_accepted':False,'elapsed_seconds':time.monotonic()-started}
    (a.out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')

if __name__=='__main__':main()
