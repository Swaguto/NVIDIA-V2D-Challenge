"""Batch the original boundary-square minimum without changing its candidate set."""
import numpy as np
from exact_voxel_boundary_v1 import Boundary as ReferenceBoundary


class Boundary(ReferenceBoundary):
    def unsigned(self, points):
        points = np.asarray(points, dtype=float)
        assert points.ndim == 2 and points.shape[1] == 3 and np.isfinite(points).all()
        _, nearest = self.tree.query(points, k=1)
        first = np.maximum(np.abs(points - self.centers[nearest]) - self.half[nearest], 0)
        upper = np.linalg.norm(first, axis=1)
        radii = upper + np.sqrt(2) * self.pitch / 2 + 1e-12
        distance = np.empty(len(points))
        nearest_face = np.empty(len(points), dtype=np.int64)
        queries = largest = 0
        for start in range(0, len(points), 256):
            batch = points[start:start + 256]
            candidates = self.tree.query_ball_point(batch, radii[start:start + 256], eps=0)
            counts = np.fromiter((len(ids) for ids in candidates), dtype=np.int64)
            assert (counts > 0).all()
            ids = np.concatenate(candidates).astype(np.int64, copy=False)
            owners = np.repeat(np.arange(len(batch)), counts)
            offsets = np.r_[0, np.cumsum(counts)[:-1]]
            delta = np.maximum(np.abs(batch[owners] - self.centers[ids]) - self.half[ids], 0)
            squared = np.einsum('ij,ij->i', delta, delta)
            minimum = np.minimum.reduceat(squared, offsets)
            # Retain the reference implementation's first minimum, including ties.
            position = np.arange(len(ids))
            first_minimum = np.minimum.reduceat(
                np.where(squared == np.repeat(minimum, counts), position, len(ids)), offsets)
            end = start + len(batch)
            distance[start:end] = np.sqrt(minimum)
            nearest_face[start:end] = ids[first_minimum]
            queries += int(counts.sum())
            largest = max(largest, int(counts.max()))
        return distance, nearest_face, {
            'boundary_square_queries': queries,
            'maximum_candidate_faces_per_point': largest,
        }
