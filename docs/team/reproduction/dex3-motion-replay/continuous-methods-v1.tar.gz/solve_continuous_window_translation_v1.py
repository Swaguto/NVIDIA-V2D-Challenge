"""Use exact signed witness clearance across an automatic source gap.

One vector serves all witness times, multiplied by their smooth window weights.
Independent original-triangle certificates still determine static rejection.
"""
import itertools
import numpy as np
from scipy.optimize import minimize
from scipy.spatial.transform import Rotation

from exact_signed_boundary_gradient_v1 import signed_clearance_gradient
from audit_static_hold_scene_triangles_v7 import mesh_certificate


def solve_translation(contexts, materials, reserve=.0005, maximum_norm_m=.010):
    assert contexts and 0 < reserve <= .001 and maximum_norm_m == .010
    cuts = [[] for _ in contexts]
    cache, gradient_errors = {}, []
    search_headroom = .0001
    for context in contexts:
        weight = context['weight']
        assert 0 < weight <= 1.
        for oi, (_, _, pitch, boundary, _) in materials.items():
            translation, matrix, inverse = context['poses'][oi]
            canonical = boundary.centers[:1].copy()
            canonical[0, boundary.axes[0]] += boundary.signs[0] * pitch * .237
            _, gradient = signed_clearance_gradient(boundary, canonical)
            analytic = gradient @ inverse * .001 * weight
            for axis in range(3):
                step = .00001
                dc = inverse[:, axis] * .001 * weight * step
                numeric = (signed_clearance_gradient(boundary, canonical+dc)[0] -
                           signed_clearance_gradient(boundary, canonical-dc)[0]) / (2*step)
                error = float(abs(numeric-analytic[:, axis]).max())
                assert error < 1e-7
                gradient_errors.append(error)

    def evaluate(x):
        if 'x' in cache and np.array_equal(x, cache['x']):
            return cache['value'], cache['gradient']
        values, gradients = [], []
        # Batch nearest-square searches per object. Every active vertex and
        # every added original-surface witness uses the exact signed distance.
        for oi, (_, _, _, boundary, _) in materials.items():
            canonical, inverses, weights, smin, smax = [], [], [], [], []
            for ci, context in enumerate(contexts):
                weight = context['weight']
                points = np.concatenate([context['world']] + cuts[ci]) + x[None, :] * .001 * weight
                translation, matrix, inverse = context['poses'][oi]
                canonical.append((points-translation) @ inverse.T)
                inverses.append(np.broadcast_to(inverse, (len(points), 3, 3)))
                weights.extend([weight]*len(points))
                singular = np.linalg.svd(matrix, compute_uv=False)
                smin.extend([float(singular.min())]*len(points))
                smax.extend([float(singular.max())]*len(points))
            weights = np.asarray(weights)
            value, gradient = signed_clearance_gradient(boundary, np.concatenate(canonical))
            # Conservative affine distance bounds: deepest possible inside,
            # nearest possible outside. Full triangles still decide acceptance.
            scale = np.where(value < 0., smax, smin)
            values.append((value*scale+.002-(reserve+search_headroom)*weights)*1000.)
            jacobian = np.einsum('bi,bij->bj', gradient, np.concatenate(inverses))
            gradients.append(jacobian * (weights*scale)[:, None])
        cache.update(x=x.copy(), value=np.concatenate(values), gradient=np.concatenate(gradients))
        return cache['value'], cache['gradient']

    # Tighten optimization only if the initial point constraints need repair.
    # Already valid shallow contact still returns zero correction. Full original
    # surfaces, the 2 mm criterion and the 10 mm norm bound are unchanged.
    if float(evaluate(np.zeros(3))[0].min()) < -1e-6:
        search_headroom = .0004
        cache.clear()

    source_axes = Rotation.from_matrix(contexts[0]['poses'][min(materials)][1]).as_matrix()
    directions = np.array([v for v in itertools.product((-1., 0., 1.), repeat=3) if any(v)])
    directions /= np.linalg.norm(directions, axis=1)[:, None]
    directions = directions @ source_axes.T
    seeds = [np.zeros(3)] + [r*d for r in (1., 2., 4., 8., 10.) for d in directions]
    seed_records = []
    for seed in seeds:
        margin = evaluate(seed)[0]
        seed_records.append({'translation_mm': seed.tolist(), 'minimum_proxy_margin_mm': float(margin.min()),
                             'squared_hinge_sum_mm2': float(np.maximum(-margin, 0.) @ np.maximum(-margin, 0.))})
    feasible = [i for i, v in enumerate(seed_records) if v['minimum_proxy_margin_mm'] >= -1e-6]
    selected = (min(feasible, key=lambda i: (float(seeds[i] @ seeds[i]), i)) if feasible else
                min(range(len(seeds)), key=lambda i: (seed_records[i]['squared_hinge_sum_mm2'], float(seeds[i] @ seeds[i]), i)))
    x = seeds[selected].copy()
    history = []
    for cycle in range(16):
        cache.clear()
        if float(evaluate(x)[0].min()) < -1e-6 or np.linalg.norm(x) > 1e-6:
            result = minimize(lambda y: .5*(y @ y), x, jac=lambda y: y, bounds=[(-10., 10.)]*3,
                              constraints=[{'type':'ineq', 'fun':lambda y:evaluate(y)[0], 'jac':lambda y:evaluate(y)[1]},
                                           {'type':'ineq', 'fun':lambda y:(maximum_norm_m*1000.)**2-y@y,
                                            'jac':lambda y:-2*y}],
                              method='SLSQP', options={'maxiter':120, 'ftol':1e-9})
            x = result.x
            solver = {'success':bool(result.success), 'message':str(result.message), 'iterations':int(result.nit),
                      'maximum_translation_norm_m':maximum_norm_m, 'world_depth_limit_m':.002,
                      'search_uses_exact_boundary_square_distance_not_a_surface_certificate':True,
                      'additional_certificate_search_headroom_m':search_headroom}
        else:
            solver = {'success':True, 'message':'all proxy constraints satisfied', 'iterations':0}
        certificates, newcuts = [], [[] for _ in contexts]
        for ci, context in enumerate(contexts):
            weight = context['weight']
            for oi, (_, _, _, boundary, box) in materials.items():
                translation, matrix, inverse = context['poses'][oi]
                triangles = context['triangles_loader']() if 'triangles_loader' in context else context['triangles']
                canonical = (triangles + x[None, None, :]*.001*weight - translation) @ inverse.T
                padding = reserve * weight
                smin = float(np.linalg.svd(matrix, compute_uv=False).min())
                certificate = mesh_certificate(boundary, box, canonical, matrix,
                                               canonical_displacement_padding_m=padding/smin,
                                               world_displacement_padding_m=padding)
                certificates.append({'context':ci, 'against_object':oi, **certificate})
                if not certificate['triangle_material_limit_certified'] and certificate['witness'] is not None:
                    world = np.array(certificate['witness']['point_object_local_m']) @ matrix.T + translation
                    newcuts[ci].append((world-x*.001*weight)[None, :])
            if (ci+1)%100==0 or ci+1==len(contexts):
                import json
                print(json.dumps({'stage':'original_surface_certificates','cycle':cycle,'contexts_completed':ci+1,'contexts_total':len(contexts)}),flush=True)
        history.append({'cycle':cycle, 'solver':solver, 'translation_amplitude_m':(x*.001).tolist(),
                        'minimum_proxy_margin_mm':float(evaluate(x)[0].min()), 'original_surface_certificates':certificates})
        passed = all(v['triangle_material_limit_certified'] for v in certificates) and np.linalg.norm(x)*.001 <= maximum_norm_m+1e-12
        if passed or cycle == 15 or not any(newcuts):
            break
        search_headroom = .0004
        cache.clear()
        for ci, additions in enumerate(newcuts):
            cuts[ci].extend(additions)
    assert np.linalg.norm(x)*.001 <= maximum_norm_m+1e-10, "Translation norm guard violated"
    return x*.001, history, seed_records, selected, sum(map(len, cuts)), passed, max(gradient_errors)
