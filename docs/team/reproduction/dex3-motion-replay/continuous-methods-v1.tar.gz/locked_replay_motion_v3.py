"""Declare the final replay interpolation explicitly, preserving grasp anchors.

Free motion uses linear translation/fingers and shortest quaternion SLERP at
locked procedural knots. Closed grasp intervals retain the existing rigid
object-following evaluator. This is a new between-knot candidate, not a proof
that finite probes certify its procedural parent. All robot states are inferred.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from corrected_per_grasp_motion_v1 import load,sha
from propose_robot_contact_motion_v1 import blend
from clearance_gated_edge_motion_v2 import ClearanceGatedEdgeMotion


class LockedReplayMotion:
    def __init__(self,bundle,baseline,parent_proposal,interval_inputs,atlas,proposal,*,source):
        saved=json.loads((proposal/'report.json').read_text())
        assert saved['motion_module_sha256']==sha(Path(__file__))
        assert saved['payload_sha256']==sha(proposal/'robot-motion-proposal.npz')
        assert saved['replay_knots_sha256']==sha(proposal/'replay-knots.npz')
        assert saved['physical_task_accepted'] is False
        parent=proposal.parent/saved['procedural_parent_proposal']
        assert saved['procedural_parent_report_sha256']==sha(parent/'report.json')
        self.base=ClearanceGatedEdgeMotion(bundle,baseline,parent_proposal,interval_inputs,atlas,parent,source=source)
        z=load(proposal/'replay-knots.npz')
        self.breakpoints=z['timestamps_s']
        self.knot_q=z['qpos_inferred']
        self.knot_kinds=z['inference_kind']
        self.knot_details=z['phase_details']
        assert np.all(np.diff(self.breakpoints)>0) and np.isin(self.base.times,self.breakpoints).all()
        original=load(parent/'robot-motion-proposal.npz')
        self.source_q=original['robot_qpos_inferred']
        self.hold_local={}
        for si,side in enumerate(self.base.sides):
            for phase in side['phases']:
                rows=np.asarray(phase['source_rows'])
                world=self.base.source[f"object_{phase['object']}_world"][rows]
                rotation=Rotation.from_matrix(world[:,:3,:3])
                local=self.source_q[rows,si].copy()
                local[:,:3]=rotation.inv().apply(local[:,:3]-world[:,:3,3])
                local[:,3:7]=(rotation.inv()*Rotation.from_quat(local[:,3:7])).as_quat()
                self.hold_local[phase['prefix']]={'rows':rows,'qpos':local}
        data=load(proposal/'robot-motion-proposal.npz')
        for key in original:
            if key not in ('robot_qpos_inferred','robot_transition_translation_delta_m'):
                np.testing.assert_array_equal(data[key],original[key])
        anchors=original['robot_contact_intent_inferred'].any(axis=2)
        np.testing.assert_array_equal(data['robot_qpos_inferred'][anchors],original['robot_qpos_inferred'][anchors])
        np.testing.assert_array_equal(data['robot_qpos_inferred'][:,:,3:],original['robot_qpos_inferred'][:,:,3:])
        assert np.linalg.norm(data['robot_qpos_inferred'][:,:,:3]-original['robot_qpos_inferred'][:,:,:3],axis=2).max()<=.010+1e-10
        assert data['robot_pose_is_inferred'].all() and not data['robot_motion_target_validated'].any()
        indices=np.searchsorted(self.breakpoints,self.base.times)
        np.testing.assert_array_equal(self.knot_q[indices],data['robot_qpos_inferred'])
        self.repair_report=saved
        self.source_sample_maximum_error=0.

    def __getattr__(self,name):return getattr(self.base,name)

    def evaluate(self,timestamp):
        row=int(np.clip(np.searchsorted(self.breakpoints,timestamp,side='right')-1,0,len(self.breakpoints)-2))
        fraction=float(np.clip((timestamp-self.breakpoints[row])/(self.breakpoints[row+1]-self.breakpoints[row]),0,1))
        q=np.array([blend(self.knot_q[row,si],self.knot_q[row+1,si],fraction) for si in range(2)])
        kinds=self.knot_kinds[row].copy()
        details=self.knot_details[row].copy()
        if fraction==0:q=self.knot_q[row].copy()
        elif fraction==1:q=self.knot_q[row+1].copy()
        for si,side in enumerate(self.base.sides):
            for phase in side['phases']:
                if phase['interval'][0]<=timestamp<=phase['interval'][1]:
                    source_row,f=self.base.bracket(timestamp)
                    support=self.hold_local[phase['prefix']]
                    i=int(np.searchsorted(support['rows'],source_row))
                    i=min(i,len(support['rows'])-2)
                    local=blend(support['qpos'][i],support['qpos'][i+1],f)
                    raw=self.base.source[f"object_{phase['object']}_world"][source_row:source_row+2]
                    rotation=Slerp([0.,1.],Rotation.from_matrix(raw[:,:3,:3]))([f])[0]
                    translation=raw[0,:3,3]*(1-f)+raw[1,:3,3]*f
                    q[si]=local
                    q[si,:3]=rotation.apply(local[:3])+translation
                    q[si,3:7]=(rotation*Rotation.from_quat(local[3:7])).as_quat()
                    kinds[si]=2
                    if timestamp in self.base.times:
                        q[si]=self.source_q[np.searchsorted(self.base.times,timestamp),si]
                    break
        return q,kinds,details

